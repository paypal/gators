
#include "header.h"

;


size_t get_num_class(void) {
  return 4;
}

size_t get_num_feature(void) {
  return 22;
}

const char* get_pred_transform(void) {
  return "softmax";
}

float get_sigmoid_alpha(void) {
  return 1.0;
}

float get_global_bias(void) {
  return 0.0;
}

const char* get_threshold_type(void) {
  return "float64";
}

const char* get_leaf_output_type(void) {
  return "float64";
}


static inline size_t pred_transform(double* pred) {
  const int num_class = 4;
  double max_margin = pred[0];
  double norm_const = 0.0;
  double t;
  for (int k = 1; k < num_class; ++k) {
    if (pred[k] > max_margin) {
      max_margin = pred[k];
    }
  }
  for (int k = 0; k < num_class; ++k) {
    t = exp(pred[k] - max_margin);
    norm_const += t;
    pred[k] = t;
  }
  for (int k = 0; k < num_class; ++k) {
    pred[k] /= (double)norm_const;
  }
  return (size_t)num_class;
}
size_t predict_multiclass(union Entry* data, int pred_margin, double* result) {
  double sum[4] = {0};
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  predict_margin_multiclass_unit0(data, sum);

  for (int i = 0; i < 4; ++i) {
    result[i] = sum[i] + (double)(0);
  }
  if (!pred_margin) {
    return pred_transform(result);
  } else {
    return 4;
  }
}
