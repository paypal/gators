#include "header.h"
double predict_margin_unit3(union Entry* data) {
  double sum = (double)0;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2721.000000000000455) ) ) {
    if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)226482.2540404040774) ) ) {
      sum += (double)-99.08732983438763142;
    } else {
      sum += (double)731.8444373366412492;
    }
  } else {
    sum += (double)1432.815302734375109;
  }
  if ( UNLIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)602.5000000000001137) ) ) {
    sum += (double)-1164.734005737304642;
  } else {
    if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1.500000000000000222) ) ) {
      sum += (double)75.3966930018810757;
    } else {
      sum += (double)-825.279009230593374;
    }
  }
  if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)5.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1922.500000000000227) ) ) {
      sum += (double)-1681.978082830255516;
    } else {
      sum += (double)-94.11543018969587138;
    }
  } else {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1983.500000000000227) ) ) {
      sum += (double)137.8768189046154191;
    } else {
      sum += (double)2016.874341947382163;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1049.000000000000227) ) ) {
    if ( UNLIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)159734.9453382438805) ) ) {
      sum += (double)-1427.542704772949264;
    } else {
      sum += (double)-248.0332709751246227;
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)189694.8191971420601) ) ) {
      sum += (double)36.74415335571135444;
    } else {
      sum += (double)1110.136396603468029;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)8.500000000000001776) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2650.000000000000455) ) ) {
      sum += (double)42.71978176783451886;
    } else {
      sum += (double)2054.30078308105476;
    }
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)8.500000000000001776) ) ) {
      sum += (double)-194.7526152519952802;
    } else {
      sum += (double)-1586.757102683738594;
    }
  }
  if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)2007.500000000000227) ) ) {
    if ( UNLIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)129170.4858116823452) ) ) {
      sum += (double)-647.4717330007842975;
    } else {
      sum += (double)12.41556664383437258;
    }
  } else {
    sum += (double)1041.210589192708312;
  }
  if ( UNLIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)165804.2865546218818) ) ) {
    if ( UNLIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1941.500000000000227) ) ) {
      sum += (double)-1406.855643310546839;
    } else {
      sum += (double)-377.6077430572510139;
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)8.500000000000001776) ) ) {
      sum += (double)144.8986417101325515;
    } else {
      sum += (double)-351.9647869256025388;
    }
  }
  if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)6.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1920.500000000000227) ) ) {
      sum += (double)-1183.400889892578334;
    } else {
      sum += (double)-40.8363796319826875;
    }
  } else {
    if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1.00000001800250948e-35) ) ) {
      sum += (double)107.2628004843188876;
    } else {
      sum += (double)713.4522237868536649;
    }
  }
  if ( LIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)888.5000000000001137) ) ) {
    if ( LIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)864.5000000000001137) ) ) {
      sum += (double)15.6206708796770446;
    } else {
      sum += (double)-1903.707285722096685;
    }
  } else {
    sum += (double)1232.698601074218914;
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)862.5000000000001137) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)735.5000000000001137) ) ) {
      sum += (double)-1171.681315185546964;
    } else {
      sum += (double)-347.7006565941704821;
    }
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)299.5000000000000568) ) ) {
      sum += (double)-139.4940708496328341;
    } else {
      sum += (double)187.3889339214807137;
    }
  }
  if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)5.500000000000000888) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)2007.500000000000227) ) ) {
      sum += (double)-179.7319617808948919;
    } else {
      sum += (double)913.4687541198732106;
    }
  } else {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1983.500000000000227) ) ) {
      sum += (double)116.3645416301570634;
    } else {
      sum += (double)1766.396240234375;
    }
  }
  if ( UNLIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)575.5000000000001137) ) ) {
    sum += (double)-1095.019001438306759;
  } else {
    if ( UNLIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)165804.2865546218818) ) ) {
      sum += (double)-573.2531807719797143;
    } else {
      sum += (double)69.61280159082944863;
    }
  }
  if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)141083.1214285714668) ) ) {
    if ( LIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)478.5000000000000568) ) ) {
      sum += (double)-190.1860509699041302;
    } else {
      sum += (double)-1243.979034893329299;
    }
  } else {
    if ( LIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)790.5000000000001137) ) ) {
      sum += (double)-8.253378042112078816;
    } else {
      sum += (double)622.5110011707653257;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)946.0000000000001137) ) ) {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)176588.0614047705021) ) ) {
      sum += (double)-269.9112637661471013;
    } else {
      sum += (double)-1159.904914370450115;
    }
  } else {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)5.500000000000000888) ) ) {
      sum += (double)-68.82301982606638546;
    } else {
      sum += (double)297.4736028421420428;
    }
  }
  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2721.000000000000455) ) ) {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)1.00000001800250948e-35) ) ) {
      sum += (double)-176.5324924064208858;
    } else {
      sum += (double)199.1336991928968985;
    }
  } else {
    sum += (double)1086.771064453125064;
  }
  if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1.500000000000000222) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1281.500000000000227) ) ) {
      sum += (double)-185.1515219801385399;
    } else {
      sum += (double)163.6091304660428705;
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1669.000000000000227) ) ) {
      sum += (double)-4.731218872070312997;
    } else {
      sum += (double)-1166.448397609165795;
    }
  }
  if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)6.500000000000000888) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1914.500000000000227) ) ) {
      sum += (double)-111.0176755672488866;
    } else {
      sum += (double)975.6142017505786725;
    }
  } else {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)176588.0614047705021) ) ) {
      sum += (double)522.7838206896707334;
    } else {
      sum += (double)-59.04191194859946989;
    }
  }
  if ( UNLIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)165804.2865546218818) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)425.5000000000000568) ) ) {
      sum += (double)-869.2169786406726644;
    } else {
      sum += (double)-81.34861729062836844;
    }
  } else {
    if ( UNLIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)159734.9453382438805) ) ) {
      sum += (double)-451.5282432242615869;
    } else {
      sum += (double)80.72647129424738921;
    }
  }
  if ( UNLIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)129170.4858116823452) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)5.500000000000000888) ) ) {
      sum += (double)136.3871966818104511;
    } else {
      sum += (double)-1972.810165223621198;
    }
  } else {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1964.000000000000227) ) ) {
      sum += (double)-10.50719482985502751;
    } else {
      sum += (double)2141.377290271577294;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)8.500000000000001776) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1914.500000000000227) ) ) {
      sum += (double)15.4873863574131363;
    } else {
      sum += (double)1967.3941650390625;
    }
  } else {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)1133.000000000000227) ) ) {
      sum += (double)-93.05119154575893958;
    } else {
      sum += (double)-2168.493574676513617;
    }
  }
  if ( LIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)876.0000000000001137) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)1399.000000000000227) ) ) {
      sum += (double)-10.11924469847943442;
    } else {
      sum += (double)1662.906000976562609;
    }
  } else {
    sum += (double)-835.7847506931850603;
  }
  if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)6.500000000000000888) ) ) {
    if ( LIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)228412.5459861776035) ) ) {
      sum += (double)-135.3033103854157275;
    } else {
      sum += (double)510.3630401243647157;
    }
  } else {
    if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)166712.5376623376796) ) ) {
      sum += (double)6.594475893766983177;
    } else {
      sum += (double)599.8733822566207436;
    }
  }
  if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)5.500000000000000888) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1531.000000000000227) ) ) {
      sum += (double)-327.0400508924801102;
    } else {
      sum += (double)1017.698989562988231;
    }
  } else {
    if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)1.500000000000000222) ) ) {
      sum += (double)1144.486229060246615;
    } else {
      sum += (double)48.24651530171372116;
    }
  }
  if ( UNLIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)165804.2865546218818) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)425.5000000000000568) ) ) {
      sum += (double)-770.0809022484756952;
    } else {
      sum += (double)-102.4307421585609177;
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)8.500000000000001776) ) ) {
      sum += (double)111.7723868217518088;
    } else {
      sum += (double)-280.9243548659027851;
    }
  }
  if ( UNLIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)662.0000000000001137) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1105.000000000000227) ) ) {
      sum += (double)-1082.628889973958394;
    } else {
      sum += (double)-188.3008845204892623;
    }
  } else {
    if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1.500000000000000222) ) ) {
      sum += (double)61.57952811717987629;
    } else {
      sum += (double)-570.8891487608565285;
    }
  }
  return sum;
}
