#include "header.h"
double predict_margin_unit3(union Entry* data) {
  double sum = (double)0;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)893.0000000000001137) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)770.5000000000001137) ) ) {
      sum += (double)-1266.619147391941397;
    } else {
      sum += (double)-439.9995714944506631;
    }
  } else {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)305.5000000000000568) ) ) {
      sum += (double)6.728788140221560354;
    } else {
      sum += (double)809.1742937360490942;
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)5962.500000000000909) ) ) {
    if ( UNLIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)155848.7128623188764) ) ) {
      sum += (double)-790.178044035940502;
    } else {
      sum += (double)-198.4457130546000485;
    }
  } else {
    if ( UNLIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)155650.5646912611264) ) ) {
      sum += (double)-239.6649549115088575;
    } else {
      sum += (double)194.8276515175232362;
    }
  }
  if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)160980.8845295330102) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)465.5000000000000568) ) ) {
      sum += (double)34.67358003813644984;
    } else {
      sum += (double)-1494.042759494781421;
    }
  } else {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)21143.00000000000364) ) ) {
      sum += (double)18.45227233762837216;
    } else {
      sum += (double)1331.37941402004617;
    }
  }
  if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)6.500000000000000888) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)2348.500000000000455) ) ) {
      sum += (double)-165.0259915441508269;
    } else {
      sum += (double)947.340813573201558;
    }
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1243.000000000000227) ) ) {
      sum += (double)-58.48987769883932941;
    } else {
      sum += (double)780.2798926001196378;
    }
  }
  if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2008.500000000000227) ) ) {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)302.5000000000000568) ) ) {
      sum += (double)-73.42835891944528726;
    } else {
      sum += (double)618.5045917455701101;
    }
  } else {
    sum += (double)1226.591123744419519;
  }
  if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1914.500000000000227) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1736.500000000000227) ) ) {
      sum += (double)-366.4830733906139244;
    } else {
      sum += (double)-1635.835654703776072;
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)234.5000000000000284) ) ) {
      sum += (double)77.12016703719137922;
    } else {
      sum += (double)-1498.378296479724668;
    }
  }
  if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1914.500000000000227) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)959.0000000000001137) ) ) {
      sum += (double)-500.8405533500339857;
    } else {
      sum += (double)-1332.7162939453126;
    }
  } else {
    if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)5.500000000000000888) ) ) {
      sum += (double)-118.9174630796320002;
    } else {
      sum += (double)320.2696357223121026;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)110.5000000000000142) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)2682.000000000000455) ) ) {
      sum += (double)-25.20268714963775381;
    } else {
      sum += (double)2858.480325244721826;
    }
  } else {
    sum += (double)-1147.78974294354839;
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1164.500000000000227) ) ) {
    if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1949.500000000000227) ) ) {
      sum += (double)-761.1011503036708064;
    } else {
      sum += (double)-127.047083271224551;
    }
  } else {
    if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1.500000000000000222) ) ) {
      sum += (double)1276.824235930266241;
    } else {
      sum += (double)67.63396404642455195;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)110.5000000000000142) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)100.5000000000000142) ) ) {
      sum += (double)-32.90235261788640031;
    } else {
      sum += (double)2463.31861391067514;
    }
  } else {
    sum += (double)-1041.790776615758205;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)56.50000000000000711) ) ) {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)164.0000000000000284) ) ) {
      sum += (double)-324.979039892676326;
    } else {
      sum += (double)1176.548563079833912;
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)234.5000000000000284) ) ) {
      sum += (double)184.9870832467079254;
    } else {
      sum += (double)-1538.993499832153248;
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1413.000000000000227) ) ) {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)226255.6283183528576) ) ) {
      sum += (double)-88.18825203796554035;
    } else {
      sum += (double)662.8685319947034031;
    }
  } else {
    sum += (double)1053.481175048828163;
  }
  if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)6.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1918.500000000000227) ) ) {
      sum += (double)-1445.072450608473673;
    } else {
      sum += (double)-45.94332842270129902;
    }
  } else {
    if ( UNLIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)189582.0075720566965) ) ) {
      sum += (double)-130.3134653060162691;
    } else {
      sum += (double)555.9479640260035467;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)110.5000000000000142) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1413.000000000000227) ) ) {
      sum += (double)-30.61165030042002044;
    } else {
      sum += (double)2538.070110022503286;
    }
  } else {
    sum += (double)-927.2108008600051789;
  }
  if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)160980.8845295330102) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)465.5000000000000568) ) ) {
      sum += (double)86.89257833546605525;
    } else {
      sum += (double)-1330.756623535156223;
    }
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1343.000000000000227) ) ) {
      sum += (double)-176.9883085028035055;
    } else {
      sum += (double)200.4229096652352382;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)98.50000000000001421) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1818.000000000000227) ) ) {
      sum += (double)-7.949557869967049051;
    } else {
      sum += (double)-1207.061382846174638;
    }
  } else {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)110.5000000000000142) ) ) {
      sum += (double)1711.129948902130309;
    } else {
      sum += (double)-842.2880197832661224;
    }
  }
  if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1912.500000000000227) ) ) {
    sum += (double)-802.0826142963610437;
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)241.5000000000000284) ) ) {
      sum += (double)61.2419082988718344;
    } else {
      sum += (double)-1427.902906227111998;
    }
  }
  if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)5.500000000000000888) ) ) {
    if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2007.500000000000227) ) ) {
      sum += (double)-188.5358220382206582;
    } else {
      sum += (double)739.3691215091281492;
    }
  } else {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)15549.50000000000182) ) ) {
      sum += (double)118.9848518804341921;
    } else {
      sum += (double)1461.269249674479397;
    }
  }
  if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)5.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1930.500000000000227) ) ) {
      sum += (double)-1079.327578457919117;
    } else {
      sum += (double)-69.87755716361873226;
    }
  } else {
    if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1982.500000000000227) ) ) {
      sum += (double)115.3655642651329458;
    } else {
      sum += (double)1491.933478037516352;
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)893.0000000000001137) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)764.5000000000001137) ) ) {
      sum += (double)-1143.132696838378934;
    } else {
      sum += (double)-318.1451667554451319;
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)475.0000000000000568) ) ) {
      sum += (double)247.7575661368074691;
    } else {
      sum += (double)-140.7565839996022703;
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)854.5000000000001137) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1931.000000000000227) ) ) {
      sum += (double)-16.90614193192049441;
    } else {
      sum += (double)2121.224996815557006;
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)888.5000000000001137) ) ) {
      sum += (double)-1905.593083586516286;
    } else {
      sum += (double)937.8741467285155977;
    }
  }
  if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)6.500000000000000888) ) ) {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)46.50000000000000711) ) ) {
      sum += (double)-255.8919275585370769;
    } else {
      sum += (double)222.3325910822137814;
    }
  } else {
    if ( UNLIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)189582.0075720566965) ) ) {
      sum += (double)-96.07718188801750614;
    } else {
      sum += (double)454.8543002641119983;
    }
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)221771.9065770973684) ) ) {
    if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1912.500000000000227) ) ) {
      sum += (double)-977.1828809102377136;
    } else {
      sum += (double)7.393592652116359965;
    }
  } else {
    sum += (double)761.1368650694151938;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)684.5000000000001137) ) ) {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)87.50000000000001421) ) ) {
      sum += (double)-9.536270453622263332;
    } else {
      sum += (double)-486.3509142684936819;
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)190.0000000000000284) ) ) {
      sum += (double)341.1028586817151904;
    } else {
      sum += (double)-1254.717472610473806;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)98.50000000000001421) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1818.000000000000227) ) ) {
      sum += (double)-1.345206518865588619;
    } else {
      sum += (double)-1197.668757997710145;
    }
  } else {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)110.5000000000000142) ) ) {
      sum += (double)1490.144720001220776;
    } else {
      sum += (double)-762.3583857874716614;
    }
  }
  return sum;
}
