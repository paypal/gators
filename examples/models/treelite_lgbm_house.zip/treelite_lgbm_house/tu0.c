#include "header.h"
double predict_margin_unit0(union Entry* data) {
  double sum = (double)0;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)2.500000000000000444) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1413.000000000000227) ) ) {
      sum += (double)176739.8455568905338;
    } else {
      sum += (double)183186.6504963057814;
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1316.500000000000227) ) ) {
      sum += (double)192611.2872620889393;
    } else {
      sum += (double)205709.8293522684835;
    }
  }
  if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)7.500000000000000888) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)6.500000000000000888) ) ) {
      sum += (double)-3918.162825550460184;
    } else {
      sum += (double)2528.591630761665328;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)8.500000000000001776) ) ) {
      sum += (double)8916.460540561018206;
    } else {
      sum += (double)18814.14424677309944;
    }
  }
  if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)2.500000000000000444) ) ) {
    if ( UNLIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1.500000000000000222) ) ) {
      sum += (double)-5073.606200283389626;
    } else {
      sum += (double)346.4389336778710344;
    }
  } else {
    if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)363.5000000000000568) ) ) {
      sum += (double)8173.410984925018056;
    } else {
      sum += (double)17289.61651367187369;
    }
  }
  if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)7.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)5.500000000000000888) ) ) {
      sum += (double)-4660.102359370723207;
    } else {
      sum += (double)268.8910118056220995;
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1968.500000000000227) ) ) {
      sum += (double)6222.925940604832249;
    } else {
      sum += (double)14641.44367745535965;
    }
  }
  if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1991.500000000000227) ) ) {
    if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)1.500000000000000222) ) ) {
      sum += (double)-3822.30581647087547;
    } else {
      sum += (double)-136.1322022999302703;
    }
  } else {
    if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)198.0000000000000284) ) ) {
      sum += (double)1523.061353697445156;
    } else {
      sum += (double)8879.974782492898157;
    }
  }
  if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1984.500000000000227) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1096.000000000000227) ) ) {
      sum += (double)-4244.868878794873126;
    } else {
      sum += (double)-23.83726200684598595;
    }
  } else {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1681.000000000000227) ) ) {
      sum += (double)2305.492301565008802;
    } else {
      sum += (double)12151.61446213942327;
    }
  }
  if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1984.500000000000227) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1136.500000000000227) ) ) {
      sum += (double)-3687.805926486902536;
    } else {
      sum += (double)227.2542103399232474;
    }
  } else {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1681.000000000000227) ) ) {
      sum += (double)2074.94307699842966;
    } else {
      sum += (double)10936.45301757812558;
    }
  }
  if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)7.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)168810.740448973258) ) ) {
      sum += (double)-3626.479903916784679;
    } else {
      sum += (double)120.6079468426436989;
    }
  } else {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)12092.50000000000182) ) ) {
      sum += (double)4731.797788534359825;
    } else {
      sum += (double)11215.81446037292517;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1800.500000000000227) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1307.000000000000227) ) ) {
      sum += (double)-2503.342620384462862;
    } else {
      sum += (double)1534.965946241866732;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)8.500000000000001776) ) ) {
      sum += (double)4232.415820062099556;
    } else {
      sum += (double)13221.06303571428725;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1819.000000000000227) ) ) {
    if ( UNLIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)168810.740448973258) ) ) {
      sum += (double)-3312.391989705532978;
    } else {
      sum += (double)-211.9373277751242028;
    }
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1391.500000000000227) ) ) {
      sum += (double)3081.554070102768492;
    } else {
      sum += (double)9196.24115478515705;
    }
  }
  if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)6.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)189582.0075720566965) ) ) {
      sum += (double)-3968.385497804788884;
    } else {
      sum += (double)-1382.201437842345058;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)8.500000000000001776) ) ) {
      sum += (double)2405.83283370261961;
    } else {
      sum += (double)9769.337623961075224;
    }
  }
  if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)2.500000000000000444) ) ) {
    if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)1.500000000000000222) ) ) {
      sum += (double)-2103.692431003146794;
    } else {
      sum += (double)578.1689545620693025;
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1316.500000000000227) ) ) {
      sum += (double)4022.215451968294929;
    } else {
      sum += (double)11462.00917154948002;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1928.500000000000227) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)6.500000000000000888) ) ) {
      sum += (double)-1874.105771408080955;
    } else {
      sum += (double)973.8777868652343841;
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)2650.000000000000455) ) ) {
      sum += (double)3655.860931239983984;
    } else {
      sum += (double)11228.40969050480817;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)2295.500000000000455) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1491.000000000000227) ) ) {
      sum += (double)-1825.228794004450947;
    } else {
      sum += (double)1174.633695628855548;
    }
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1521.000000000000227) ) ) {
      sum += (double)5642.275790824142859;
    } else {
      sum += (double)11804.60364990234484;
    }
  }
  if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)7.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)168810.740448973258) ) ) {
      sum += (double)-2280.599077289236448;
    } else {
      sum += (double)151.89607842775564;
    }
  } else {
    if ( LIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)9.500000000000001776) ) ) {
      sum += (double)3192.208015843144494;
    } else {
      sum += (double)10102.4859953703708;
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1111.000000000000227) ) ) {
    if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)1064.500000000000227) ) ) {
      sum += (double)-886.7816972966234061;
    } else {
      sum += (double)4178.436019764775665;
    }
  } else {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1853.000000000000227) ) ) {
      sum += (double)3804.479323628743714;
    } else {
      sum += (double)8872.565974934896076;
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)545.0000000000001137) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)12157.50000000000182) ) ) {
      sum += (double)-1458.489107565977065;
    } else {
      sum += (double)1500.975100900750476;
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1150.500000000000227) ) ) {
      sum += (double)1369.200150707887587;
    } else {
      sum += (double)5549.868655802409194;
    }
  }
  if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)6.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)4.500000000000000888) ) ) {
      sum += (double)-3513.896663065159373;
    } else {
      sum += (double)-848.1942811621165674;
    }
  } else {
    if ( LIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)9.500000000000001776) ) ) {
      sum += (double)1491.56339455829584;
    } else {
      sum += (double)7518.771761546415291;
    }
  }
  if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)6.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)151.0000000000000284) ) ) {
      sum += (double)-2585.372574951750721;
    } else {
      sum += (double)-385.8853011468810337;
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)939.5000000000001137) ) ) {
      sum += (double)880.4250900897916381;
    } else {
      sum += (double)4800.914772279800673;
    }
  }
  if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)7.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)5.500000000000000888) ) ) {
      sum += (double)-1631.026386349413315;
    } else {
      sum += (double)255.7866437541439382;
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1316.500000000000227) ) ) {
      sum += (double)2191.192567719194358;
    } else {
      sum += (double)6503.534897626679594;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)2295.500000000000455) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)791.0000000000001137) ) ) {
      sum += (double)-1999.999428932002502;
    } else {
      sum += (double)200.2956236543884643;
    }
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1501.500000000000227) ) ) {
      sum += (double)3628.189388183594019;
    } else {
      sum += (double)7856.256522042411234;
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)1986.500000000000227) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)649.5000000000001137) ) ) {
      sum += (double)-3815.749265289307004;
    } else {
      sum += (double)-901.5357243972326842;
    }
  } else {
    if ( LIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)9.500000000000001776) ) ) {
      sum += (double)680.4273752454837449;
    } else {
      sum += (double)5660.061628998650122;
    }
  }
  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1023.000000000000114) ) ) {
    if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)758.5000000000001137) ) ) {
      sum += (double)-1553.760875854295591;
    } else {
      sum += (double)424.1973525103401244;
    }
  } else {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1962.500000000000227) ) ) {
      sum += (double)841.6096243046699783;
    } else {
      sum += (double)5343.280465262277175;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1928.500000000000227) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1199.500000000000227) ) ) {
      sum += (double)-1476.61790836283717;
    } else {
      sum += (double)20.66345985795485518;
    }
  } else {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)12436.50000000000182) ) ) {
      sum += (double)1154.041344382546185;
    } else {
      sum += (double)4276.071037652757695;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)2295.500000000000455) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)299.5000000000000568) ) ) {
      sum += (double)-1213.391608677227623;
    } else {
      sum += (double)467.0948005215627177;
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)2682.000000000000455) ) ) {
      sum += (double)2713.26213521754471;
    } else {
      sum += (double)5656.429229736328125;
    }
  }
  return sum;
}
