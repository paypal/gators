#include "header.h"
double predict_margin_unit0(union Entry* data) {
  double sum = (double)0;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)7.500000000000000888) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)6.500000000000000888) ) ) {
      sum += (double)177530.0920368627994;
    } else {
      sum += (double)184376.4710597323428;
    }
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1968.500000000000227) ) ) {
      sum += (double)190091.452864514431;
    } else {
      sum += (double)199795.41060779072;
    }
  }
  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1544.000000000000227) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1154.500000000000227) ) ) {
      sum += (double)-5096.433785317160982;
    } else {
      sum += (double)75.65730946110744526;
    }
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2295.500000000000455) ) ) {
      sum += (double)3443.354178930528178;
    } else {
      sum += (double)14058.23161586708011;
    }
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.500000000000000444) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1982.500000000000227) ) ) {
      sum += (double)-3496.346408336871718;
    } else {
      sum += (double)1954.559688337722946;
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)272504.8927318728529) ) ) {
      sum += (double)8868.873463675901803;
    } else {
      sum += (double)20577.49194661458387;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)7.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)5.500000000000000888) ) ) {
      sum += (double)-4614.961457285920005;
    } else {
      sum += (double)203.7990089307289736;
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)8.500000000000001776) ) ) {
      sum += (double)7315.305898363837514;
    } else {
      sum += (double)16606.90157948369597;
    }
  }
  if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)1443.000000000000227) ) ) {
    if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)815.0000000000001137) ) ) {
      sum += (double)-3045.455909562111174;
    } else {
      sum += (double)3533.620208012082912;
    }
  } else {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)1336.000000000000227) ) ) {
      sum += (double)4650.517744997714544;
    } else {
      sum += (double)14655.68123918805941;
    }
  }
  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1819.000000000000227) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1315.000000000000227) ) ) {
      sum += (double)-2892.104548241682551;
    } else {
      sum += (double)2284.656392068302011;
    }
  } else {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)1225.000000000000227) ) ) {
      sum += (double)4703.404448499178216;
    } else {
      sum += (double)15711.86023667279551;
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)187577.5878299120523) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1415.000000000000227) ) ) {
      sum += (double)-3489.428760399481234;
    } else {
      sum += (double)-588.8073370974287855;
    }
  } else {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1627.500000000000227) ) ) {
      sum += (double)2277.631224915691746;
    } else {
      sum += (double)11105.28334582691605;
    }
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.500000000000000444) ) ) {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)176588.0614047705021) ) ) {
      sum += (double)-2686.192119059429388;
    } else {
      sum += (double)1182.056887509375883;
    }
  } else {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)271053.2338004672201) ) ) {
      sum += (double)5170.912568419656964;
    } else {
      sum += (double)12885.40001141092216;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)7.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)5.500000000000000888) ) ) {
      sum += (double)-3276.178562758618227;
    } else {
      sum += (double)240.890349460598884;
    }
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)9.500000000000001776) ) ) {
      sum += (double)5375.931635199653101;
    } else {
      sum += (double)13774.66979166666715;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)6.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)189582.0075720566965) ) ) {
      sum += (double)-4314.044306906675956;
    } else {
      sum += (double)-1404.300348213340158;
    }
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2295.500000000000455) ) ) {
      sum += (double)2298.87806029811054;
    } else {
      sum += (double)9713.468399200441127;
    }
  }
  if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)176588.0614047705021) ) ) {
    if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1.00000001800250948e-35) ) ) {
      sum += (double)-3135.728853244316269;
    } else {
      sum += (double)-508.5510228534077442;
    }
  } else {
    if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)1681.000000000000227) ) ) {
      sum += (double)1267.783620434042859;
    } else {
      sum += (double)8437.907603701385597;
    }
  }
  if ( LIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)602.5000000000001137) ) ) {
    if ( UNLIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)367.5000000000000568) ) ) {
      sum += (double)-2926.942215983073311;
    } else {
      sum += (double)-43.64684792689115511;
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)272504.8927318728529) ) ) {
      sum += (double)2845.603493555972818;
    } else {
      sum += (double)10415.36794433593786;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)7.500000000000000888) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)176222.4820081879443) ) ) {
      sum += (double)-1987.444506480392874;
    } else {
      sum += (double)648.3226579793295059;
    }
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)9.500000000000001776) ) ) {
      sum += (double)3825.124482512297618;
    } else {
      sum += (double)10498.91873553240839;
    }
  }
  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1782.500000000000227) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1029.500000000000227) ) ) {
      sum += (double)-2215.456756416527242;
    } else {
      sum += (double)300.5066877181271821;
    }
  } else {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1219.000000000000227) ) ) {
      sum += (double)1569.65364872817463;
    } else {
      sum += (double)6310.223051060267608;
    }
  }
  if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)176588.0614047705021) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)169.0000000000000284) ) ) {
      sum += (double)-3122.403974953083434;
    } else {
      sum += (double)-689.8002723461650021;
    }
  } else {
    if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)1681.000000000000227) ) ) {
      sum += (double)967.5198784265400036;
    } else {
      sum += (double)6275.291007624446138;
    }
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.500000000000000444) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.500000000000000222) ) ) {
      sum += (double)-2210.764245026020944;
    } else {
      sum += (double)254.9140615815737476;
    }
  } else {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)1316.500000000000227) ) ) {
      sum += (double)3140.206837211535003;
    } else {
      sum += (double)9481.873516845704216;
    }
  }
  if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1984.500000000000227) ) ) {
    if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)1096.000000000000227) ) ) {
      sum += (double)-2138.829313092090615;
    } else {
      sum += (double)153.7255626254611798;
    }
  } else {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)844.0000000000001137) ) ) {
      sum += (double)849.1719185105907854;
    } else {
      sum += (double)4573.610345126066022;
    }
  }
  if ( UNLIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1954.500000000000227) ) ) {
      sum += (double)-3575.92138087775129;
    } else {
      sum += (double)-983.8977586129699375;
    }
  } else {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.500000000000000444) ) ) {
      sum += (double)550.3561487659989098;
    } else {
      sum += (double)4379.323779950823337;
    }
  }
  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1919.500000000000227) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1199.500000000000227) ) ) {
      sum += (double)-1939.043561116275441;
    } else {
      sum += (double)-22.20137746280297364;
    }
  } else {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)271053.2338004672201) ) ) {
      sum += (double)2214.158469597069143;
    } else {
      sum += (double)6742.670869140625655;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)1111.000000000000227) ) ) {
    if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)1064.500000000000227) ) ) {
      sum += (double)-679.8818358440244083;
    } else {
      sum += (double)3239.568292899753942;
    }
  } else {
    if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)1853.000000000000227) ) ) {
      sum += (double)2738.777339640299488;
    } else {
      sum += (double)7320.010630580356519;
    }
  }
  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1928.500000000000227) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)685.0000000000001137) ) ) {
      sum += (double)-2718.554278495095332;
    } else {
      sum += (double)-195.9405810781791502;
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)8.500000000000001776) ) ) {
      sum += (double)1954.472972677907592;
    } else {
      sum += (double)7208.584673281069627;
    }
  }
  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1782.500000000000227) ) ) {
    if ( UNLIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1953.500000000000227) ) ) {
      sum += (double)-2122.343709564208893;
    } else {
      sum += (double)-117.3857989001494389;
    }
  } else {
    if ( LIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)228412.5459861776035) ) ) {
      sum += (double)1364.162786305008467;
    } else {
      sum += (double)5788.228883713942196;
    }
  }
  if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1986.500000000000227) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)223.5000000000000284) ) ) {
      sum += (double)-2508.296870134548044;
    } else {
      sum += (double)-493.9572634483451452;
    }
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2295.500000000000455) ) ) {
      sum += (double)506.5684610534260628;
    } else {
      sum += (double)4536.892892795139232;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)6.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)169.0000000000000284) ) ) {
      sum += (double)-1927.977513769475081;
    } else {
      sum += (double)-247.7482137116466845;
    }
  } else {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)939.5000000000001137) ) ) {
      sum += (double)604.5891235813950289;
    } else {
      sum += (double)3673.372722562154649;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)8.500000000000001776) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)687.5000000000001137) ) ) {
      sum += (double)-680.3109500029720493;
    } else {
      sum += (double)1172.928120261502727;
    }
  } else {
    if ( LIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)781.5000000000001137) ) ) {
      sum += (double)2940.238293457031432;
    } else {
      sum += (double)6304.038441162109848;
    }
  }
  return sum;
}
