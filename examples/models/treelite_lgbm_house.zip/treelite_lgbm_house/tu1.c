#include "header.h"
double predict_margin_unit1(union Entry* data) {
  double sum = (double)0;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)1986.500000000000227) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)223.5000000000000284) ) ) {
      sum += (double)-2213.462113724211576;
    } else {
      sum += (double)-378.1893416333554683;
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)769.5000000000001137) ) ) {
      sum += (double)213.3723587285110739;
    } else {
      sum += (double)2401.684657113763478;
    }
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)12157.50000000000182) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)649.5000000000001137) ) ) {
      sum += (double)-2374.590787661654304;
    } else {
      sum += (double)-183.3335477711109718;
    }
  } else {
    if ( LIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)9.500000000000001776) ) ) {
      sum += (double)1282.722562379103692;
    } else {
      sum += (double)5666.433192871094434;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1531.000000000000227) ) ) {
    if ( UNLIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1920.500000000000227) ) ) {
      sum += (double)-2644.518577100409857;
    } else {
      sum += (double)-560.4017098620106481;
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)687.5000000000001137) ) ) {
      sum += (double)315.0541506846745961;
    } else {
      sum += (double)2424.467546213785681;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1751.000000000000227) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)601.0000000000001137) ) ) {
      sum += (double)-2318.244377668280777;
    } else {
      sum += (double)-279.7455457941504733;
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)1979.500000000000227) ) ) {
      sum += (double)-964.5187122486255475;
    } else {
      sum += (double)2006.396127574865886;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)25.50000000000000355) ) ) {
    if ( UNLIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)3.500000000000000444) ) ) {
      sum += (double)-3947.760182407924276;
    } else {
      sum += (double)-614.5868831058583055;
    }
  } else {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1651.500000000000227) ) ) {
      sum += (double)362.9215393102911094;
    } else {
      sum += (double)2791.364982964010778;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)2295.500000000000455) ) ) {
    if ( UNLIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)155848.7128623188764) ) ) {
      sum += (double)-1658.989450841371763;
    } else {
      sum += (double)67.49649413402993048;
    }
  } else {
    if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)423.5000000000000568) ) ) {
      sum += (double)1795.284300740559956;
    } else {
      sum += (double)4496.983503524116713;
    }
  }
  if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2007.500000000000227) ) ) {
    if ( UNLIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)4.500000000000000888) ) ) {
      sum += (double)-2582.984514617920013;
    } else {
      sum += (double)13.49749817885418501;
    }
  } else {
    sum += (double)3570.485290857263408;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)1979.500000000000227) ) ) {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)193.0000000000000284) ) ) {
      sum += (double)-1038.249724194601413;
    } else {
      sum += (double)453.8659094024123419;
    }
  } else {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1362.500000000000227) ) ) {
      sum += (double)14.66233644091967214;
    } else {
      sum += (double)1483.800776743334609;
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)687.5000000000001137) ) ) {
    if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)4.500000000000000888) ) ) {
      sum += (double)-1938.896588025774463;
    } else {
      sum += (double)-182.6561865478573736;
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)804.0000000000001137) ) ) {
      sum += (double)732.9172812065470453;
    } else {
      sum += (double)3009.185581054687646;
    }
  }
  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1023.000000000000114) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)217.0000000000000284) ) ) {
      sum += (double)-1122.519963034372495;
    } else {
      sum += (double)-28.02117145762724348;
    }
  } else {
    if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)2007.500000000000227) ) ) {
      sum += (double)432.6575219811511488;
    } else {
      sum += (double)3843.263967063210657;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)26.50000000000000355) ) ) {
    if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)160980.8845295330102) ) ) {
      sum += (double)-1890.665523176051011;
    } else {
      sum += (double)-374.0525051107511558;
    }
  } else {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1651.500000000000227) ) ) {
      sum += (double)283.6389460967137666;
    } else {
      sum += (double)2129.460428855532427;
    }
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)12377.00000000000182) ) ) {
    if ( UNLIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1920.500000000000227) ) ) {
      sum += (double)-1869.885737912066588;
    } else {
      sum += (double)-138.4609548821002249;
    }
  } else {
    if ( LIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)9.500000000000001776) ) ) {
      sum += (double)928.1414513959142596;
    } else {
      sum += (double)4466.501169549851511;
    }
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)12377.00000000000182) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)6222.000000000000909) ) ) {
      sum += (double)-1285.093367978988226;
    } else {
      sum += (double)-36.41687854042109507;
    }
  } else {
    if ( LIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)9.500000000000001776) ) ) {
      sum += (double)835.3273129309009164;
    } else {
      sum += (double)4019.851072765532081;
    }
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)12799.00000000000182) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)1977.500000000000227) ) ) {
      sum += (double)-843.2161020659846145;
    } else {
      sum += (double)157.2182296537410195;
    }
  } else {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)313.5000000000000568) ) ) {
      sum += (double)821.5703144815233827;
    } else {
      sum += (double)3697.132937622070585;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1480.000000000000227) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)169.0000000000000284) ) ) {
      sum += (double)-1107.312097298105755;
    } else {
      sum += (double)-128.5487651924754289;
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)299.5000000000000568) ) ) {
      sum += (double)-158.0221399367665072;
    } else {
      sum += (double)1100.934293898096712;
    }
  }
  if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)160980.8845295330102) ) ) {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)734.0000000000001137) ) ) {
      sum += (double)-1155.798932820638129;
    } else {
      sum += (double)-2467.602959541653036;
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1942.000000000000227) ) ) {
      sum += (double)-89.40452490859075851;
    } else {
      sum += (double)1314.630052336698782;
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)7248.000000000000909) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1266.500000000000227) ) ) {
      sum += (double)-1009.63499603640048;
    } else {
      sum += (double)402.4602335248674763;
    }
  } else {
    if ( UNLIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)4.500000000000000888) ) ) {
      sum += (double)-1822.845485527570872;
    } else {
      sum += (double)371.1127863094370696;
    }
  }
  if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2007.500000000000227) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)20165.50000000000364) ) ) {
      sum += (double)-187.3323701613060166;
    } else {
      sum += (double)2321.538852341110669;
    }
  } else {
    sum += (double)2478.220300622888772;
  }
  if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2007.500000000000227) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)56.50000000000000711) ) ) {
      sum += (double)-662.1918453012588088;
    } else {
      sum += (double)229.4110175660332231;
    }
  } else {
    sum += (double)2230.398275509396171;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)2682.000000000000455) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)56.50000000000000711) ) ) {
      sum += (double)-632.431680253131276;
    } else {
      sum += (double)243.5864249567067645;
    }
  } else {
    sum += (double)2792.131545257568632;
  }
  if ( UNLIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1920.500000000000227) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)744.5000000000001137) ) ) {
      sum += (double)-2225.693255687895544;
    } else {
      sum += (double)-1113.144162120819146;
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)46.50000000000000711) ) ) {
      sum += (double)-204.3147731195113579;
    } else {
      sum += (double)659.4942967525309996;
    }
  }
  if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)160980.8845295330102) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)540.5000000000001137) ) ) {
      sum += (double)-862.9103716912209165;
    } else {
      sum += (double)-2633.087881324404862;
    }
  } else {
    if ( UNLIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)4.500000000000000888) ) ) {
      sum += (double)-1518.631703394109536;
    } else {
      sum += (double)214.2712942747636191;
    }
  }
  if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)160980.8845295330102) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1233.000000000000227) ) ) {
      sum += (double)-827.9303698254869914;
    } else {
      sum += (double)-2181.638614545549899;
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)865.0000000000001137) ) ) {
      sum += (double)-407.2995247968632384;
    } else {
      sum += (double)398.521056045544924;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)2348.500000000000455) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)137.0000000000000284) ) ) {
      sum += (double)-560.9229319556285418;
    } else {
      sum += (double)169.9012608668895155;
    }
  } else {
    if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1976.500000000000227) ) ) {
      sum += (double)11.51135742187500099;
    } else {
      sum += (double)2130.800624957614673;
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1345.500000000000227) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)770.5000000000001137) ) ) {
      sum += (double)-2175.707152258831684;
    } else {
      sum += (double)-344.7770812386214061;
    }
  } else {
    if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2007.500000000000227) ) ) {
      sum += (double)208.6558643614018536;
    } else {
      sum += (double)2233.772688598633067;
    }
  }
  return sum;
}
