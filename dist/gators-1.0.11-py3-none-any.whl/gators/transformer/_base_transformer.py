from pydantic import BaseModel, ConfigDict
from sklearn.base import BaseEstimator, TransformerMixin


class _BaseTransformer(BaseModel, BaseEstimator, TransformerMixin):
    """
    Base class for all transformers in the gators library.

    This class provides common functionality for all transformers.

    """

    model_config = ConfigDict(extra="forbid")

    def __init__(self, *args, **kwargs):
        """Initialize transformer with clear error message for positional arguments.
        
        Raises
        ------
        TypeError
            If positional arguments are provided instead of keyword arguments.
        """
        if args:
            raise TypeError(
                f"{self.__class__.__name__}() does not accept positional arguments. "
                "Use keyword arguments instead:\n"
                f"  {self.__class__.__name__}(param1=value1, param2=value2)  # Correct\n"
                f"  {self.__class__.__name__}(value1, value2)                # Wrong - raises this error"
            )
        super().__init__(**kwargs)
