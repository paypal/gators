# License: Apache-2.0
from ._base_imputer import _BaseImputer
from imputer import float_imputer_object
from imputer import float_imputer
from ..util import util
import numpy as np
from typing import List, Union
import pandas as pd
import databricks.koalas as ks


class NumericsImputer(_BaseImputer):
    """NUmerics imputer Transformer.

    Parameters
    ----------
    strategy : str
        Imputation strategy.
            Supported imputation strategies are:

            - 'constant'
            - 'mean'
            - 'median'

    value : str, default to None
        Imputation value used for `strategy=constant`.

    Examples
    ---------

    * fit & transform with pandas

    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.imputers import NumericsImputer
    >>> X = pd.DataFrame({'A': [0.1, 0.2, np.nan], 'B': ['z', 'a', 'a']})
    >>> obj = NumericsImputer(strategy='median')
    >>> obj.fit_transform(X)
        A  B
    0  0.10  z
    1  0.20  a
    2  0.15  a

    * fit & transform with koalas

    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.imputers import NumericsImputer
    >>> X = ks.DataFrame({'A': [0.1, 0.2, np.nan], 'B': ['z', 'a', 'a']})
    >>> obj = NumericsImputer(strategy='mean')
    >>> obj.fit_transform(X)
        A  B
    0  0.10  z
    1  0.20  a
    2  0.15  a

    * fit with pandas & transform with numpy

    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.imputers import NumericsImputer
    >>> X = pd.DataFrame({'A': [0.1, 0.2, np.nan], 'B': ['z', 'a', 'a']})
    >>> obj = NumericsImputer(strategy='mean')
    >>> obj.fit(X)
    obj.transform_numpy(X.to_numpy())
    array([[0.1, 'z'],
           [0.2, 'a'],
           [0.15000000000000002, 'a']], dtype=object)

    * fit with koalas & transform with numpy

    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.imputers import NumericsImputer
    >>> X = ks.DataFrame({'A': [0.1, 0.2, np.nan], 'B': ['z', 'a', 'a']})
    >>> obj = NumericsImputer(strategy='mean')
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[0.1, 'z'],
           [0.2, 'a'],
           [0.15000000000000002, 'a']], dtype=object)

    """

    def __init__(self, strategy: str,
                 value: float = None,
                 columns: List[str] = None):
        _BaseImputer.__init__(self, strategy, value, columns)
        if strategy not in ['constant', 'mean', 'median']:
            raise ValueError(
                '''`strategy` should be "constant", ,"mean"
                     or "median" for NumericsImputer Transformer.''')
        if strategy == 'constant' and not isinstance(value, float):
            raise TypeError(
                '''`value` should be a float
                for the NumericsImputer class''')

    def fit(self, X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'NumericsImputer':
        """Fit the transformer on the pandas/koalas dataframe X.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
        y None
            None.

        Returns
        -------
            'NumericsImputer': Instance of itself.
        """
        self.check_dataframe(X)
        if not self.columns:
            self.columns = util.get_datatype_columns(X, float)
        self.idx_columns = util.get_idx_columns(X.columns, self.columns)
        self.statistics = self.compute_statistics(
            X=X,
            columns=self.columns,
            strategy=self.strategy,
            value=self.value,
        )
        self.statistics_values = np.array(
            list(self.statistics.values()))
        return self

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """
        self.check_dataframe(X)
        if isinstance(X, pd.DataFrame):
            return X.fillna(self.statistics)
        for col, val in self.statistics.items():
            X[col] = X[col].replace({np.nan: val})
        return X

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy ndarray X.

        Parameters
        ----------
        X (np.ndarray): Input ndarray.

        Returns
        -------
        np.ndarray:
            Transformed numpy array.
        """
        self.check_array(X)
        if len(self.idx_columns) == 0:
            return X
        if X.dtype == object:
            return float_imputer_object(
                X,
                self.statistics_values.astype(object),
                self.idx_columns)
        return float_imputer(
            X,
            self.statistics_values,
            self.idx_columns)
