# License: Apache-2.0
from gators.feature_selection.select_from_model import SelectFromModel
from gators.transformer.transformer import Transformer
from sklearn.tree import DecisionTreeClassifier
from gators.pipeline.pipeline import Pipeline
from pandas.testing import assert_series_equal
from pandas.testing import assert_frame_equal
import pytest
import numpy as np
import pandas as pd


class MultiplyTransformer(Transformer):

    def __init__(self, multiplier):
        self.multiplier = multiplier

    def fit(self, X, y=None):
        return self

    def transform(self, X):

        return self.multiplier * X

    def transform_numpy(self,  X):
        return self.multiplier * X


class DropFirstColumnTransformer(Transformer):

    def __init__(self):
        pass

    def fit(self, X, y=None):
        return self

    def transform(self,  X):
        return X.drop(X.columns[0], axis=1)

    def transform_numpy(self,  X):
        return X[:, 1:]


@pytest.fixture
def pipeline_example():
    X = pd.DataFrame(
        [[1, 2, 3], [4, 5, 6], [7, 8, 9]],
        columns=['A', 'B', 'C'],
        dtype=float
    )
    steps = [
        MultiplyTransformer(2.),
        DropFirstColumnTransformer(),
        MultiplyTransformer(2.),
    ]

    pipe = Pipeline(steps)
    return pipe, X


@pytest.fixture
def pipeline_with_feature_selection_example():
    X = pd.DataFrame(
        [[1, 2, 3], [4, 5, 6], [7, 8, 9]],
        columns=['A', 'B', 'C'],
        dtype=float
    )
    y = pd.Series([1, 0, 1], name='TARGET')
    X_expected = pd.DataFrame({'B': {0: 8.0, 1: 20.0, 2: 32.0}})
    steps = [
        MultiplyTransformer(2.),
        DropFirstColumnTransformer(),
        MultiplyTransformer(2.),
        SelectFromModel(
            model=DecisionTreeClassifier(random_state=0),
            k=1)
    ]
    pipe = Pipeline(steps).fit(X, y)
    return pipe, X, X_expected


@pytest.fixture
def pipeline_with_model_example():
    X = pd.DataFrame(
        [[1, 2, 3], [4, 5, 6], [7, 8, 9]],
        columns=['A', 'B', 'C'],
        dtype=float
    )
    y = pd.Series([1, 0, 1], name='TARGET')
    steps = [
        MultiplyTransformer(2.),
        DropFirstColumnTransformer(),
        MultiplyTransformer(2.),
        DecisionTreeClassifier(random_state=0)
    ]

    pipe = Pipeline(steps).fit(X, y)
    return pipe, X


def test_pandas_pipeline_fit_and_transform(pipeline_example):
    pipe, X = pipeline_example
    _ = pipe.fit(X)
    X_new = pipe.transform(X)
    X_new_expected = pd.DataFrame(
        [[8, 12], [20, 24], [32, 36]],
        columns=['B', 'C'],
        dtype=float,
    )
    assert_frame_equal(X_new_expected, X_new)


def test_pandas_fit_transform_pipeline(pipeline_example):
    pipe, X = pipeline_example
    X_new = pipe.fit_transform(X)
    X_new_expected = pd.DataFrame(
        [[8, 12], [20, 24], [32, 36]],
        columns=['B', 'C'],
        dtype=float,
    )
    assert_frame_equal(X_new_expected, X_new)


def test_pipeline_predict_pandas(pipeline_with_model_example):
    pipe, X = pipeline_with_model_example
    y_pred = pipe.predict(X)
    assert y_pred.shape == (3, )


def test_pipeline_predict_proba_pandas(pipeline_with_model_example):
    pipe, X = pipeline_with_model_example
    y_pred = pipe.predict_proba(X)
    assert y_pred.shape == (3, 2)


def test_pipeline_numpy(pipeline_example):
    pipe, X = pipeline_example
    _ = pipe.fit(X)
    X_numpy_new = pipe.transform_numpy(X.to_numpy())
    X_numpy_new_expected = pd.DataFrame(
        [[8, 12], [20, 24], [32, 36]],
        columns=['B', 'C'],
        dtype=float,
    ).to_numpy()
    assert np.allclose(X_numpy_new_expected, X_numpy_new)


def test_pipeline_predict_numpy(pipeline_with_model_example):
    pipe, X = pipeline_with_model_example
    y_pred = pipe.predict_numpy(X.to_numpy())
    assert y_pred.shape == (3, )


def test_pipeline_predict_proba_numpy(pipeline_with_model_example):
    pipe, X = pipeline_with_model_example
    y_pred = pipe.predict_proba_numpy(X.to_numpy())
    assert y_pred.shape == (3, 2)


def test_default_fit_transform_pipeline(pipeline_example):
    pipe, X = pipeline_example
    X_new = pipe.fit_transform(X)
    X_new_expected = pd.DataFrame(
        [[8, 12], [20, 24], [32, 36]],
        columns=['B', 'C'],
        dtype=float,
    )
    assert_frame_equal(X_new_expected, X_new)


def test_init():
    with pytest.raises(TypeError):
        _ = Pipeline(0)
    with pytest.raises(TypeError):
        _ = Pipeline([])


def test_pipeline_transform_input_data(pipeline_example):
    pipe, X = pipeline_example
    _ = pipe.fit(X)
    with pytest.raises(TypeError):
        _ = pipe.transform(X.to_numpy())
    with pytest.raises(TypeError):
        _ = pipe.transform(X, X)
    with pytest.raises(TypeError):
        _ = pipe.transform_numpy(X)


def test_get_feature_importances(pipeline_with_feature_selection_example):
    pipe, _, _ = pipeline_with_feature_selection_example
    feature_importances_expected = pd.Series(
        {'B': 0.75, 'C': 0.24999999999999997})
    feature_importances = pipe.get_feature_importances(k=2)
    assert_series_equal(feature_importances, feature_importances_expected)


def test_clean_steps(pipeline_with_feature_selection_example):
    pipe, X, X_expected = pipeline_with_feature_selection_example
    X_new = pipe.transform(X)
    prod_steps, features = pipe.clean_steps()
    prod_pipe = Pipeline(steps=prod_steps)
    assert_frame_equal(X_new, X_expected)
    assert features == ['B']
