# License: Apache-2.0
from typing import List, Union
import copy
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..transformer.transformer import Transformer
from ..data_cleaning import KeepColumns


class Pipeline(Transformer):
    """Pipeline Transformer.

    Parameters
    ----------
    steps : List[Transformer]
        List of transformations.

    Examples
    ---------

    * fit & transform with pandas

    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.imputers import IntImputer
    >>> from gators.imputers import FloatImputer
    >>> from gators.imputers import ObjectImputer
    >>> from gators.pipeline import Pipeline
    >>> X = pd.DataFrame(
    ...     {'A': [0.1, 0.2, 0.3, np.nan],
    ...     {'B': [1, 2, 2, np.nan],
    ...     {'C': ['a', 'b', 'c', np.nan]})
    >>> steps = [
    ...     ObjectImputer(strategy='constant', value='MISSING'),
    ...     FloatImputer(strategy='median'),
    ...     IntImputer(strategy='most_frequent'),
    ... ]
    >>> obj = Pipeline(steps=steps)
    >>> obj.fit_transform(X)
        A    B        C
    0  0.1  1.0        a
    1  0.2  2.0        b
    2  0.3  2.0        c
    3  0.2  2.0  MISSING

    * fit & transform with koalas

    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.imputers import IntImputer
    >>> from gators.imputers import FloatImputer
    >>> from gators.imputers import ObjectImputer
    >>> from gators.pipeline import Pipeline
    >>> X = ks.DataFrame(
    ...     {'A': [0.1, 0.2, 0.3, np.nan],
    ...     {'B': [1, 2, 2, np.nan],
    ...     {'C': ['a', 'b', 'c', np.nan]})
    steps = [
            ObjectImputer(strategy='constant', value='MISSING'),
            FloatImputer(strategy='median'),
            IntImputer(strategy='most_frequent'),
    ]
    obj = Pipeline(steps=steps)
    obj.fit_transform(X)
    >>> steps = [
    ...     ObjectImputer(strategy='constant', value='MISSING'),
    ...     FloatImputer(strategy='median'),
    ...     IntImputer(strategy='most_frequent'),
    ... ]
    >>> obj = Pipeline(steps=steps)
    >>> obj.fit_transform(X)
        A    B        C
    0  0.1  1.0        a
    1  0.2  2.0        b
    2  0.3  2.0        c
    3  0.2  2.0  MISSING

    * fit with pandas & transform with numpy

    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.imputers import IntImputer
    >>> from gators.imputers import FloatImputer
    >>> from gators.imputers import ObjectImputer
    >>> from gators.pipeline import Pipeline
    >>> X = pd.DataFrame(
    ...     {'A': [0.1, 0.2, 0.3, np.nan],
    ...     {'B': [1, 2, 2, np.nan],
    ...     {'C': ['a', 'b', 'c', np.nan]})
    >>> steps = [
    ...     ObjectImputer(strategy='constant', value='MISSING'),
    ...     FloatImputer(strategy='median'),
    ...     IntImputer(strategy='most_frequent'),
    ... ]
    >>> obj = Pipeline(steps=steps)
    >>> _ = obj.fit(X)
    obj.transform_numpy(X.to_numpy())
    >>> obj.transform_numpy(X.to_numpy())
    array([[0.1, 1.0, 'a'],
           [0.2, 2.0, 'b'],
           [0.3, 2.0, 'c'],
           [0.2, 2.0, 'MISSING']], dtype=object)

    * fit with koalas & transform with numpy

    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.imputers import IntImputer
    >>> from gators.imputers import FloatImputer
    >>> from gators.imputers import ObjectImputer
    >>> from gators.pipeline import Pipeline
    >>> X = ks.DataFrame(
    ...     {'A': [0.1, 0.2, 0.3, np.nan],
    ...     {'B': [1, 2, 2, np.nan],
    ...     {'C': ['a', 'b', 'c', np.nan]})
    steps = [
            ObjectImputer(strategy='constant', value='MISSING'),
            FloatImputer(strategy='median'),
            IntImputer(strategy='most_frequent'),
    ]
    obj = Pipeline(steps=steps)
    _ = obj.fit(X)
    obj.transform_numpy(X.to_numpy())
    >>> steps = [
    ...     ObjectImputer(strategy='constant', value='MISSING'),
    ...     FloatImputer(strategy='median'),
    ...     IntImputer(strategy='most_frequent'),
    ... ]
    >>> obj = Pipeline(steps=steps)
    >>> _ = obj.fit(X)
    obj.transform_numpy(X.to_numpy())

    >>> obj.transform_numpy(X.to_numpy())
    array([[0.1, 1.0, 'a'],
           [0.2, 2.0, 'b'],
           [0.3, 2.0, 'c'],
           [0.2, 2.0, 'MISSING']], dtype=object)

    """

    def __init__(self, steps: List[Transformer]):
        if not isinstance(steps, list):
            raise TypeError('`steps` should be a list.')
        if not steps:
            raise TypeError('`steps` should be an empty list.')
        self.steps = steps
        self.is_model = hasattr(self.steps[-1], 'predict')
        self.n_steps = len(self.steps)
        self.n_transformations = self.n_steps - 1 if self.is_model else self.n_steps

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'Pipeline':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
        y None
            None.

        Returns
        -------
        Pipeline
            Instance of itself.
        """
        self.base_columns = list(X.columns)
        for step in self.steps[:self.n_transformations]:
            step = step.fit(X, y)
            X = step.transform(X)
        if self.is_model:
            _ = self.steps[-1].fit(X, y)
        return self

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """
        self.check_dataframe(X)
        for step in self.steps[:self.n_transformations]:
            X = step.transform(X)
        return X

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        for step in self.steps[:self.n_transformations]:
            X = step.transform_numpy(X)
        return X

    def fit_transform(self,
                      X: Union[pd.DataFrame, ks.DataFrame],
                      y: Union[pd.Series, ks.Series] = None
                      ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Fit and transform the pandas dataframe.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed pandas dataframe.
        """
        self.base_columns = list(X.columns).copy()
        # import time
        for step in self.steps[:self.n_transformations]:
            # to = time.time()
            step = step.fit(X, y)
            # print('FIT', step.__class__.__name__, time.time() - to)
            # to = time.time()
            X = step.transform(X)
            # print('TRANSFORM', step.__class__.__name__, time.time() - to)
        return X

    def predict(self,
                X: Union[pd.DataFrame, ks.DataFrame],
                y: Union[pd.Series, ks.Series] = None) -> np.ndarray:
        """Predict on X, and predict.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.

        Returns
        -------
        np.ndarray
            Model predictions.
        """
        for step in self.steps[:-1]:
            X = step.transform(X)
        return self.steps[-1].predict(X)

    def predict_proba(self,
                      X: Union[pd.DataFrame, ks.DataFrame],
                      y: np.array = None) -> np.ndarray:
        """Predict on X, and return the probability of success.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.

        Returns
        -------
        np.ndarray
            Model probabilities of success.
        """
        for step in self.steps[:-1]:
            X = step.transform(X)
        return self.steps[-1].predict_proba(X)

    def predict_numpy(self,
                      X: np.ndarray,
                      y: Union[pd.Series, ks.Series] = None
                      ) -> np.ndarray:
        """Predict on X, and predict.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.

        Returns
        -------
        np.ndarray
            Model predictions.
        """
        for step in self.steps[:-1]:
            X = step.transform_numpy(X)
        return self.steps[-1].predict(X)

    def predict_proba_numpy(self,
                            X: np.ndarray) -> np.ndarray:
        """Predict on X, and return the probability of success.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Model probabilities of success.
        """
        for step in self.steps[:-1]:
            X = step.transform_numpy(X)
        return self.steps[-1].predict_proba(X)

    def clean_steps(self):

        has_feature_importances_ = hasattr(
            self.steps[-1], 'feature_importances_')
        if not has_feature_importances_:
            raise ValueError(
                '''The last step of the pipeline should contains
                the atrribute `feature_importances_`''')
        features = self.steps[-1].selected_columns

        def flatten_column(columns):
            colums_flatten = []
            for i, col in enumerate(columns):
                if isinstance(col, str):
                    colums_flatten.append(col)
                else:
                    colums_flatten += col
            return colums_flatten

        steps_ = []
        n_steps = len(steps_) - 1
        base_columns_ = features.copy()
        for step in self.steps[:n_steps][::-1]:
            if hasattr(step, 'column_names'):
                is_used = False
                for i, col in enumerate(base_columns_):
                    if col in step.column_mapping:
                        base_columns_[i] = step.column_mapping[col]
                        base_columns_ = flatten_column(base_columns_)
                        is_used = True
                if is_used:
                    steps_.append(copy.copy(step))
            else:
                steps_.append(copy.copy(step))
        base_columns_ = list(set(base_columns_))
        prod_columns = [
            c for c in self.base_columns
            if c in base_columns_]
        steps_ = steps_[::-1]
        # clean DropColumns
        for step in steps_:
            if hasattr(step, 'columns') and hasattr(step, 'column_names'):
                print()
                print(step.__class__.__name__)
                print(step.column_mapping)
                column_mapping_vals = list(step.column_mapping.values())
                print(column_mapping_vals)
                if isinstance(column_mapping_vals[0], list):
                    column_mapping_vals = [
                        c for l in column_mapping_vals
                        for c in l]
                column_mapping_vals = list(
                    set(list(column_mapping_vals)))
                if len(column_mapping_vals) != len(step.column_names):
                    continue
                print('self.base_columns', self.base_columns)
                idx = [
                    i for i, c in enumerate(step.columns)
                    if (c in self.base_columns and c in prod_columns)
                    or (c not in self.base_columns)]
                [
                    print(c not in self.base_columns) for i, c in enumerate(step.columns)
                ]
                print('A', step.columns)
                step.columns = [
                    c for i, c in enumerate(step.columns) if i in idx]
                print('B', step.columns)
                step.column_names = [
                    c for i, c in enumerate(step.column_names) if i in idx]
            if step.__class__.__name__ == 'DropColumns':
                step.columns_to_drop = [
                    c for c in step.columns_to_drop
                    if c in self.base_columns and c in prod_columns]
        steps_.append(KeepColumns(columns_to_keep=features))
        return steps_, prod_columns

    def get_feature_importances(self, k: int) -> pd.Series:
        """Get the feature importances of the pipeline.

        Parameters
        ----------
        k int
            Number of top features to return.
        Returns
        -------
        pd.Series
            Feature importances.
        """
        if not hasattr(self.steps[-1], 'feature_importances_'):
            raise AttributeError(
                '''The last step of the pipeline should have
                 the attribute `feature_importances_`''')
        feature_importances_ = self.steps[-1].feature_importances_
        return feature_importances_.sort_values(ascending=False).iloc[:k]

    def get_features(self, k: int) -> List[str]:
        """Get the feature importances of the pipeline.

        Parameters
        ----------
        k int
            Number of top features to return.
        Returns
        -------
        List[str]
            List of features.
        """
        return list(self.get_feature_importances(k=k).index)

    def get_production_columns(self):
        has_feature_importances_ = hasattr(
            self.steps[-1], 'feature_importances_')
        if not has_feature_importances_:
            raise ValueError(
                '''The last step of the pipeline should contains
                the atrribute `feature_importances_`''')
        features = self.steps[-1].selected_columns

        def flatten_column(columns):
            colums_flatten = []
            for i, col in enumerate(columns):
                if isinstance(col, str):
                    colums_flatten.append(col)
                else:
                    colums_flatten += col
            return colums_flatten

        base_columns_ = features.copy()
        for step in self.steps[::-1]:
            if not hasattr(step, 'column_names'):
                continue
            for i, col in enumerate(base_columns_):
                if col in step.column_mapping:
                    base_columns_[i] = step.column_mapping[col]
            base_columns_ = list(set(flatten_column(base_columns_)))
        base_columns_ = list(set(base_columns_))
        prod_columns = [
            c for c in self.base_columns
            if c in base_columns_]
        return prod_columns

    def clean_steps_new(self):
        has_feature_importances_ = hasattr(
            self.steps[-1], 'feature_importances_')
        if not has_feature_importances_:
            raise ValueError(
                '''The last step of the pipeline should contains
                the atrribute `feature_importances_`''')
        features = self.steps[-1].selected_columns
        steps = copy.deepcopy(self.steps[:-1])

        def flatten_column(columns):
            colums_flatten = []
            for i, col in enumerate(columns):
                if isinstance(col, str):
                    colums_flatten.append(col)
                else:
                    colums_flatten += col
            return colums_flatten

        def get_prod_columns(steps, columns):
            base_columns_ = features.copy()
            for step in steps[::-1]:
                if not hasattr(step, 'column_names'):
                    continue
                for i, col in enumerate(base_columns_):
                    if col in step.column_mapping:
                        base_columns_[i] = step.column_mapping[col]
                base_columns_ = list(set(flatten_column(base_columns_)))
            base_columns_ = list(set(base_columns_))
            prod_columns = [
                c for c in self.base_columns
                if c in base_columns_]
            return prod_columns

        def get_used_columns(steps, features):
            columns_ = features.copy()
            used_columns = []
            for step in steps[::-1]:
                if not hasattr(step, 'column_names'):
                    continue
                for i, col in enumerate(columns_):
                    if col in step.column_mapping:
                        columns_[i] = step.column_mapping[col]
                columns_ = list(set(flatten_column(columns_)))
                used_columns.extend(columns_)
            return sorted(list(set(used_columns)))

        def clean_steps_columns(steps, used_columns):
            for step in steps:
                print(step.__class__.__name__)
                print(step.columns)
                if not hasattr(step, 'column_names'):
                    continue
                n_cols = len(step.columns)
                n_names = len(step.column_names)
                print('old columns', step.columns)
                print('old names', step.column_names)
                print('old mapping', step.column_mapping)
                if n_cols == n_names:
                    for i, (c, n) in enumerate(
                            zip(step.columns[::-1], step.column_names[::-1])):
                        print(-i - 1)
                        if n not in used_columns:
                            step.columns.pop(n_cols - i - 1)
                            step.column_names.pop(n_cols - i - 1)
                elif n_cols < n_names:
                    n_names_per_column = n_names // n_cols
                    for i, c in enumerate(step.columns[::-1]):
                        j_min = n_names - (i+1) * n_names_per_column
                        j_max = n_names - i * n_names_per_column
                        z = sum(
                            [n in used_columns
                             for n in step.column_names[j_min: j_max]])
                        if z == 0:
                            step.columns.pop(n_cols - i - 1)
                            [step.column_names.pop(n_cols - i - 1 - k)
                             for k in range(n_names_per_column)]
                        # for j, n in enumerate(step.column_names[j_min: j_max]):
                        #     if n not in used_columns:
                        #         step.columns.pop(-i - 1)
                        #         step.column_names.pop(-i - 1)

                else:
                    n_names_per_column = n_names // n_cols
                    for i, c in enumerate(step.columns[::-1]):
                        j_min = n_names - (i+1) * n_names_per_column
                        j_max = n_names - i * n_names_per_column
                        z = sum(
                            [n in used_columns
                             for n in step.column_names[j_min: j_max]])
                        if z == 0:
                            step.columns.pop(n_cols - i - 1)
                            [step.column_names.pop(n_cols - i - 1 - k)
                             for k in range(n_names_per_column)]
                print('new', step.columns)
                print('new', step.column_names)
                print('new', step.column_mapping)
                print()

        print(features)
        used_columns = get_used_columns(steps, features)
        print('used_columns', used_columns)
        prod_columns = get_prod_columns(steps, features)
        # print(prod_columns)
        steps = clean_steps_columns(steps, used_columns)
        # steps_ = steps_[::-1]
        # # clean DropColumns
        # for step in steps_:
        #     if hasattr(step, 'columns') and hasattr(step, 'column_names'):
        #         print()
        #         print(step.__class__.__name__)
        #         print(step.column_mapping)
        #         column_mapping_vals = list(step.column_mapping.values())
        #         print(column_mapping_vals)
        #         if isinstance(column_mapping_vals[0], list):
        #             column_mapping_vals = [
        #                 c for l in column_mapping_vals
        #                 for c in l]
        #         column_mapping_vals = list(
        #             set(list(column_mapping_vals)))
        #         if len(column_mapping_vals) != len(step.column_names):
        #             continue
        #         print('self.base_columns', self.base_columns)
        #         idx = [
        #             i for i, c in enumerate(step.columns)
        #             if (c in self.base_columns and c in prod_columns)
        #             or (c not in self.base_columns)]
        #         [
        #             print(c not in self.base_columns) for i, c in enumerate(step.columns)
        #         ]
        #         print('A', step.columns)
        #         step.columns = [
        #             c for i, c in enumerate(step.columns) if i in idx]
        #         print('B', step.columns)
        #         step.column_names = [
        #             c for i, c in enumerate(step.column_names) if i in idx]
        #     if step.__class__.__name__ == 'DropColumns':
        #         step.columns_to_drop = [
        #             c for c in step.columns_to_drop
        #             if c in self.base_columns and c in prod_columns]
        # steps_.append(KeepColumns(columns_to_keep=features))
        return 0, prod_columns
