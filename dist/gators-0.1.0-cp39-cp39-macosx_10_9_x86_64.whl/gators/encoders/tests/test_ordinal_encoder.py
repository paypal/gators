# License: Apache-2.0
from gators.encoders import OrdinalEncoder
from pandas.testing import assert_frame_equal
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    X = pd.DataFrame(
        {
            'A': ['Q', 'Q', 'W'],
            'B': ['Q', 'W', 'W'],
            'C': ['W', 'Q', 'W'],
            'D': [1, 2, 3]
        })
    X_expected = pd.DataFrame(
        [[1.0, 1.0, 0.0, 1.0],
         [1.0, 0.0, 1.0, 2.0],
         [0.0, 0.0, 0.0, 3.0]],
        columns=list('ABCD'),
    )
    X_ks = ks.from_pandas(X)
    obj_pd = OrdinalEncoder().fit(X)
    obj_ks = OrdinalEncoder().fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_no_cat():
    X = pd.DataFrame(
        np.zeros((3, 3)),
        columns=list('ABC'),
    )
    X_ks = ks.from_pandas(X)
    obj_pd = OrdinalEncoder().fit(X)
    obj_ks = OrdinalEncoder().fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X.copy()


def test_pd(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy = X.to_numpy()
    X_numpy_new = obj_pd.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


####

def test_no_cat_pd(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_no_cat_ks(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_no_cat_pd_np(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_numpy = X.to_numpy()
    X_numpy_new = obj_pd.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_no_cat_ks_np(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


@pytest.fixture
def test_check_nans():
    X = pd.DataFrame(
        {
            'A': [None, 'Q', 'W'],
            'B': ['Q', 'W', 'W'],
            'C': ['W', 'Q', 'W'],
            'D': [1, 2, 3]
        })
    with pytest.raises(ValueError):
        _ = OrdinalEncoder().fit(X)
