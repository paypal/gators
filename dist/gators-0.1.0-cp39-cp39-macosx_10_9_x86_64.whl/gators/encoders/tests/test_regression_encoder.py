# License: Apache-2.0
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
from gators.encoders import TargetEncoder
from gators.encoders import RegressionEncoder
from gators.binning import QuantileDiscretizer
from pandas.testing import assert_frame_equal
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    n_bins = 3
    X = pd.DataFrame({
        'A': ['Q', 'Q', 'Q', 'W', 'W', 'W'],
        'B': ['Q', 'Q', 'W', 'W', 'W', 'W'],
        'C': ['Q', 'Q', 'Q', 'Q', 'W', 'W'],
        'D': [1, 2, 3, 4, 5, 6]
    })
    y = pd.Series([0.11,  -0.1, 5.55, 233.9, 4.66, 255.1], name='TARGET')
    X_ks = ks.from_pandas(X)
    y_ks = ks.from_pandas(y)
    obj_pd = RegressionEncoder(
        TargetEncoder(), discretizer=QuantileDiscretizer(n_bins)
    ).fit(X, y)
    obj_ks = RegressionEncoder(
        TargetEncoder(), discretizer=QuantileDiscretizer(n_bins)
    ).fit(X_ks, y_ks)
    X_expected = pd.DataFrame(
        {
            'A': {0: 1.6666666666666667,
                  1: 1.6666666666666667,
                  2: 1.6666666666666667,
                  3: 164.0,
                  4: 164.0,
                  5: 164.0},
            'B': {0: 0.0, 1: 0.0, 2: 124.25, 3: 124.25, 4: 124.25, 5: 124.25},
            'C': {0: 59.5, 1: 59.5, 2: 59.5, 3: 59.5, 4: 129.5, 5: 129.5},
            'D': {0: 1.0, 1: 2.0, 2: 3.0, 3: 4.0, 4: 5.0, 5: 6.0}
        }
    )
    return obj_pd, obj_ks, X, X_ks, X_expected


@ pytest.fixture
def data_no_cat():
    n_bins = 2
    X = pd.DataFrame(
        np.zeros((3, 6)),
        columns=list('qweasd'),
    )
    X_ks = ks.from_pandas(X)
    y = pd.Series([1., 2., 0.], name='TARGET')
    y_ks = ks.from_pandas(y)
    discretizer = QuantileDiscretizer(n_bins)
    obj_pd = RegressionEncoder(
        TargetEncoder(), discretizer=discretizer).fit(X, y)
    obj_ks = RegressionEncoder(
        TargetEncoder(), discretizer=discretizer).fit(X_ks, y_ks)
    return obj_pd, obj_ks, X, X_ks, X.copy()


def test_pd(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy = X.to_numpy()
    X_numpy_new = obj_pd.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


# ####

def test_without_cat_pd(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_without_cat_ks(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_without_cat_pd_np(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_numpy = X.to_numpy()
    X_numpy_new = obj_pd.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_without_cat_ks_np(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


def test_init():
    with pytest.raises(TypeError):
        _ = RegressionEncoder(
            encoder='q', discretizer=QuantileDiscretizer(n_nbins=2))
        _ = RegressionEncoder(
            encoder=TargetEncoder(), discretizer='q')
