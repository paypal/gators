# License: Apache-2.0
from gators.encoders.target_encoder import TargetEncoder
from pandas.testing import assert_frame_equal
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    X = pd.DataFrame(
        {
            'A': ['Q', 'Q', 'Q', 'W', 'W', 'W'],
            'B': ['Q', 'Q', 'W', 'W', 'W', 'W'],
            'C': ['Q', 'Q', 'Q', 'Q', 'W', 'W'],
            'D': [1, 2, 3, 4, 5, 6]
        })
    X_ks = ks.from_pandas(X)
    y = pd.Series([0, 0, 0, 1, 1, 0], name='TARGET')
    y_ks = ks.from_pandas(y)
    X_expected = pd.DataFrame(
        {
            'A': {0: 0.0,
                  1: 0.0,
                  2: 0.0,
                  3: 0.6666666666666666,
                  4: 0.6666666666666666,
                  5: 0.6666666666666666},
            'B': {0: 0.0, 1: 0.0, 2: 0.5, 3: 0.5, 4: 0.5, 5: 0.5},
            'C': {0: 0.25, 1: 0.25, 2: 0.25, 3: 0.25, 4: 0.5, 5: 0.5},
            'D': {0: 1.0, 1: 2.0, 2: 3.0, 3: 4.0, 4: 5.0, 5: 6.0}
        }
    )
    obj_pd = TargetEncoder().fit(X, y)
    obj_ks = TargetEncoder().fit(X_ks, y_ks)
    return obj_pd, obj_ks, X, X_expected


@pytest.fixture
def data_no_cat():
    X = pd.DataFrame(
        np.zeros((6, 3)),
        columns=list('ABC'),
    )
    X_ks = ks.from_pandas(X)
    y = pd.Series([0, 0, 0, 1, 1, 0], name='TARGET')
    y_ks = ks.from_pandas(y)
    obj_pd = TargetEncoder().fit(X, y)
    obj_ks = TargetEncoder().fit(X_ks, y_ks)
    return obj_pd, obj_ks, X, X.copy()


def test_pd(data):
    obj_pd, obj_ks, X, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_expected = data
    X = ks.from_pandas(X)
    X_new = obj_ks.transform(X)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_expected = data
    X_numpy = X.to_numpy()
    X_numpy_new = obj_pd.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_expected = data
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


def test_no_cat_pd(data_no_cat):
    obj_pd, obj_ks, X, X_expected = data_no_cat
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_no_cat_ks(data_no_cat):
    obj_pd, obj_ks, X, X_expected = data_no_cat
    X = ks.from_pandas(X)
    X_new = obj_ks.transform(X)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_no_cat_pd_np(data_no_cat):
    obj_pd, obj_ks, X, X_expected = data_no_cat
    X_numpy = X.to_numpy()
    X_numpy_new = obj_pd.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_no_cat_ks_np(data_no_cat):
    obj_pd, obj_ks, X, X_expected = data_no_cat
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


def test_fit_input(data):
    obj_pd, _, X, _ = data
    with pytest.raises(TypeError):
        _ = obj_pd.fit(X, pd.Series(list('abcdefg')))
