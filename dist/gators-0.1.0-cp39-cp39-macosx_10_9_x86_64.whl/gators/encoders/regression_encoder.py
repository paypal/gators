# License: Apache-2.0
from .onehot_encoder import OneHotEncoder
from ._base_encoder import _BaseEncoder
from ..data_cleaning import DropColumns
from ..binning._base_discretizer import _BaseDiscretizer
from ..transformer import Transformer
from ..util import util
import numpy as np
from typing import List, Union
import copy
import pandas as pd
import databricks.koalas as ks


class RegressionEncoder(_BaseEncoder):
    """Encode all the categorical columns with an encoder given by the user.

    The encoding is composed in 2 steps:
    * bin the target values using the discretizer passed as argument.
    * apply the encoder on the discretized target values.

    Parameters
    ----------
    encoder : Transformer.
        Encoder.
    discretizer: Transformer.
        Discretizer.

    Examples
    --------

    * fit & transform with pandas

    >>> import pandas as pd
    >>> from gators.binning import QuantileDiscretizer
    >>> from gators.encoders import TargetEncoder
    >>> from gators.encoders import RegressionEncoder
    >>> X = pd.DataFrame({
    ...     'A': ['Q', 'Q', 'Q', 'W', 'W', 'W'],
    ...     'B': ['Q', 'Q', 'W', 'W', 'W', 'W'],
    ...     'C': ['Q', 'Q', 'Q', 'Q', 'W', 'W'],
    ...     'D': [1, 2, 3, 4, 5, 6]})
    >>> y = pd.Series([0.11,  -0.1, 5.55, 233.9, 4.66, 255.1], name='TARGET')
    >>> obj = RegressionEncoder(
    ... enncoder=TargetEncoder(),
    ... discretizer=QuantileDiscretizer(n_bins=3))
    >>> obj.fit_transform(X)
        A	        B	    C	    D
    0	1.666667	0.00	59.5	1.0
    1	1.666667	0.00	59.5	2.0
    2	1.666667	124.25	59.5	3.0
    3	164.000000	124.25	59.5	4.0
    4	164.000000	124.25	129.5	5.0
    5	164.000000	124.25	129.5	6.0

    * fit & transform with koalas

    >>> from gators.binning import QuantileDiscretizer
    >>> from gators.encoders import TargetEncoder
    >>> from gators.encoders import RegressionEncoder
    >>> X = ks.DataFrame({
    ...     'A': ['Q', 'Q', 'Q', 'W', 'W', 'W'],
    ...     'B': ['Q', 'Q', 'W', 'W', 'W', 'W'],
    ...     'C': ['Q', 'Q', 'Q', 'Q', 'W', 'W'],
    ...     'D': [1, 2, 3, 4, 5, 6]})
    >>> y = ks.Series([0.11,  -0.1, 5.55, 233.9, 4.66, 255.1], name='TARGET')
    >>> obj = RegressionEncoder(
    ... enncoder=TargetEncoder(),
    ... discretizer=QuantileDiscretizer(n_bins=3))
    >>> obj.fit_transform(X)
        A	        B	    C	    D
    0	1.666667	0.00	59.5	1.0
    1	1.666667	0.00	59.5	2.0
    2	1.666667	124.25	59.5	3.0
    3	164.000000	124.25	59.5	4.0
    4	164.000000	124.25	129.5	5.0
    5	164.000000	124.25	129.5	6.0

    * fit with pandas & transform with numpy

    >>> from gators.binning import QuantileDiscretizer
    >>> from gators.encoders import TargetEncoder
    >>> from gators.encoders import RegressionEncoder
    >>> X = pd.DataFrame({
    ...     'A': ['Q', 'Q', 'Q', 'W', 'W', 'W'],
    ...     'B': ['Q', 'Q', 'W', 'W', 'W', 'W'],
    ...     'C': ['Q', 'Q', 'Q', 'Q', 'W', 'W'],
    ...     'D': [1, 2, 3, 4, 5, 6]})
    >>> y = pd.Series([0.11,  -0.1, 5.55, 233.9, 4.66, 255.1], name='TARGET')
    >>> obj = RegressionEncoder(
    ... enncoder=TargetEncoder(),
    ... discretizer=QuantileDiscretizer(n_bins=3))
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[  1.66666667,   0.        ,  59.5       ,   1.        ],
           [  1.66666667,   0.        ,  59.5       ,   2.        ],
           [  1.66666667, 124.25      ,  59.5       ,   3.        ],
           [164.        , 124.25      ,  59.5       ,   4.        ],
           [164.        , 124.25      , 129.5       ,   5.        ],
           [164.        , 124.25      , 129.5       ,   6.        ]])

    * fit with koalas & transform with numpy

    >>> import databricks.koalas as ks
    >>> from gators.binning import QuantileDiscretizer
    >>> from gators.encoders import TargetEncoder
    >>> from gators.encoders import RegressionEncoder
    >>> X = ks.DataFrame({
    ...     'A': ['Q', 'Q', 'Q', 'W', 'W', 'W'],
    ...     'B': ['Q', 'Q', 'W', 'W', 'W', 'W'],
    ...     'C': ['Q', 'Q', 'Q', 'Q', 'W', 'W'],
    ...     'D': [1, 2, 3, 4, 5, 6]})
    >>> y = ks.Series([0.11,  -0.1, 5.55, 233.9, 4.66, 255.1], name='TARGET')
    >>> obj = RegressionEncoder(
    ... enncoder=TargetEncoder(),
    ... discretizer=QuantileDiscretizer(n_bins=3))
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[  1.66666667,   0.        ,  59.5       ,   1.        ],
           [  1.66666667,   0.        ,  59.5       ,   2.        ],
           [  1.66666667, 124.25      ,  59.5       ,   3.        ],
           [164.        , 124.25      ,  59.5       ,   4.        ],
           [164.        , 124.25      , 129.5       ,   5.        ],
           [164.        , 124.25      , 129.5       ,   6.        ]])
    """

    def __init__(self, encoder: Transformer, discretizer: Transformer):
        if not isinstance(discretizer, _BaseDiscretizer):
            raise TypeError(
                '`discretizer` should inherit from _BaseDiscretizer.')
        if not isinstance(encoder, Transformer):
            raise TypeError('`encoder` should inherit from _BaseEncoder.')

        self.encoder = encoder
        self.discretizer = discretizer
        self.one_hot_encoder = OneHotEncoder()
        self.drop_columns = None
        self.label_names = []
        self.encoder_dict = {}
        self.columns = []
        self.idx_columns: np.ndarray = None
        self.name = type(encoder).__name__

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series]) -> 'RegressionEncoder':
        """Fit the transformer on the dataframe `X`.
        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None.
            Labels.
        Returns
        -------
        RegressionEncoder
            Instance of itself.
        """
        self.check_dataframe(X)
        self.check_y(X, y)
        self.check_y_dtype(y, float)
        self.columns = util.get_datatype_columns(X, object)
        self.check_nans(X, self.columns)
        self.drop_columns = DropColumns(self.columns).fit(X)
        if not self.columns:
            self.idx_columns = np.array([])
            return self
        self.idx_columns = util.get_idx_columns(
            columns=X.columns,
            selected_columns=self.columns,
        )
        y_name = y.name
        y_binned = self.discretizer.fit_transform(y.to_frame())
        self.encoder.fit(X, y_binned[y_name].astype(float).astype(int))
        return self

    def transform(self,
                  X: Union[pd.DataFrame, ks.DataFrame]
                  ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.
        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """
        self.check_dataframe(X)
        if len(self.columns) == 0:
            return X
        return self.encoder.transform(X)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.
        Parameters
        ----------
        X  : np.ndarray
            Input array.
        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        if len(self.idx_columns) == 0:
            return X
        return self.encoder.transform_numpy(X)
