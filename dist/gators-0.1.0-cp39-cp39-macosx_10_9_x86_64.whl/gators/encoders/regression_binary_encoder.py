# License: Apache-2.0
from .onehot_encoder import OneHotEncoder
from .multiclass_binary_encoder import MultiClassBinaryEncoder
from ._base_encoder import _BaseEncoder
from ..data_cleaning import DropColumns
from ..transformer import Transformer
from ..util import util
import numpy as np
from typing import Union
import copy
import pandas as pd
import databricks.koalas as ks


class RegressionBinaryEncoder(_BaseEncoder):
    """Encode all the categorical columns with a binary encoder given by the user.

    The encoding is composed in 2 steps:
    * bin the target values using the discretizer passed as argument.
    * apply the `MultiClassBinaryEncoder` on the discretized target values.

    Parameters
    ----------
    encoder : Transformer.
        Encoder.
    discretizer: Transformer.
        Discretizer.

    Examples
    --------

    * fit & transform with pandas

    >>> import pandas as pd
    >>> from gators.binning import QuantileDiscretizer
    >>> from gators.encoders import WOEEncoder
    >>> from gators.encoders import RegressionEncoder
    >>> X = pd.DataFrame({
    ... 'A': ['Q', 'Q', 'Q', 'W', 'W', 'W'],
    ... 'B': ['Q', 'Q', 'W', 'W', 'W', 'W'],
    ... 'C': ['Q', 'Q', 'Q', 'Q', 'W', 'W'],
    ... 'D': [1, 2, 3, 4, 5, 6]})
    >>> y = pd.Series([0.11,  -0.1, 5.55, 233.9, 4.66, 255.1], name='TARGET')
    >>> obj = RegressionBinaryEncoder(
    ... encoder=WOEEncoder(),
    ... discretizer=QuantileDiscretizer(n_bins=n_bins, inplace=True)))
    >>> obj.fit_transform(X)
        D	A__TARGET_1_WOEEncoder	B__TARGET_1_WOEEncoder	C__TARGET_1_WOEEncoder	A__TARGET_2_WOEEncoder	B__TARGET_2_WOEEncoder	C__TARGET_2_WOEEncoder
    0	1.0	0.0	                    0.000000	            -0.405465	            0.000000	            0.000000	            -0.405465
    1	2.0	0.0	                    0.000000	            -0.405465	            0.000000	            0.000000	            -0.405465
    2	3.0	0.0	                    0.693147	            -0.405465	            0.000000	            0.693147	            -0.405465
    3	4.0	0.0	                    0.693147	            -0.405465	            1.386294	            0.693147	            -0.405465
    4	5.0	0.0	                    0.693147	            0.693147	            1.386294	            0.693147	            0.693147
    5	6.0	0.0	                    0.693147	            0.693147	            1.386294	            0.693147	            0.693147
    * fit & transform with koalas

    >>> import databricks.koalas as ks
    >>> from gators.binning import QuantileDiscretizer
    >>> from gators.encoders import WOEEncoder
    >>> from gators.encoders import RegressionEncoder
    >>> X = ks.DataFrame({
    ... 'A': ['Q', 'Q', 'Q', 'W', 'W', 'W'],
    ... 'B': ['Q', 'Q', 'W', 'W', 'W', 'W'],
    ... 'C': ['Q', 'Q', 'Q', 'Q', 'W', 'W'],
    ... 'D': [1, 2, 3, 4, 5, 6]})
    >>> obj = RegressionBinaryEncoder(
    ... encoder=WOEEncoder(),
    ... discretizer=QuantileDiscretizer(n_bins=n_bins, inplace=True))
    >>> obj.fit_transform(X)
        D	A__TARGET_1_WOEEncoder	B__TARGET_1_WOEEncoder	C__TARGET_1_WOEEncoder	A__TARGET_2_WOEEncoder	B__TARGET_2_WOEEncoder	C__TARGET_2_WOEEncoder
    0	1.0	0.0	                    0.000000	            -0.405465	            0.000000	            0.000000	            -0.405465
    1	2.0	0.0	                    0.000000	            -0.405465	            0.000000	            0.000000	            -0.405465
    2	3.0	0.0	                    0.693147	            -0.405465	            0.000000	            0.693147	            -0.405465
    3	4.0	0.0	                    0.693147	            -0.405465	            1.386294	            0.693147	            -0.405465
    4	5.0	0.0	                    0.693147	            0.693147	            1.386294	            0.693147	            0.693147
    5	6.0	0.0	                    0.693147	            0.693147	            1.386294	            0.693147	            0.693147

    * fit with pandas & transform with numpy

    >>> import pandas as pd
    >>> from gators.binning import QuantileDiscretizer
    >>> from gators.encoders import WOEEncoder
    >>> from gators.encoders import RegressionEncoder
    >>> X = pd.DataFrame({
    ... 'A': ['Q', 'Q', 'Q', 'W', 'W', 'W'],
    ... 'B': ['Q', 'Q', 'W', 'W', 'W', 'W'],
    ... 'C': ['Q', 'Q', 'Q', 'Q', 'W', 'W'],
    ... 'D': [1, 2, 3, 4, 5, 6]})
    >>> obj = RegressionBinaryEncoder(
    ... encoder=WOEEncoder(),
    ... discretizer=QuantileDiscretizer(n_bins=n_bins, inplace=True))
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[ 1.        ,  0.        ,  0.        , -0.40546511,  0.        ,
             0.        , -0.40546511],
           [ 2.        ,  0.        ,  0.        , -0.40546511,  0.        ,
             0.        , -0.40546511],
           [ 3.        ,  0.        ,  0.69314718, -0.40546511,  0.        ,
             0.69314718, -0.40546511],
           [ 4.        ,  0.        ,  0.69314718, -0.40546511,  1.38629436,
             0.69314718, -0.40546511],
           [ 5.        ,  0.        ,  0.69314718,  0.69314718,  1.38629436,
             0.69314718,  0.69314718],
           [ 6.        ,  0.        ,  0.69314718,  0.69314718,  1.38629436,
             0.69314718,  0.69314718]])

    * fit with koalas & transform with numpy

    >>> import databricks.koalas as ks
    >>> from gators.binning import QuantileDiscretizer
    >>> from gators.encoders import WOEEncoder
    >>> from gators.encoders import RegressionEncoder
    >>> X = ks.DataFrame({
    ... 'A': ['Q', 'Q', 'Q', 'W', 'W', 'W'],
    ... 'B': ['Q', 'Q', 'W', 'W', 'W', 'W'],
    ... 'C': ['Q', 'Q', 'Q', 'Q', 'W', 'W'],
    ... 'D': [1, 2, 3, 4, 5, 6]})
    >>> obj = RegressionBinaryEncoder(
    ... encoder=WOEEncoder(),
    ... discretizer=QuantileDiscretizer(n_bins=n_bins, inplace=True))
    >>> obj.transform_numpy(X.to_numpy())
    array([[ 1.        ,  0.        ,  0.        , -0.40546511,  0.        ,
             0.        , -0.40546511],
           [ 2.        ,  0.        ,  0.        , -0.40546511,  0.        ,
             0.        , -0.40546511],
           [ 3.        ,  0.        ,  0.69314718, -0.40546511,  0.        ,
             0.69314718, -0.40546511],
           [ 4.        ,  0.        ,  0.69314718, -0.40546511,  1.38629436,
             0.69314718, -0.40546511],
           [ 5.        ,  0.        ,  0.69314718,  0.69314718,  1.38629436,
             0.69314718,  0.69314718],
           [ 6.        ,  0.        ,  0.69314718,  0.69314718,  1.38629436,
             0.69314718,  0.69314718]])

    """

    def __init__(self, encoder: Transformer, discretizer: Transformer):
        if not isinstance(discretizer, Transformer):
            raise TypeError(
                '`discretizer` should inherit from _BaseDiscretizer.')
        if not isinstance(encoder, Transformer):
            raise TypeError('`encoder` should be a transformer.')

        self.discretizer = discretizer
        self.multiclass_binary_encoder = MultiClassBinaryEncoder(
            encoder=encoder)

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series]) -> 'RegressionBinaryEncoder':
        """Fit the transformer on the dataframe `X`.
        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None.
            Labels.
        Returns
        -------
        RegressionBinaryEncoder
            Instance of itself.
        """
        y_binned = self.discretizer.fit_transform(y.to_frame())
        self.multiclass_binary_encoder.fit(
            X, y_binned[y.name].astype(float).astype(int))
        return self

    def transform(self,
                  X: Union[pd.DataFrame, ks.DataFrame]
                  ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.
        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """
        return self.multiclass_binary_encoder.transform(X)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.
        Parameters
        ----------
        X  : np.ndarray
            Input array.
        Returns
        -------
        np.ndarray
            Transformed array.
        """
        return self.multiclass_binary_encoder.transform_numpy(X)
