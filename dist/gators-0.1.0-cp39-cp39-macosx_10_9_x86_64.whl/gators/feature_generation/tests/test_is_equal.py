# License: Apache-2.0
from gators.feature_generation.is_equal import IsEqual
from pandas.testing import assert_frame_equal
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    X = pd.DataFrame(
        {'A': [99., 1., 2.],
         'B': [99., 4., 5.],
         'C': [99., 7., 8.]})
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(
        {'A': [99., 1., 2.],
         'B': [99., 4., 5.],
         'C': [99., 7., 8.],
         'A__is__B': [1., 0., 0.],
         'A__is__C': [1., 0., 0.]})
    obj_pd = IsEqual(columns_a=list('AA'),  columns_b=list('BC')).fit(X)
    obj_ks = IsEqual(columns_a=list('AA'),  columns_b=list('BC')).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_names():
    X = pd.DataFrame(
        {'A': [99., 1., 2.],
         'B': [99., 4., 5.],
         'C': [99., 7., 8.]})
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(
        {'A': [99., 1., 2.],
         'B': [99., 4., 5.],
         'C': [99., 7., 8.],
         'A==B': [1., 0., 0.],
         'A==C': [1., 0., 0.]})
    obj_pd = IsEqual(columns_a=list('AA'),  columns_b=list('BC'),
                     column_names=['A==B', 'A==C']).fit(X)
    obj_ks = IsEqual(columns_a=list('AA'),  columns_b=list('BC'),
                     column_names=['A==B', 'A==C']).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


def test_pd(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values.astype(np.float64))
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values.astype(np.float64))
    assert_frame_equal(X_new, X_expected)


def test_names_pd(data_names):
    obj_pd, obj_ks, X, X_ks, X_expected = data_names
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_names_ks(data_names):
    obj_pd, obj_ks, X, X_ks, X_expected = data_names
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_names_pd_np(data_names):
    obj_pd, obj_ks, X, X_ks, X_expected = data_names
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values.astype(np.float64))
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_names_ks_np(data_names):
    obj_pd, obj_ks, X, X_ks, X_expected = data_names
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values.astype(np.float64))
    assert_frame_equal(X_new, X_expected)


def test_input():
    with pytest.raises(TypeError):
        _ = IsEqual(columns_a=0, columns_b=['B'])
    with pytest.raises(TypeError):
        _ = IsEqual(columns_a=['A'], columns_b=0)
    with pytest.raises(TypeError):
        _ = IsEqual(columns_a=['A'], columns_b=['B'], column_names=0)
    with pytest.raises(ValueError):
        _ = IsEqual(columns_a=['A'], columns_b=['B', 'C'])
    with pytest.raises(ValueError):
        _ = IsEqual(columns_a=['A'], columns_b=['B'], column_names=['x', 'y'])
    with pytest.raises(ValueError):
        _ = IsEqual(columns_a=[], columns_b=[])
