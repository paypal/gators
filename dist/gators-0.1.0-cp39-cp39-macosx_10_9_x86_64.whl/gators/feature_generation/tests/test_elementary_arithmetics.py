# License: Apache-2.0
import pytest
from gators.feature_generation.elementary_arithmethics import (
    ElementaryArithmetics
)
from pandas.testing import assert_frame_equal
import numpy as np
import pandas as pd
import databricks.koalas as ks


@pytest.fixture
def data_add():
    X = pd.DataFrame(np.arange(9).reshape(
        3, 3), columns=list('ABC'), dtype=np.float64)
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(np.array(
        [[0.,  1.,  2., -2., -4.],
         [3.,  4.,  5., -5., -7.],
         [6.,  7.,  8., -8., -10.]]),
        columns=['A',  'B',  'C',  'A__-__B',  'A__-__C']
    )
    obj_pd = ElementaryArithmetics(
        columns_a=list('AA'),  columns_b=list('BC'), coef=-2., operator='+'
    ).fit(X)
    obj_ks = ElementaryArithmetics(
        columns_a=list('AA'),  columns_b=list('BC'), coef=-2., operator='+'
    ).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_name_add():
    X = pd.DataFrame(np.arange(9).reshape(
        3, 3), columns=list('ABC'), dtype=np.float64)
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(np.array(
        [[0.,  1.,  2., -2., -4.],
         [3.,  4.,  5., -5., -7.],
         [6.,  7.,  8., -8., -10.]]),
        columns=['A',  'B',  'C',  'A+B',  'A+C']
    )
    obj_pd = ElementaryArithmetics(
        columns_a=list('AA'),  columns_b=list('BC'), coef=-2., operator='+',
        column_names=['A+B',  'A+C']

    ).fit(X)
    obj_ks = ElementaryArithmetics(
        columns_a=list('AA'),  columns_b=list('BC'), coef=-2., operator='+',
        column_names=['A+B',  'A+C']
    ).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_mult():
    X = pd.DataFrame(np.arange(9).reshape(
        3, 3), columns=list('ABC'), dtype=np.float64)
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(np.array(
        [[0.,  1.,  2.,  0.,  0.],
         [3.,  4.,  5., 12., 15.],
         [6.,  7.,  8., 42., 48.]]),
        columns=['A',  'B',  'C',  'A__*__B',  'A__*__C']
    )
    obj_pd = ElementaryArithmetics(
        columns_a=list('AA'),  columns_b=list('BC'), operator='*'
    ).fit(X)
    obj_ks = ElementaryArithmetics(
        columns_a=list('AA'),  columns_b=list('BC'), operator='*'
    ).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_div():
    X = pd.DataFrame(np.arange(9).reshape(
        3, 3), columns=list('ABC'), dtype=np.float64)
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(np.array(
        [[0., 1., 2., 0., 0],
         [3., 4., 5., 0.75, 0.59999988],
         [6., 7., 8., 0.85714286, 0.7499999]]),
        columns=['A',  'B',  'C',  'A__/__B',  'A__/__C']
    )
    obj_pd = ElementaryArithmetics(
        columns_a=list('AA'),  columns_b=list('BC'), operator='/'
    ).fit(X)
    obj_ks = ElementaryArithmetics(
        columns_a=list('AA'),  columns_b=list('BC'), operator='/'
    ).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


def test_add_pd(data_add):
    obj_pd, obj_ks, X, X_ks, X_expected = data_add
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_add_ks(data_add):
    obj_pd, obj_ks, X, X_ks, X_expected = data_add
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_add_pd_np(data_add):
    obj_pd, obj_ks, X, X_ks, X_expected = data_add
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_add_ks_np(data_add):
    obj_pd, obj_ks, X, X_ks, X_expected = data_add
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)

# #


def test_mult_pd(data_mult):
    obj_pd, obj_ks, X, X_ks, X_expected = data_mult
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_mult_ks(data_mult):
    obj_pd, obj_ks, X, X_ks, X_expected = data_mult
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_mult_pd_np(data_mult):
    obj_pd, obj_ks, X, X_ks, X_expected = data_mult
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_mult_ks_np(data_mult):
    obj_pd, obj_ks, X, X_ks, X_expected = data_mult
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


def test_div_pd(data_div):
    obj_pd, obj_ks, X, X_ks, X_expected = data_div
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_div_ks(data_div):
    obj_pd, obj_ks, X, X_ks, X_expected = data_div
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_div_pd_np(data_div):
    obj_pd, obj_ks, X, X_ks, X_expected = data_div
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_div_ks_np(data_div):
    obj_pd, obj_ks, X, X_ks, X_expected = data_div
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


def test_name_add_pd(data_name_add):
    obj_pd, obj_ks, X, X_ks, X_expected = data_name_add
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_name_add_ks(data_name_add):
    obj_pd, obj_ks, X, X_ks, X_expected = data_name_add
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_name_add_pd_np(data_name_add):
    obj_pd, obj_ks, X, X_ks, X_expected = data_name_add
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_name_add_ks_np(data_name_add):
    obj_pd, obj_ks, X, X_ks, X_expected = data_name_add
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)
