import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
from pandas.testing import assert_frame_equal
from gators.feature_generation.polynomial_features import PolynomialFeatures
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data_inter():
    X = pd.DataFrame(np.arange(9).reshape(
        3, 3), columns=list('ABC'), dtype=np.float64)
    X_ks = ks.from_pandas(X)
    obj_pd = PolynomialFeatures(
        interaction_only=True, columns=['A', 'B', 'C']).fit(X)
    obj_ks = PolynomialFeatures(
        interaction_only=True, columns=['A', 'B', 'C']).fit(X_ks)
    X_expected = pd.DataFrame(np.array(
        [[0., 1., 2., 0., 0., 2.],
         [3., 4., 5., 12., 15., 20.],
         [6., 7., 8., 42., 48., 56.]]),
        columns=['A', 'B', 'C', 'A__x__B', 'A__x__C', 'B__x__C']
    )
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_all():
    X = pd.DataFrame(np.arange(9).reshape(
        3, 3), columns=list('ABC'), dtype=np.float64)
    X_ks = ks.from_pandas(X)
    obj_pd = PolynomialFeatures(
        interaction_only=False, columns=['A', 'B', 'C']).fit(X)
    obj_ks = PolynomialFeatures(interaction_only=False, columns=[
                                'A', 'B', 'C']).fit(X_ks)
    X_expected = pd.DataFrame(np.array(
        [[0., 1., 2., 0., 0., 0., 1., 2., 4.],
         [3., 4., 5., 9., 12., 15., 16., 20., 25.],
         [6., 7., 8., 36., 42., 48., 49., 56., 64.]]),
        columns=['A', 'B', 'C', 'A__x__A', 'A__x__B',
                 'A__x__C', 'B__x__B', 'B__x__C', 'C__x__C']
    )
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_degree():
    X = pd.DataFrame(np.arange(9).reshape(
        3, 3), columns=list('ABC'), dtype=np.float64)
    X_ks = ks.from_pandas(X)
    obj_pd = PolynomialFeatures(
        interaction_only=False, degree=3, columns=['A', 'B', 'C']).fit(X)
    obj_ks = PolynomialFeatures(interaction_only=False, degree=3, columns=[
                                'A', 'B', 'C']).fit(X_ks)
    X_expected = pd.DataFrame(np.array(
        [[0., 1., 2., 0., 0., 0., 1., 2., 4., 0., 0.,
            0., 0., 0., 0., 1., 2., 4., 8.],
         [3., 4., 5., 9., 12., 15., 16., 20., 25., 27., 36.,
            45., 48., 60., 75., 64., 80., 100., 125.],
         [6., 7., 8., 36., 42., 48., 49., 56., 64., 216., 252.,
            288., 294., 336., 384., 343., 392., 448., 512.]]),
        columns=['A', 'B', 'C', 'A__x__A', 'A__x__B', 'A__x__C', 'B__x__B', 'B__x__C', 'C__x__C',
                 'A__x__A__x__A', 'A__x__A__x__B', 'A__x__A__x__C', 'A__x__B__x__B', 'A__x__B__x__C',
                 'A__x__C__x__C', 'B__x__B__x__B', 'B__x__B__x__C', 'B__x__C__x__C', 'C__x__C__x__C']
    )
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_inter_degree():
    X = pd.DataFrame(np.arange(9).reshape(
        3, 3), columns=list('ABC'), dtype=np.float64)
    X_ks = ks.from_pandas(X)
    obj_pd = PolynomialFeatures(
        interaction_only=True, degree=3, columns=['A', 'B', 'C']).fit(X)
    obj_ks = PolynomialFeatures(interaction_only=True, degree=3, columns=[
                                'A', 'B', 'C']).fit(X_ks)
    X_expected = pd.DataFrame(np.array(
        [[0., 1., 2., 0., 0., 2., 0.],
         [3., 4., 5., 12., 15., 20., 60.],
         [6., 7., 8., 42., 48., 56., 336.]]),
        columns=['A', 'B', 'C', 'A__x__B',
                 'A__x__C', 'B__x__C', 'A__x__B__x__C']
    )
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_subset():
    X = pd.DataFrame(np.arange(12).reshape(
        3, 4), columns=list('ABCD'), dtype=np.float64)
    X_ks = ks.from_pandas(X)
    obj_pd = PolynomialFeatures(
        columns=['A', 'B', 'D'], interaction_only=True, degree=2).fit(X)
    obj_ks = PolynomialFeatures(
        columns=['A', 'B', 'D'], interaction_only=True, degree=2).fit(X_ks)
    X_expected = pd.DataFrame(np.array(
        [[0., 1., 2., 3., 0., 0., 3.],
         [4., 5., 6., 7., 20., 28., 35.],
         [8., 9., 10., 11., 72., 88., 99.]]),
        columns=['A', 'B', 'C', 'D', 'A__x__B', 'A__x__D', 'B__x__D']
    )
    return obj_pd, obj_ks, X, X_ks, X_expected


def test_inter_pd(data_inter):
    obj_pd, obj_ks, X, X_k, X_expected = data_inter
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_inter_ks(data_inter):
    obj_pd, obj_ks, X, X_ks, X_expected = data_inter
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_inter_pd_np(data_inter):
    obj_pd, obj_ks, X, X_ks, X_expected = data_inter
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_inter_ks_np(data_inter):
    obj_pd, obj_ks, X, X_ks, X_expected = data_inter
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


def test_all_pd(data_all):
    obj_pd, obj_ks, X, X_k, X_expected = data_all
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_all_ks(data_all):
    obj_pd, obj_ks, X, X_ks, X_expected = data_all
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_all_pd_np(data_all):
    obj_pd, obj_ks, X, X_ks, X_expected = data_all
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_all_ks_np(data_all):
    obj_pd, obj_ks, X, X_ks, X_expected = data_all
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


def test_degree_pd(data_degree):
    obj_pd, obj_ks, X, X_k, X_expected = data_degree
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_degree_ks(data_degree):
    obj_pd, obj_ks, X, X_ks, X_expected = data_degree
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_degree_pd_np(data_degree):
    obj_pd, obj_ks, X, X_ks, X_expected = data_degree
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_degree_ks_np(data_degree):
    obj_pd, obj_ks, X, X_ks, X_expected = data_degree
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


def test_inter_degree_pd(data_inter_degree):
    obj_pd, obj_ks, X, X_k, X_expected = data_inter_degree
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_inter_degree_ks(data_inter_degree):
    obj_pd, obj_ks, X, X_ks, X_expected = data_inter_degree
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_inter_degree_pd_np(data_inter_degree):
    obj_pd, obj_ks, X, X_ks, X_expected = data_inter_degree
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_inter_degree_ks_np(data_inter_degree):
    obj_pd, obj_ks, X, X_ks, X_expected = data_inter_degree
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


def test_subset_pd(data_subset):
    obj_pd, obj_ks, X, X_k, X_expected = data_subset
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_subset_ks(data_subset):
    obj_pd, obj_ks, X, X_ks, X_expected = data_subset
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_subset_pd_np(data_subset):
    obj_pd, obj_ks, X, X_ks, X_expected = data_subset
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_subset_ks_np(data_subset):
    obj_pd, obj_ks, X, X_ks, X_expected = data_subset
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)
