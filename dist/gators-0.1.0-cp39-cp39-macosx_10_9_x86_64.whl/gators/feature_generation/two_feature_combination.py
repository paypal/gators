# License: Apache-2.0
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ..transformer.transformer import Transformer


def get_idx_columns_in_selected_columns(
        columns: List[str], selected_columns: List[str]) -> np.ndarray:
    """Get the indices of the columns used for the combination.

    Parameters
    ----------
    columns : List[str]
        List of columns.
    selected_columns : List[str]
        List of columns.

    Returns:
    np.ndarray
        Array of indices.
    """
    idx = []
    for selected_column in selected_columns:
        for i, column in enumerate(columns):
            if column == selected_column:
                idx.append(i)
                break
    return np.array(idx)


def compute_X_combination_numpy(
        X: np.ndarray,
        idx_columns_a: np.ndarray,
        idx_columns_b: np.ndarray,
        operator: str,
        coef: float,) -> np.ndarray:
    """Compute the feature combinations using numpy arrays.

        Depending on the `operator` input value, the columns are combined by
          * addition:

            $$X[columns_a] + coef * X[columns_b]$$

          * multiplication:

            $$X[columns_a] * X[columns_b]$$

          * division:

            $$X[columns_a] / X[columns_b]$$

        Parameters
        ----------
        X  : np.ndarray
            Input array.
        idx_columns_a : np.ndarray
            Array of column indices.
        idx_columns_b : np.ndarray
            Array of column indices.
        operator : str
            Operator (`+`, `*`, or `\`).
        coef : float
            Coefficient used in the addtion and the substraction.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Dataframe with the combination features.
        """
    if operator == '+':
        return X[:, idx_columns_a] + coef * X[:, idx_columns_b]
    elif operator == '*':
        return X[:, idx_columns_a] * X[:, idx_columns_b]
    else:
        return X[:, idx_columns_a] / (X[:, idx_columns_b] + 1e-6)


class TwoFeatureCombination(Transformer):
    """Two Feature Combination class.

    Parameters
    ----------
    columns_a : List[str]
        List of columns.
    columns_b : List[str]
        List of columns.
    operator : str
        Operator
    column_names : List[str], defaults to [].
        List of new column names. 
    coef : float, defaults to 1.
        Coefficient value. Defaults to 1.
        
    Examples
    ---------

    >>> import pandas as pd
    >>> from gators.feature_generation import TwoFeatureCombination
    >>> X = pd.DataFrame({'A': [1, 1., 1.], 'B': [1., 2., 3.]})
    >>> obj = TwoFeatureCombination(columns_a=['A'], columns_b=['B'], operator='+', coef=0.1)
    >>> obj.fit_transform(X)
        A    B  A__+__B
    0  1.0  1.0      1.1
    1  1.0  2.0      1.2
    2  1.0  3.0      1.3

    >>> import pandas as pd
    >>> from gators.feature_generation import TwoFeatureCombination
    >>> X = pd.DataFrame({'A': [1., 1., 1.], 'B': [1., 2., 3.]})
    >>> obj = TwoFeatureCombination(columns_a=['A'], columns_b=['B'], operator='/')
    >>> obj.fit_transform(X)
        A    B   A__/__B
    0  1.0  1.0  0.999999
    1  1.0  2.0  0.500000
    2  1.0  3.0  0.333333

    >>> import pandas as pd
    >>> from gators.feature_generation import TwoFeatureCombination
    >>> X = pd.DataFrame({'A': [1, 1., 1.], 'B': [1., 2., 3.]})
    >>> obj = TwoFeatureCombination(columns_a=['A'], columns_b=['B'], operator='/', column_names=['ratios'])
    >>> obj.fit_transform(X)
        A    B    ratios
    0  1.0  1.0  0.999999
    1  1.0  2.0  0.500000
    2  1.0  3.0  0.333333

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation import TwoFeatureCombination
    >>> X = ks.DataFrame({'A': [1., 1., 1.], 'B': [1., 2., 3.]})
    >>> obj = TwoFeatureCombination(columns_a=['A'], columns_b=['B'], operator='/')
    >>> obj.fit_transform(X)
        A    B   A__/__B
    0  1.0  1.0  0.999999
    1  1.0  2.0  0.500000
    2  1.0  3.0  0.333333
        
    >>> import pandas as pd
    >>> from gators.feature_generation import TwoFeatureCombination
    >>> X = pd.DataFrame({'A': [1., 1., 1.], 'B': [1., 2., 3.]})
    >>> obj = TwoFeatureCombination(columns_a=['A'], columns_b=['B'], operator='/')
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1.        , 1.        , 0.999999  ],
           [1.        , 2.        , 0.49999975],
           [1.        , 3.        , 0.33333322]])

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation import TwoFeatureCombination
    >>> X = ks.DataFrame({'A': [1., 1., 1.], 'B': [1., 2., 3.]})
    >>> obj = TwoFeatureCombination(columns_a=['A'], columns_b=['B'], operator='/')
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1.        , 1.        , 0.999999  ],
           [1.        , 2.        , 0.49999975],
           [1.        , 3.        , 0.33333322]])
    """

    def __init__(self, columns_a: List[str], columns_b: List[str],
                 operator: str, column_names: List[str] = None, coef: float = 1.):
        self.columns_a = columns_a
        self.columns_b = columns_b
        self.idx_columns_a: np.ndarray = np.array([])
        self.idx_columns_b: np.ndarray = np.array([])
        self.operator = operator
        self.coef = coef
        str_operator = operator
        if coef < 0:
            str_operator = '-'
        if column_names:
            self.column_names = column_names
        else:
            self.column_names = [
                f'{c_a}__{str_operator}__{c_b}'
                for c_a, c_b in zip(columns_a, columns_b)
            ]
        
    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'TwoFeatureCombination':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.
        y None 
            None.

        Returns
        -------
        TwoFeatureCombination
            Instance of itself.
        """
        self.check_dataframe(X)
        self.idx_columns_a = get_idx_columns_in_selected_columns(
            columns=X.columns,
            selected_columns=self.columns_a
        )
        self.idx_columns_b = get_idx_columns_in_selected_columns(
            columns=X.columns,
            selected_columns=self.columns_b
        )
        return self

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        self.check_dataframe(X)
        if len(self.columns_a) == 0:
            return X
        X_new = self.compute_X_combination(
            X, self.columns_a, self.idx_columns_a, self.columns_b,
            self.idx_columns_b, self.column_names, self.operator, self.coef)
        return X_new

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        if len(self.columns_a) == 0:
            return X
        X_comnination_np = compute_X_combination_numpy(
            X, self.idx_columns_a, self.idx_columns_b,
            self.operator, self.coef)
        if X_comnination_np is None:
            return X
        return np.concatenate((X, X_comnination_np), axis=1)

    @staticmethod
    def compute_X_combination(
            X: Union[pd.DataFrame, ks.DataFrame],
            columns_a: List[str],
            idx_columns_a: np.ndarray,
            columns_b: List[str],
            idx_columns_b: np.ndarray,
            column_names: List[str],
            operator: str,
            coef: float,) -> Union[pd.DataFrame, ks.DataFrame]:
        """Compute the feature combinations.

          Depending on the `operator` input value, the columns are combined by
            * addition:

              $$X[columns_a] + coef * X[columns_b]$$

            * multiplication:

              $$X[columns_a] * X[columns_b]$$

            * division:

              $$X[columns_a] / X[columns_b]$$

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.
        idx_columns_a : np.ndarray
            Array of column indices.
        idx_columns_b : np.ndarray
            Array of column indices.
        operator : str
            Operator (`+`, `*`, or `\`).
        coef : float
            Coefficient used in the addtion and the substraction.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Dataframe with the combination features.
        """            
        for a, b, c in zip(columns_a, columns_b, column_names):
            if operator == '+':
                X[c] = X[a] + coef * X[b]
            elif operator == '*':
                X[c] = X[a] * X[b]
            else:
                X[c] = X[a] / (X[b] + 1e-6)
        return X
