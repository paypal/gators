from typing import Callable
import logging
import functools
import time
#https://dev.to/aldo/implementing-logging-in-python-via-decorators-1gje
#https://realpython.com/primer-on-python-decorators/
def _generate_logger(path: str) -> logging.Logger:
    """Generate a logger object

    Parameters
    ----------
        path : str
            Path of the log file.

    Returns:
        logging.Logger: Logger object.
    """    
    logger = logging.getLogger('Log')
    logger.setLevel(logging.INFO)
    file_handler = logging.FileHandler(path)
    # See https://docs.python.org/3/library/logging.html#logrecord-attributes
    log_format = '%(levelname)s %(asctime)s %(message)s'
    formatter = logging.Formatter(log_format)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger


def log(path='<path>/log.error.log'):
    """Log function
    
    Parameters
    ----------
        path : str
            Path of the log file.

    Returns:
        Callable: Log function.
    """

    def log(func):

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
                logger = _generate_logger(path)
                t_start = time.perf_counter()  
                func_return = func(*args, **kwargs)
                t_end = time.perf_counter()
                delta_time = t_end - t_start
                error_msg = f' {func.__name__} + \n'
                exectime_msg = f' {delta_time} + \n'
                logger.exception(error_msg)
                logger.exception(exectime_msg)
                return func_return

        return wrapper

    return log