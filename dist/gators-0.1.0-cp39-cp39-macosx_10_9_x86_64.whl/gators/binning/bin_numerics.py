# License: Apache-2.0
from typing import List, Union, Dict
import numpy as np
import pandas as pd
import databricks.koalas as ks
from pyspark.ml.feature import QuantileDiscretizer
from ..transformer.transformer import Transformer
from ..util import util
from cython_binning import bin_numerics, bin_numerics_object

EPSILON  = 1e-10

class BinNumerics(Transformer):
    """Bin Numerics class.
    
    Note that difference between Pandas and Koalas are expected due
    to the different quantile computations.

    Parameters
    ----------
    n_bins : int
        Number of bins to use.
    relativeError : float
        Relative error to compute the quantiles.
        
    Examples
    ---------
    
    >>> from gators.binning import BinNumerics
    >>> import pandas as pd
    >>> X = pd.DataFrame({'A': [-1, 0, 1], 'B': [1, 2, 3]})
    >>> obj = BinNumerics(n_bins=2)
    >>> obj.fit_transform(X)
    A  B  A_bin  B_bin
    0 -1  1    0.0    0.0
    1  0  2    1.0    1.0
    2  1  3    1.0    1.0

    >>> import databricks.koalas as ks
    >>> from gators.binning import BinNumerics
    >>> X = ks.DataFrame({'A': [-1, 0, 1], 'B': [1, 2, 3]})
    >>> obj = BinNumerics(n_bins=2)
    >>> obj.fit_transform(X)
    A  B  A_bin  B_bin
    0 -1  1    0.0    0.0
    1  0  2    1.0    1.0
    2  1  3    1.0    1.0

    >>> import pandas as pd
    >>> from gators.binning import BinNumerics
    >>> X = pd.DataFrame({'A': [-1., 0., 1.], 'B': [1., 2., 3.]})
    >>> obj = BinNumerics(n_bins=2)
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[-1.,  1.,  0.,  0.],
           [ 0.,  2.,  1.,  1.],
           [ 1.,  3.,  1.,  1.]])

    >>> import databricks.koalas as ks
    >>> from gators.binning import BinNumerics
    >>> X = ks.DataFrame({'A': [-1, 0, 1], 'B': [1, 2, 3]x})
    >>> obj = BinNumerics(n_bins=2)
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[-1.,  1.,  1.,  0.],
           [ 0.,  2.,  0.,  1.],
           [ 1.,  3.,  0.,  1.]])
       
    """

    def __init__(self, n_bins: int, relativeError: float = 0.05):
        if not isinstance(n_bins, int):
            raise TypeError('`n_bins` must be an int.')
        if not isinstance(relativeError, float):
            raise TypeError('`relativeError` must be a float.')
        Transformer.__init__(self)
        self.n_bins = n_bins
        self.columns = []
        self.output_columns =[]
        self.idx_columns = np.array([])
        self.bins = pd.DataFrame([])
        self.bins_np = np.array([])
        self.bin_limits = np.array([])
        self.bin_limits_np = np.array([])
        self.q = np.linspace(0, 1, n_bins+1)[1:-1].tolist()
        self.relativeError = relativeError

    def fit(self, X: Union[pd.DataFrame, ks.DataFrame], y=None) -> 'BinNumerics':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None. 
            Labels.

        Returns
        -------
        'BinNumerics'
            Instance of itself.
        """
        self.check_dataframe(X)
        self.columns = util.get_numerical_columns(X)
        self.output_columns = [f'{c}__bin' for c in self.columns]
        self.idx_columns  = util.get_idx_columns_in_selected_columns(
            X.columns, self.columns
        )
        n_cols = len(self.idx_columns)
        if n_cols == 0:
            return self
        if isinstance(X, pd.DataFrame):
            self.bin_limits = X[self.columns].apply(
                self.compute_bins_pd, args=(self.n_bins, )
            )
            self.bins = self.bin_limits.apply(self.get_intervals_pd)
            self.bin_limits_np = self.get_bin_limits_np(self.bins) + EPSILON
        else:
            
            self.discretizer = QuantileDiscretizer(
                numBuckets=self.n_bins, 
                inputCols=self.columns, 
                outputCols=self.output_columns,
            )
            self.discretizer = self.discretizer.fit(X.to_spark())
            self.bins = self.discretizer.getSplitsArray()
            self.bin_limits_np = self.get_bin_limits_ks(self.bins) - EPSILON
        self.bins_np = (np.ones((n_cols, self.n_bins)) * np.arange(self.n_bins)).T
        return self

    def transform(self,
                  X: Union[pd.DataFrame, ks.DataFrame]
                  ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        self.check_dataframe(X)
        if self.idx_columns.size == 0:
            return X
        if isinstance(X, pd.DataFrame):
            X_bin = X[self.columns].apply(self.bin_numerics_pd, args=(self.bins, ))
            X_bin = X_bin.apply(self.replace_bins_pd, args=(self.bins, )).astype(float)
            X_bin.columns = self.output_columns
            X_bin.index.name = X.index.name
            return X.join(X_bin)
        else:
            dummy = ks.DataFrame(self.discretizer.transform(X.to_spark()))
            columns_not_bins = [c for c in X.columns if c not in self.output_columns]
            return dummy[columns_not_bins].join(dummy[self.output_columns])


    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the input numpy array.

        Parameters
        ----------
        X : np.ndarray
            Input numpy array.

        Returns
        -------
        np.ndarray
            Transformed numpy array.
        """
        self.check_array(X)
        if self.idx_columns.size == 0:
            return X
        if X.dtype == object:
            return bin_numerics_object(
                X,
                self.bin_limits_np, 
                self.bins_np, 
                self.idx_columns
            )
        return bin_numerics(
            X.astype(float),
            self.bin_limits_np, 
            self.bins_np, 
            self.idx_columns
        )
            
    @staticmethod
    def compute_bins_pd(x, q):
        if x.std() == 0:
            return [np.array([- np.inf, np.inf])]
        _, bins = pd.qcut(x, q=q, duplicates='drop', retbins=True)
        bins = bins.astype(float).round(3)
        bins[0] = -np.inf
        bins[-1] = np.inf
        return [bins]

    @staticmethod
    def get_intervals_pd(bins):
        return pd.IntervalIndex.from_arrays(
            bins[0][:-1], bins[0][1:], closed='right')
    
    @staticmethod
    def replace_bins_pd(x, bins):
        return x.cat.codes

    @staticmethod
    def bin_numerics_pd(x, bins):
        bins = pd.IntervalIndex(bins[x.name])
        return pd.cut(x, bins=bins)

    @staticmethod
    def get_bin_limits_np(bins: pd.DataFrame):
        
        def get_bin_limit_np(x):
            x = x.values.astype(str)
            limits = np.empty(2 * len(x))
            limits[::2] = [float(a.split(',')[0][1:]) for a in x]
            limits[1::2] = [float(a.split(',')[1][:-1]) for a in x]
            return np.unique(limits)
        bin_limits = bins.apply(get_bin_limit_np).to_numpy()
        n_rows = max([len(x) for x in bin_limits])
        n_cols = bin_limits.shape[0]
        bin_limits_np = np.zeros((n_rows, n_cols))
        for i, bin_limit in enumerate(bin_limits):
            n = len(bin_limit)
            bin_limits_np[:n, i] = bin_limit
        return bin_limits_np.T

    @staticmethod
    def get_bin_limits_ks(bins: List[List[float]]):
        n_rows = max([len(x) for x in bins])
        n_cols = len(bins)
        bin_limits_np = np.zeros((n_rows, n_cols))
        for i, bin_limit in enumerate(bins):
            n = len(bin_limit)
            bin_limits_np[:n, i] = bin_limit
        return bin_limits_np.T