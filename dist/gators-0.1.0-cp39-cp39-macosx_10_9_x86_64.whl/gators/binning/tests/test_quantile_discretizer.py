# License: Apache-2.0
from gators.binning import QuantileDiscretizer
from pandas.testing import assert_frame_equal
import pytest
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    n_bins = 4
    X = pd.DataFrame({
        'A': [7.25, 71.2833, 7.925, 53.1, 8.05, 8.4583],
        'B': [1, 1, 0, 1, 0, 0],
        'C': ['a', 'b', 'c', 'd', 'e', 'f'],
        'D': [22.0, 38.0, 26.0, 35.0, 35.0, 31.2],
        'F': [3, 1, 2, 1, 2, 3]}
    )
    X_expected = pd.DataFrame({
        'A': {0: 7.25, 1: 71.2833, 2: 7.925, 3: 53.1, 4: 8.05, 5: 8.4583},
        'B': {0: 1, 1: 1, 2: 0, 3: 1, 4: 0, 5: 0},
        'C': {0: 'a', 1: 'b', 2: 'c', 3: 'd', 4: 'e', 5: 'f'},
        'D': {0: 22.0, 1: 38.0, 2: 26.0, 3: 35.0, 4: 35.0, 5: 31.2},
        'F': {0: 3, 1: 1, 2: 2, 3: 1, 4: 2, 5: 3},
        'A__bin': {0: '0.0', 1: '3.0', 2: '0.0', 3: '3.0', 4: '1.0', 5: '2.0'},
        'B__bin': {0: '2.0', 1: '2.0', 2: '0.0', 3: '2.0', 4: '0.0', 5: '0.0'},
        'D__bin': {0: '0.0', 1: '3.0', 2: '0.0', 3: '2.0', 4: '2.0', 5: '1.0'},
        'F__bin': {0: '3.0', 1: '0.0', 2: '1.0', 3: '0.0', 4: '1.0', 5: '3.0'}
    })
    X_ks = ks.from_pandas(X)
    obj_pd = QuantileDiscretizer(n_bins).fit(X)
    obj_ks = QuantileDiscretizer(n_bins).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


@ pytest.fixture
def data_inplace():
    n_bins = 4
    X = pd.DataFrame({
        'A': [7.25, 71.2833, 7.925, 53.1, 8.05, 8.4583],
        'B': [1, 1, 0, 1, 0, 0],
        'C': ['a', 'b', 'c', 'd', 'e', 'f'],
        'D': [22.0, 38.0, 26.0, 35.0, 35.0, 31.2],
        'F': [3, 1, 2, 1, 2, 3]}
    )
    X_expected = pd.DataFrame({
        'A': {0: '0.0', 1: '3.0', 2: '0.0', 3: '3.0', 4: '1.0', 5: '2.0'},
        'B': {0: '2.0', 1: '2.0', 2: '0.0', 3: '2.0', 4: '0.0', 5: '0.0'},
        'C': {0: 'a', 1: 'b', 2: 'c', 3: 'd', 4: 'e', 5: 'f'},
        'D': {0: '0.0', 1: '3.0', 2: '0.0', 3: '2.0', 4: '2.0', 5: '1.0'},
        'F': {0: '3.0', 1: '0.0', 2: '1.0', 3: '0.0', 4: '1.0', 5: '3.0'}
    })
    X_ks = ks.from_pandas(X)
    obj_pd = QuantileDiscretizer(n_bins, inplace=True).fit(X)
    obj_ks = QuantileDiscretizer(n_bins, inplace=True).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


@ pytest.fixture
def data_num():
    n_bins = 4
    X = pd.DataFrame({
        'A': [7.25, 71.2833, 7.925, 53.1, 8.05, 8.4583],
        'B': [1, 1, 0, 1, 0, 0],
        'D': [22.0, 38.0, 26.0, 35.0, 35.0, 31.2],
        'F': [3, 1, 2, 1, 2, 3]}
    )
    X_expected = pd.DataFrame({
        'A': {0: 7.25, 1: 71.2833, 2: 7.925, 3: 53.1, 4: 8.05, 5: 8.4583},
        'B': {0: 1, 1: 1, 2: 0, 3: 1, 4: 0, 5: 0},
        'D': {0: 22.0, 1: 38.0, 2: 26.0, 3: 35.0, 4: 35.0, 5: 31.2},
        'F': {0: 3, 1: 1, 2: 2, 3: 1, 4: 2, 5: 3},
        'A__bin': {0: '0.0', 1: '3.0', 2: '0.0', 3: '3.0', 4: '1.0', 5: '2.0'},
        'B__bin': {0: '2.0', 1: '2.0', 2: '0.0', 3: '2.0', 4: '0.0', 5: '0.0'},
        'D__bin': {0: '0.0', 1: '3.0', 2: '0.0', 3: '2.0', 4: '2.0', 5: '1.0'},
        'F__bin': {0: '3.0', 1: '0.0', 2: '1.0', 3: '0.0', 4: '1.0', 5: '3.0'}
    })
    X_ks = ks.from_pandas(X)
    obj_pd = QuantileDiscretizer(n_bins).fit(X)
    obj_ks = QuantileDiscretizer(n_bins).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


@ pytest.fixture
def data_num_inplace():
    n_bins = 4
    X = pd.DataFrame({
        'A': [7.25, 71.2833, 7.925, 53.1, 8.05, 8.4583],
        'B': [1, 1, 0, 1, 0, 0],
        'D': [22.0, 38.0, 26.0, 35.0, 35.0, 31.2],
        'F': [3, 1, 2, 1, 2, 3]}
    )
    X_expected = pd.DataFrame({
        'A': {0: '0.0', 1: '3.0', 2: '0.0', 3: '3.0', 4: '1.0', 5: '2.0'},
        'B': {0: '2.0', 1: '2.0', 2: '0.0', 3: '2.0', 4: '0.0', 5: '0.0'},
        'D': {0: '0.0', 1: '3.0', 2: '0.0', 3: '2.0', 4: '2.0', 5: '1.0'},
        'F': {0: '3.0', 1: '0.0', 2: '1.0', 3: '0.0', 4: '1.0', 5: '3.0'}
    })
    X_ks = ks.from_pandas(X)
    obj_pd = QuantileDiscretizer(n_bins, inplace=True).fit(X)
    obj_ks = QuantileDiscretizer(n_bins, inplace=True).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


def test_pd(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_ks.transform(X_ks)
    X_new = X_new.to_pandas()
    assert_frame_equal(X_new, X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(
        X_numpy_new, columns=X_expected.columns, index=X_expected.index)
    assert_frame_equal(X_new, X_expected.astype(object))


@ pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(
        X_numpy_new, columns=X_expected.columns, index=X_expected.index)
    assert_frame_equal(X_new, X_expected.astype(object))


def test_num_pd(data_num):
    obj_pd, obj_ks, X, X_ks, X_expected = data_num
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_num_ks(data_num):
    obj_pd, obj_ks, X, X_ks, X_expected = data_num
    X_new = obj_ks.transform(X_ks)
    X_new = X_new.to_pandas()
    assert_frame_equal(X_new, X_expected)


def test_num_pd_np(data_num):
    obj_pd, obj_ks, X, X_ks, X_expected = data_num
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(
        X_numpy_new, columns=X_expected.columns, index=X_expected.index)
    assert_frame_equal(X_new, X_expected.astype(object))


@ pytest.mark.koalas
def test_num_ks_np(data_num):
    obj_pd, obj_ks, X, X_ks, X_expected = data_num
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(
        X_numpy_new, columns=X_expected.columns, index=X_expected.index)
    assert_frame_equal(X_new, X_expected.astype(object))

# # inplace


def test_inplace_pd(data_inplace):
    obj_pd, obj_ks, X, X_ks, X_expected = data_inplace
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_inplace_ks(data_inplace):
    obj_pd, obj_ks, X, X_ks, X_expected = data_inplace
    X_new = obj_ks.transform(X_ks)
    X_new = X_new.to_pandas()
    assert_frame_equal(X_new, X_expected)


def test_inplace_pd_np(data_inplace):
    obj_pd, obj_ks, X, X_ks, X_expected = data_inplace
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(
        X_numpy_new, columns=X_expected.columns, index=X_expected.index)
    assert_frame_equal(X_new, X_expected.astype(object))


@ pytest.mark.koalas
def test_inplace_ks_np(data_inplace):
    obj_pd, obj_ks, X, X_ks, X_expected = data_inplace
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(
        X_numpy_new, columns=X_expected.columns, index=X_expected.index)
    assert_frame_equal(X_new, X_expected.astype(object))


def test_inplace_num_pd(data_num_inplace):
    obj_pd, obj_ks, X, X_ks, X_expected = data_num_inplace
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_inplace_num_ks(data_num_inplace):
    obj_pd, obj_ks, X, X_ks, X_expected = data_num_inplace
    X_new = obj_ks.transform(X_ks)
    X_new = X_new.to_pandas()
    assert_frame_equal(X_new, X_expected)


def test_inplace_num_pd_np(data_num_inplace):
    obj_pd, obj_ks, X, X_ks, X_expected = data_num_inplace
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(
        X_numpy_new, columns=X_expected.columns, index=X_expected.index)
    assert_frame_equal(X_new, X_expected.astype(object))


@ pytest.mark.koalas
def test_inplace_num_ks_np(data_num_inplace):
    obj_pd, obj_ks, X, X_ks, X_expected = data_num_inplace
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(
        X_numpy_new, columns=X_expected.columns, index=X_expected.index)
    assert_frame_equal(X_new, X_expected.astype(object))


def test_init():
    with pytest.raises(TypeError):
        _ = QuantileDiscretizer(n_bins='a')
    with pytest.raises(TypeError):
        _ = QuantileDiscretizer(n_bins=2, inplace='a')
