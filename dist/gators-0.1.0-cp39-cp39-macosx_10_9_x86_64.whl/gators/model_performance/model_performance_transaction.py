# License: Apache-2.0
from ..model_performance.model_performance import ModelPerformance
from ..model_performance import model_performance_util
from ..model_performance import metrics
from scipy.optimize import bisect
from typing import Union
from typing import List, Union
from typing import Tuple
import numpy as np
import pandas as pd


class ModelPerformanceTransaction(ModelPerformance):
    """Model Performance class.
    
    Parameters
    ----------
    y_true : np.ndarray:
        True target values.
    y_pred_proba : np.ndarray:
        odel score values.
    amount : np.ndarray:
        mount values.
    """

    def __init__(self, y_true: np.array ,y_pred_proba: np.ndarray,
                 amount: np.ndarray):
        ModelPerformance.__init__(self, y_true, y_pred_proba)
        self.amount = amount

    def performances(self,
                     thresholds: List[float],
                     betas: List[float]) -> pd.DataFrame:
        """Return the model performance for the given thresholds and betas.

        Parameters
        ----------
        thresholds : List[float]
            List of threshold values to consider.
        betas : List[float]
            List of beta values to consider.

        Returns
        -------
        pd.DataFrame
            Model performance dataframe.
        """
        perfs = pd.Series(thresholds, index=thresholds, dtype='float')
        perfs.index.name = 'threshold'
        kwds = {
            'y_true': self.y_true,
            'y_pred_proba': self.y_pred_proba,
            'amount': self.amount,
        }
        perfs = perfs.apply(self.performance, **kwds)
        dump = pd.Series(betas, index=betas, dtype='float')
        kwds = {
            'p': perfs['precision'],
            'r': perfs['recall'],
        }

        fscores = dump.apply(metrics.fbeta_formula, **kwds).T
        fscores.columns = [
            model_performance_util.get_fbeta_column_name(beta)
            for beta in betas
        ]
        return pd.concat([perfs, fscores], axis=1).round(5)

    @staticmethod
    def performance(threshold: float, y_true: np.ndarray,
                    y_pred_proba: np.ndarray,
                    amount: np.ndarray) -> pd.Series:
        """Return the model performance for a given threshold.

        Parameters
        ----------
        threshold : float
            Score threshold value.
        y_true : np.ndarray
            True target values.
        y_pred_proba : np.ndarray
            odel score values.
        amount : np.ndarray
            ransaction amount values.

        Returns
        -------
            pd.Series: Model performance for a given threshold.
        """
        index = [
            'ratio_rejected(%)',
            'precision',
            'recall',
            'tp(count)',
            'tn(count)',
            'fp(count)',
            'fn(count)',
            'fp/tp(count)',
            'tp($)',
            'tn($)',
            'fp($)',
            'fn($)',
            'fp/tp($)',
        ]
        y_pred = model_performance_util.get_y_pred(y_pred_proba, threshold)
        cm = metrics.confusion_matrix(y_true, y_pred)
        precision, recall = metrics.precision_recall_with_cm(cm)
        perf = pd.Series(0., index=index, dtype='float')
        perf['ratio_rejected(%)'] = 100 * y_pred.mean()
        perf['precision'] = precision
        perf['recall'] = recall
        perf['tp(count)'] = cm[0, 0]
        perf['fp(count)'] = cm[0, 1]
        perf['fn(count)'] = cm[1, 0]
        perf['tn(count)'] = cm[1, 1]
        perf['fp/tp(count)'] = cm[0, 1] / cm[0, 0]
        cm = metrics.confusion_matrix(y_true, y_pred, amount)
        perf['tp($)'] = cm[0, 0]
        perf['fp($)'] = cm[0, 1]
        perf['fn($)'] = cm[1, 0]
        perf['tn($)'] = cm[1, 1]
        perf['fp/tp($)'] = cm[0, 1] / cm[0, 0]
        return perf
    
    
    @staticmethod
    def threshold_tpfp_amount(
            fptp: float, y_true: np.array ,y_pred_proba: np.ndarray,
            amount: np.array ,min_val: float = 0.001,
            max_val: float = 0.999) -> float:
        """Return the threshold for a given FP to TP rate.

        Parameters
        ----------
        fptp : float
            FP to TP rate.
        y_true : np.ndarray
            True target values.
        y_pred_proba : np.ndarray
            Model score values.
        amount : np.ndarray
            Transaction amount values.
        min_val : float. default to 0.001
            Minimal threshold value to consider.
        max_val : float. default to 0.999
            Maximal threshold value to consider.

        Returns
        -------
        float
            Threshold value.
        """

        def func_to_minimize(threshold: float) -> float:
            """            Return value to minimize.

            Parameters
            ----------
            threshold : float
                Threshold value.

            Returns
            -------
            float
                Value to minimize.
          """            
            y_pred = model_performance_util.get_y_pred(
                y_pred_proba, threshold)
            mask_tp = metrics.mask_true_positive(y_true, y_pred)
            mask_fp = metrics.mask_false_positive(y_true, y_pred)
            return amount[mask_fp].sum() / amount[mask_tp].sum() - fptp

        if func_to_minimize(min_val) * func_to_minimize(max_val) > 0:
            return np.nan
        res = bisect(func_to_minimize, min_val, max_val, xtol=1e-15)
        return res

    def fptp_amount_thresholds(
            self, fptps_values: List[float], min_val: float = 0.001,
            max_val: float = 0.999, ) -> pd.Series:
        """Return the thresholds for the given FP to TP rates.

        Parameters
        ----------
        fptps_values : List[float]
            FP to TP rates.
        min_val : float. default to 0.001
            Minimal threshold value to consider.
        max_val : float. default to 0.999
            Maximal threshold value to consider.

        Returns
        -------
        pd.Series
            Threshold values
        """
        fptps = pd.Series(fptps_values, index=fptps_values, dtype='float')
        fptps.index.name = 'fptp'
        kwds = {
            'y_true': self.y_true,
            'y_pred_proba': self.y_pred_proba,
            'amount': self.amount,
            'min_val': min_val,
            'max_val': max_val,
        }
        return fptps.apply(self.threshold_tpfp_amount, **kwds).dropna()
