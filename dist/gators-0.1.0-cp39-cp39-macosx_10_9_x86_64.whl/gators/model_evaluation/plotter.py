# License: Apache-2.0
from typing import Union
import pandas as pd
import matplotlib.pyplot as plt
from ..model_performance import model_performance_util


class Plotter:
    """Plotter class.

    Parameters
    ----------
    perfs ([pd.DataFrame]): Generated model performance.
    """

    def __init__(self, perfs: pd.DataFrame) -> None:
        self.perfs = perfs

    def plot_fscores(self, fig_height: float = 5.,
                     style: str = '--*') -> plt.Figure:
        """Plot the F-beta scores values depending on the thresholds.

        Parameters
        ----------
        fig_height : float, default to efaults to '--'
            Height of the figure. Defaults to 5.
        style: str
            Plotstyle
        Returns
        -------
        plt.Figure
            Matplotlib figure..
        """
        figsize = (fig_height * 1.618, fig_height)
        fig, ax = plt.subplots(figsize=figsize)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        columns = [c for c in self.perfs.columns if c.startswith('F')]
        self.perfs[columns].plot(ax=ax, style=style)
        plt.legend(loc=7, bbox_to_anchor=(1.17, 0.5))
        ax.set_title('F-beta score VS Threshold Value')
        ax.set_xlabel('Threshold Value')
        ax.set_ylabel('F-score')
        return fig

    def plot_roc_curve(self, fig_height=5.) -> plt.Figure:
        """Plot the ROC curve.

        Parameters
        ----------
        fig_hight : float, default to 5.
            Hight of the figure
        Returns
        -------
        plt.Figure:
            Matplotlib figure.
        """
        tp_rate = self.perfs['tp(count)'] / \
            (self.perfs['tp(count)'] + self.perfs['fn(count)'])
        fp_rate = self.perfs['fp(count)'] / \
            (self.perfs['fp(count)'] + self.perfs['tp(count)'])
        figsize = (fig_height * 1.618, fig_height)
        fig, ax = plt.subplots(figsize=figsize)
        ax.set_title('ROC Curve')
        ax.set_xlabel('False Positive Rate')
        ax.set_ylabel('True Positive Rate')
        plt.plot(fp_rate, tp_rate, '--o')
        fig.tight_layout()
        return fig

    def plot_precision_recall_curve(self, fig_height=5.) -> plt.Figure:
        """Plot the Precison Recall curve.

        Parameters
        ----------
        fig_hight : float, default to 5.
            Hight of the figure
        Returns
        -------
        plt.Figure:
            Matplotlib figure.
        """
        figsize = (fig_height * 1.618, fig_height)
        fig, ax = plt.subplots(figsize=figsize)
        ax.set_title('Precision Recall Curve')
        ax.set_xlabel('Recall')
        ax.set_ylabel('Precision')
        plt.plot(self.perfs['precision'], self.perfs['recall'], '--o')
        fig.tight_layout()
        return fig

    def get_confusion_matrix(
            self, beta: float, weighted: bool = False) -> pd.DataFrame:
        """Return the confusion matrix for the given beta value.

        The selected threshold corresponds to the maximal F-beta value.

        Parameters
        ----------
        beta : float
            Beta value.
        weighted : bool
            If True compute the confusion matrix
            using the tp, tn, fp, fn based on amount. Defaults to False.

        Returns
        -------
        pd.DataFrame
            Confusion matrix.
        """
        column = model_performance_util.get_fbeta_column_name(beta)
        idx = self.perfs[column].idxmax()
        if weighted:
            columns = ['tn($)', 'fp($)', 'fn($)', 'tp($)']
        else:
            columns = ['tn(count)', 'fp(count)', 'fn(count)', 'tp(count)']
        cm = self.perfs.loc[idx, columns].to_numpy()
        cm /= cm.sum()
        index = ['Not Fraud', 'Fraud']
        cm = pd.DataFrame(cm.reshape((2, 2)), index=index, columns=index)
        cm.name = column
        return cm
