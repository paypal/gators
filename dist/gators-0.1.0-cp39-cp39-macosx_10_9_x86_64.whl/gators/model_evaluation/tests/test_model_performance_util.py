# # License: Apache-2.0
# from gators.model_performance import model_performance_util


# def test_get_fbeta_column_name():
#     assert model_performance_util.get_fbeta_column_name(beta=1) == 'F1'
#     assert model_performance_util.get_fbeta_column_name(beta=1.) == 'F1'
#     assert model_performance_util.get_fbeta_column_name(beta=1.55) == 'F1.55'
