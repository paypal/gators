# License: Apache-2.0
from scaler import minmax_scaler
from ..transformer.transformer import Transformer
import numpy as np
from typing import Union
import pandas as pd
import databricks.koalas as ks


class MinMaxScaler(Transformer):
    """MinMax Scaler Transformer.

    Examples
    ---------

    * fit & transform with pandas

    >>> import pandas as pd
    >>> from gators.scalers import MinMaxScaler
    >>> X = pd.DataFrame({'A': [1, 2, 3], 'B': [-0.1, 0.2, 0.3]})
    >>> obj = MinMaxScaler()
    >>> obj.fit_transform(X)
        A     B
    0  0.0  0.00
    1  0.5  0.75
    2  1.0  1.00

    * fit & transform with koalas

    >>> import databricks.koalas as ks
    >>> from gators.scalers import MinMaxScaler
    >>> X = ks.DataFrame({'A': [1, 2, 3], 'B': [-0.1, 0.2, 0.3]})
    >>> obj = MinMaxScaler()
    >>> obj.fit_transform(X)
        A     B
    0  0.0  0.00
    1  0.5  0.75
    2  1.0  1.00

    * fit with pandas & transform with numpy

    >>> import pandas as pd
    >>> from gators.scalers import MinMaxScaler
    >>> X = pd.DataFrame({'A': [1, 2, 3], 'B': [-0.1, 0.2, 0.3]})
    >>> obj = MinMaxScaler()
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[0.  , 0.  ],
           [0.5 , 0.75],
           [1.  , 1.  ]])

    * fit with koalas & transform with numpy

    >>> import databricks.koalas as ks
    >>> from gators.scalers import MinMaxScaler
    >>> X = ks.DataFrame({'A': [1, 2, 3], 'B': [-0.1, 0.2, 0.3]})
    >>> obj = MinMaxScaler()
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[0.  , 0.  ],
           [0.5 , 0.75],
           [1.  , 1.  ]])
    """

    def __init__(self):
        self.X_min: Union[pd.DataFrame, ks.DataFrame] = None
        self.X_max: Union[pd.DataFrame, ks.DataFrame] = None
        self.X_min_np = np.array([])
        self.X_max_np = np.array([])

    def fit(self, X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'MinMaxScaler':
        """Fit the transformer on the pandas/koalas dataframe X.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None.
            Labels.

        Returns
        -------
            'MinMaxScaler': Instance of itself.
        """
        self.check_dataframe(X)
        self.X_min = X.min()
        self.X_max = X.max()
        self.X_min_np = self.X_min.to_numpy()
        self.X_max_np = self.X_max.to_numpy()
        return self

    def transform(self, X):
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """
        self.check_dataframe(X)
        self.check_dataframe_is_numerics(X)

        def scaling(x):
            c = x.name
            return (x - self.X_min.loc[c]) / \
                (self.X_max[c] - self.X_min[c])

        return X.apply(scaling)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the array X.

        Parameters
        ----------
        X (np.ndarray): Input ndarray.

        Returns
        -------
            np.ndarray: Imputed ndarray.
        """
        self.check_array(X)
        return minmax_scaler(X, self.X_min_np, self.X_max_np)
