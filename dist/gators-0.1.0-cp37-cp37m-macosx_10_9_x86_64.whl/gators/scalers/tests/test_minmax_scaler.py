# License: Apache-2.0
from gators.scalers.minmax_scaler import MinMaxScaler
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    X = pd.DataFrame(
        np.random.randn(5, 5),
        columns=list('ABCDF')
    )
    X_ks = ks.from_pandas(X)
    obj_pd = MinMaxScaler().fit(X)
    obj_ks = MinMaxScaler().fit(X_ks)
    return obj_pd, obj_ks, X, X_ks


def test_pd(data):
    obj_pd, obj_ks, X, X_ks = data
    X_new = obj_pd.transform(X)
    assert np.allclose(X_new.min().mean(), 0)
    assert np.allclose(X_new.max().mean(), 1)


@pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks = data
    X_new = obj_ks.transform(X_ks)
    assert np.allclose(X_new.min().mean(), 0)
    assert np.allclose(X_new.max().mean(), 1)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks = data
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    assert np.allclose(X_new.min().mean(), 0)
    assert np.allclose(X_new.max().mean(), 1)


@pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks = data
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    assert np.allclose(X_new.min().mean(), 0)
    assert np.allclose(X_new.max().mean(), 1)
