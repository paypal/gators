# License: Apache-2.0
from gators.converter.set_column_datatype import SetColumnDatatype
from pandas.testing import assert_frame_equal
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    X = pd.DataFrame(
        {
            'A': [True, False, True, False],
            'B': [True, True, True, False],
            'C': [True, True, True, True],
            'D': [1, 2, 3, 4]
        })
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(
        {
            'A': [1., 0., 1., 0.],
            'B': [1., 1., 1., 0.],
            'C': [1., 1., 1., 1.],
            'D': [1, 2, 3, 4]
        }
    )
    obj_pd = SetColumnDatatype(
        columns=['A', 'B', 'C'], datatype=float).fit(X)
    obj_ks = SetColumnDatatype(
        columns=['A', 'B', 'C'], datatype=float).fit(X_ks)
    return obj_pd, obj_ks, X, X_expected


@pytest.fixture
def data_obj():
    X = pd.DataFrame(
        {
            'A': ['2020-01-01T00', '2020-04-08T06'],
            'B': [True, False],
            'C': [True, True],
            'D': [1, 2]
        }
    )
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(
        {
            'A': ['2020-01-01T00', '2020-04-08T06'],
            'B': [True, False],
            'C': [True, True],
            'D': [1, 2]
        }
    )
    X_expected['A'] = X_expected['A'].astype('datetime64[ns]')
    obj_pd = SetColumnDatatype(
        columns=['A'], datatype='datetime64[ns]').fit(X)
    obj_ks = SetColumnDatatype(
        columns=['A'], datatype='datetime64[ns]').fit(X_ks)
    return obj_pd, obj_ks, X, X_expected


def test_pd(data):
    obj_pd, obj_ks, X, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_expected = data
    X = ks.from_pandas(X)
    X_new = obj_ks.transform(X)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_expected = data
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(
        X_numpy_new, columns=X_expected.columns, dtype=X_numpy_new.dtype)
    X_expected = pd.DataFrame(
        X_expected, columns=X_expected.columns, dtype=float)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_expected = data
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(
        X_numpy_new, columns=X_expected.columns, dtype=X_numpy_new.dtype)
    X_expected = pd.DataFrame(
        X_expected, columns=X_expected.columns, dtype=float)
    assert_frame_equal(X_new, X_expected)


def test_obj_pd(data_obj):
    obj_pd, obj_ks, X, X_expected = data_obj
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_obj_ks(data_obj):
    obj_pd, obj_ks, X, X_expected = data_obj
    X = ks.from_pandas(X)
    X_new = obj_ks.transform(X)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_obj_pd_np(data_obj):
    obj_pd, obj_ks, X, X_expected = data_obj
    X_expected = X.copy()
    X_numpy = X.to_numpy()
    X_numpy_new = obj_pd.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns, dtype=object)
    assert_frame_equal(X_new, X_expected.astype(object))


@pytest.mark.koalas
def test_obj_ks_np(data_obj):
    obj_pd, obj_ks, X, X_expected = data_obj
    X_expected = X.copy()
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns, dtype=object)
    assert_frame_equal(X_new, X_expected.astype(object))


def test_input():
    with pytest.raises(TypeError):
        _ = SetColumnDatatype(columns=0, datatype=float)
    with pytest.raises(ValueError):
        _ = SetColumnDatatype(columns=[], datatype=float)
    with pytest.raises(TypeError):
        _ = SetColumnDatatype(columns=['A'], datatype=0)
    with pytest.raises(TypeError):
        _ = SetColumnDatatype(columns=['A'], datatype='x')
