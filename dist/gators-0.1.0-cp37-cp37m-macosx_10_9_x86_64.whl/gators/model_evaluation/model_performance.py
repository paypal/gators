# License: Apache-2.0
from typing import List, Union
import numpy as np
from ..model_performance import model_performance_util
from ..model_performance import metrics
from scipy.optimize import bisect
import pandas as pd


class ModelPerformance:
    """Model Performance class.

    Parameters
    ----------
    y_true : np.ndarray
            True target values.
        y_pred_proba : np.ndarray
           Model score values.
    """

    def __init__(self, y_true: np.array,
                 y_pred_proba: np.ndarray) -> None:
        self.y_true = y_true
        self.y_pred_proba = y_pred_proba

    @ staticmethod
    def fscore(
            threshold: float, y_true: np.array, y_pred_proba: np.ndarray,
            betas: List[float]) -> pd.DataFrame:
        """Return the fscores for each beta value and a given threshold.

        Parameters
        ----------
        threshold : float
            Score threshold.
        y_true : np.ndarray
            True target values.
        y_pred_proba : np.ndarray
            Model score values.
        betas : List[float]
            List of beta values.

        Returns
        -------
        pd.DataFrame:
        F-scores for each beta value and a given threshold.
        """
        y_pred = model_performance_util.get_y_pred(y_pred_proba, threshold)
        fscores = pd.Series(betas, index=betas)
        kwds = {'y_true': y_true, 'y_pred': y_pred}
        return fscores.apply(metrics.fbeta, **kwds)

    def fscores(self,
                thresholds: List[float] = np.linspace(0, 1, 11)[1: -1],
                betas: List[float] = [1.]) -> pd.DataFrame:
        """Return the f-scores for each beta value and threshold.

        Parameters
        ----------
        thresholds : List[float], defaults to np.linspace(0, 1, 11)[1: -1].
            List of threshold values.
        betas : List[float], defaults to [1.].
            List of beta values.

        Returns
        -------
        pd.DataFrame
            F-scores for each beta value and threshold.
        """
        fscores = pd.Series(thresholds, index=thresholds, dtype='float')
        fscores.index.name = 'threshold'
        kwds = {
            'y_true': self.y_true,
            'y_pred_proba': self.y_pred_proba,
            'betas': betas,
        }
        return fscores.apply(self.fscore, **kwds)

    def performances(
            self, thresholds: List[float], betas: List[float]) -> pd.DataFrame:
        """Return the model performance for the given thresholds and betas.

        Parameters
        ----------
        thresholds : List[float]
            List of threshold values to consider.
        betas : List[float]
            List of beta values to consider.

        Returns
        -------
        pd.DataFrame:
            Model performance
        """
        perfs = pd.Series(thresholds, index=thresholds, dtype='float')
        perfs.index.name = 'threshold'
        kwds = {
            'y_true': self.y_true,
            'y_pred_proba': self.y_pred_proba,
        }
        perfs = perfs.apply(self.performance, **kwds)
        dump = pd.Series(betas, index=betas, dtype='float')
        kwds = {
            'p': perfs['precision'],
            'r': perfs['recall'],
        }

        fscores = dump.apply(metrics.fbeta_formula, **kwds).T
        fscores.columns = [
            model_performance_util.get_fbeta_column_name(beta)
            for beta in betas
        ]
        return pd.concat([perfs, fscores], axis=1).round(2)

    def fptp_thresholds(
            self, fptps_values: List[float], min_val: float = 0.001,
            max_val: float = 0.999, ) -> pd.Series:
        """Return the thresholds for the given FP to TP rates.

        Parameters
        ----------
        fptps_values : List[float]
            FP to TP rates.
        min_val : float, defaults to 0.001
            Minimal threshold value to consider.
            defaults to 0.001.
        max_val : float, defaults to 0.999
            Maximal threshold value to consider.
            defaults to 0.999.

        Returns
        -------
        pd.Series:
            Threshold values
        """
        fptps = pd.Series(fptps_values, index=fptps_values, dtype='float')
        fptps.index.name = 'fptp'
        kwds = {
            'y_true': self.y_true,
            'y_pred_proba': self.y_pred_proba,
            'min_val': min_val,
            'max_val': max_val,
        }
        return fptps.apply(self.threshold_tpfp, **kwds).dropna()

    def reject_ratio_thesholds(
            self, reject_ratio_values: List[float], min_val: float = 0.001,
            max_val: float = 0.999, ) -> pd.Series:
        """Return the thresholds for the given reject ratios.

        Parameters
        ----------
        reject_ratio_values : List[float]
            Reject ratio values.
        min_val : float, defaults to 0.001
            Minimal threshold value to consider.
        max_val : float, defaults to 0.999
            Maximal threshold value to consider.

        Returns
        -------
        pd.Series:
            Threshold values.
        """
        reject_ratio = pd.Series(
            reject_ratio_values, index=reject_ratio_values, dtype='float')
        reject_ratio.index.name = 'reject_ratio'
        kwds = {
            'y_true': self.y_true,
            'y_pred_proba': self.y_pred_proba,
            'min_val': min_val,
            'max_val': max_val,
        }
        return reject_ratio.apply(self.reject_ratio_theshold, **kwds).dropna()

    def rolling_window_perf(
            self, timestamp: pd.Series, threshold: float, n_days_window: int) -> pd.DataFrame:
        """Return the rolling window data with Precision and Recall.

        Parameters
        ----------
        timestamp : pd.Series
            Data timestamp.
        threshold : float
            Threshold value to obtain the label predictions.
        n_days_window : int
            Number of days of the rolling window.

        Returns
        -------
        pd.DataFrame
            Rolling window data with Precision and Recall.
        """
        df = pd.DataFrame(
            {'y_true': self.y_true,
             'y_pred': model_performance_util.get_y_pred(
                 self.y_pred_proba, threshold),
             'timestamp': timestamp
             }
        )
        df.sort_values('timestamp', ascending=False, inplace=True)
        df['date'] = pd.to_datetime(df['timestamp'].dt.date)

    @staticmethod
    def performance(
            threshold: float, y_true: np.array, y_pred_proba: np.ndarray,
            sample_weight: np.ndarray = None) -> pd.Series:
        """Return the model performance for a given threshold.

        Parameters
        ----------
        threshold : float
        Score threshold value.
        y_true : np.ndarray
            True target values.
        y_pred_proba : np.ndarray
           Model score values.

        Returns
        -------
        pd.Series
            Model performance for a given threshold.
        """
        y_pred = model_performance_util.get_y_pred(y_pred_proba, threshold)
        cm = metrics.confusion_matrix(
            y_true, y_pred, sample_weight)
        index = [
            'ratio_rejected(%)',
            'precision',
            'recall',
            'tp(count)',
            'fp(count)',
            'tn(count)',
            'fn(count)',
            'fp/tp',
        ]
        perf = pd.Series(0., index=index, dtype='float')
        precision, recall = metrics.precision_recall_with_cm(cm)
        perf['precision'] = precision
        perf['recall'] = recall
        perf['tp(count)'] = cm[0, 0]
        perf['fp(count)'] = cm[0, 1]
        perf['fn(count)'] = cm[1, 0]
        perf['tn(count)'] = cm[1, 1]
        perf['ratio_rejected(%)'] = 100 * y_pred.mean()
        perf['fp/tp'] = cm[0, 1] / cm[0, 0]
        return perf

    @staticmethod
    def threshold_tpfp(
            fptp: float, y_true: np.array, y_pred_proba: np.ndarray,
            min_val: float = 0.001, max_val: float = 0.999) -> float:
        """Return the threshold for a given FP to TP rate.

        Parameters
        ----------
        fptp : float
            FP to TP rate.
        y_true : np.ndarray
            True target values.
        y_pred_proba : np.ndarray
           Model score values.
        min_val : float, defaults to 0.001
            Minimal threshold value to consider.
        max_val : float, defaults to 0.999
            Maximal threshold value to consider.

        Returns
        -------
            float: Threshold value.
        """

        def func_to_minimize(threshold: float) -> float:
            """Return value to minimize.

            Parameters
            ----------
            threshold : float
                Threshold value.

            Returns
            -------
            float:
                Value to minimize.
            """
            y_pred = model_performance_util.get_y_pred(
                y_pred_proba, threshold)
            mask_tp = metrics.mask_true_positive(y_true, y_pred)
            mask_fp = metrics.mask_false_positive(y_true, y_pred)
            return mask_fp.sum() / mask_tp.sum() - fptp

        if func_to_minimize(min_val) * func_to_minimize(max_val) > 0:
            return np.nan
        res = bisect(func_to_minimize, min_val, max_val, xtol=1e-15)
        return res

    @staticmethod
    def reject_ratio_theshold(
            reject_ratio: float, y_true: np.array, y_pred_proba: np.ndarray,
            min_val: float = 0.001, max_val: float = 0.999) -> float:
        """Return the threshold for a given reject_ratio.

        Parameters
        ----------
        reject_ratio : float
            Reject ratio.
        y_true : np.ndarray
                True target values.
        y_pred_proba : np.ndarray
               Model score values.
        min_val : float, defaults to 0.001
                Minimal threshold value to consider.
        max_val : float, defaults to 0.999
                Maximal threshold value to consider.

        Returns
        -------
            float: Threshold value.
        """

        def func_to_minimize(threshold: float) -> float:
            """Return value to minimize.

            Parameters
            ----------
            threshold : float
                Threshold value.

            Returns
            -------
            float:
                Value to minimize.
          """
            y_pred = model_performance_util.get_y_pred(
                y_pred_proba, threshold)
            return y_pred.mean() - reject_ratio

        if func_to_minimize(min_val) * func_to_minimize(max_val) > 0:
            return np.nan
        res = bisect(func_to_minimize, min_val, max_val, xtol=1e-15)
        return res
