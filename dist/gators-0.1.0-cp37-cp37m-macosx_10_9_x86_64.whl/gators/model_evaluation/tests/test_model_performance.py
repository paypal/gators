# # License: Apache-2.0
# from gators.model_performance import metrics
# from gators.model_performance.plotter import Plotter
# from gators.model_performance.model_performance import ModelPerformance
# from sklearn.metrics import confusion_matrix
# from sklearn.metrics import recall_score
# from sklearn.metrics import precision_score
# from sklearn.metrics import f1_score
# from pandas.testing import assert_series_equal
# import numpy as np
# import pytest
# import pandas as pd

# y_true = np.array([0, 0, 0, 1, 1])
# y_pred_proba = np.array([0.1, 0.7, 0.8, 0.2, 0.9])
# y_pred = (y_pred_proba > 0.5)
# amount = np.array([10., 20., 30., 40., 50.])


# @pytest.fixture
# def perfs_transaction():
#     ml_perf = ModelPerformance(
#         y_true=y_true,
#         y_pred_proba=y_pred_proba,
#         amount=amount,
#     )
#     return ml_perf.performances(thresholds=[0.5], betas=[1.])


# @pytest.fixture
# def perfs():
#     ml_perf = ModelPerformance(
#         y_true=y_true,
#         y_pred_proba=y_pred_proba,
#     )
#     return ml_perf.performances(thresholds=[0.5], betas=[1.])


# def test_precision_score(perfs):
#     p = precision_score(y_true, y_pred)
#     np.testing.assert_allclose(perfs['precision'], p)


# def test_recall_score(perfs):
#     r = recall_score(y_true, y_pred)
#     np.testing.assert_allclose(perfs['recall'], r)


# def test_f1_score(perfs):
#     f1 = f1_score(y_true, y_pred)
#     np.testing.assert_allclose(perfs['F1'], f1)


# def test_confusion_matrix_tn(perfs):
#     [[tn, _], [_, _]] = metrics.confusion_matrix(y_true, y_pred)
#     np.testing.assert_allclose(perfs['tn(count)'], tn)


# def test_precision_score(perfs):
#     p = precision_score(y_true, y_pred)
#     np.testing.assert_allclose(perfs['precision'], round(p, 2))


# def test_recall_score(perfs):
#     r = recall_score(y_true, y_pred)
#     np.testing.assert_allclose(perfs['recall'], r)


# def test_f1_score(perfs):
#     f1 = f1_score(y_true, y_pred)
#     np.testing.assert_allclose(perfs['F1'], f1)


# def test_confusion_matrix_tn(perfs):
#     [[tn, fp], [fn, tp]] = metrics.confusion_matrix(y_true, y_pred)
#     np.testing.assert_allclose(perfs['tn(count)'], tn)


# def test_confusion_matrix_fp(perfs):
#     [[tn, fp], [fn, tp]] = metrics.confusion_matrix(y_true, y_pred)
#     np.testing.assert_allclose(perfs['fp(count)'], fp)


# def test_confusion_matrix_fp(perfs):
#     [[tn, fp], [fn, tp]] = metrics.confusion_matrix(y_true, y_pred)
#     np.testing.assert_allclose(perfs['fp(count)'], fp)


# def test_confusion_matrix_fn(perfs):
#     [[tn, fp], [fn, tp]] = metrics.confusion_matrix(y_true, y_pred)
#     np.testing.assert_allclose(perfs['fn(count)'], fn)


# def test_confusion_matrix_fn(perfs):
#     [[tn, fp], [fn, tp]] = metrics.confusion_matrix(y_true, y_pred)
#     np.testing.assert_allclose(perfs['fn(count)'], fn)


# def test_confusion_matrix_tp(perfs):
#     [[tn, fp], [fn, tp]] = metrics.confusion_matrix(y_true, y_pred)
#     np.testing.assert_allclose(perfs['tp(count)'], tp)


# def test_confusion_matrix_tp(perfs):
#     [[tn, fp], [fn, tp]] = metrics.confusion_matrix(y_true, y_pred)
#     np.testing.assert_allclose(perfs['tp(count)'], tp)


# def test_plot_fscores(perfs):
#     perf_plotter = Plotter(perfs=perfs)
#     _ = perf_plotter.plot_fscores()
#     assert True


# def test_plot_roc_curve(perfs):
#     perf_plotter = Plotter(perfs=perfs)
#     _ = perf_plotter.plot_roc_curve()
#     assert True


# def test_plot_precision_recall_curve(perfs):
#     perf_plotter = Plotter(perfs=perfs)
#     _ = perf_plotter.plot_precision_recall_curve()
#     assert True


# def test_fptp_thresholds():
#     perfs = ModelPerformance(
#         y_true=y_true,
#         y_pred_proba=y_pred_proba,
#     )
#     fptp_thresholds = perfs.fptp_thresholds(
#         fptps_values=[1.],
#         min_val=0.001,
#         max_val=1.,
#     )
#     fptp_thresholds_expected = pd.Series([0.75025], index=[1.])
#     fptp_thresholds_expected.index.name = 'fptp'
#     assert_series_equal(fptp_thresholds, fptp_thresholds_expected)
