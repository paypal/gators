# License: Apache-2.0
from ..util import util
from ..transformer.transformer import Transformer
import numpy as np
from typing import List, Union
import pandas as pd
import databricks.koalas as ks


class BaseFeatureGen(Transformer):
    """Base Feature Generation class.

    Parameters
    ----------
        Transformer (Transformer): Transformer abstract class.
    """

    def __init__(self):
        """Init Base Feature Generation class.

        Parameters
        ----------
        is_null_columns : List[str]
            List of columns.
        """
        Transformer.__init__(self)
        self.column_names: List[str] = []
        self.idx_cluster_columns: np.ndarray = np.array([])
    
