import numpy as np
import pandas as pd
from typing import List, Union
import databricks.koalas as ks
from ..util import util
from gators.transformer import Transformer
from itertools import combinations, combinations_with_replacement, chain
from feature_gen import polynomial, polynomial_object


class PolynomialFeatures(Transformer):
    """Create new columns based on columns multiplication.

    Parameters
    ----------
    columns : List[str]
        List of columns.
    degree : int, default = 2
        The degree of polynomial. The default of degree of 2
        will produce A * A, B * B, and A  * B from features A and B.
    interaction_only : bool, default = False
        Allows to keep only interaction terms.
        If true, only A * B will be produced from features A and B.


    Examples
    ---------

    >>> import pandas as pd
    >>> from gators.feature_generation import PolynomialFeatures
    >>> X = pd.DataFrame(
    ... np.arange(9).reshape(3, 3), columns=list('ABC'), dtype=np.float64)
    >>> obj = PolynomialFeatures(columns=['A', 'B'])
    >>> obj.fit_transform(X)
         A    B    C  A__x__A  A__x__B  B__x__B
    0  0.0  1.0  2.0    0.0    0.0    1.0
    1  3.0  4.0  5.0    9.0   12.0   16.0
    2  6.0  7.0  8.0   36.0   42.0   49.0

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation import PolynomialFeatures
    >>> X = ks.DataFrame(
    ... np.arange(9).reshape(3, 3), columns=list('ABC')).astype(float)
    >>> columns = util.get_numerical_columns(X)
    >>> obj = PolynomialFeatures(columns, degree = 3, interaction_only=True)
    >>> obj.fit_transform(X)
         A    B    C  A__x__B  A__x__C  B__x__C  A__x__B__x__C
    0  0.0  1.0  2.0    0.0    0.0    2.0        0.0
    1  3.0  4.0  5.0   12.0   15.0   20.0       60.0
    2  6.0  7.0  8.0   42.0   48.0   56.0      336.0

    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.feature_generation import PolynomialFeatures
    >>> X = pd.DataFrame(
    ... np.arange(9).reshape(3, 3), columns=list('ABC'), dtype=np.float64)
    >>> columns = util.get_numerical_columns(X)
    >>> obj = PolynomialFeatures(columns, degree=2, interaction_only=True)
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[ 0.,  1.,  2.,  0.,  0.,  2.],
           [ 3.,  4.,  5., 12., 15., 20.],
           [ 6.,  7.,  8., 42., 48., 56.]])

    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.feature_generation import PolynomialFeatures
    >>> X = ks.DataFrame(np.arange(9).reshape(3, 3), columns=list('ABC'), dtype=np.float64)
    >>> columns = util.get_numerical_columns(X)
    >>> obj = PolynomialFeatures(columns, degree=2, interaction_only=True)
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[ 0.,  1.,  2.,  0.,  0.,  2.],
           [ 3.,  4.,  5., 12., 15., 20.],
           [ 6.,  7.,  8., 42., 48., 56.]])
    """

    def __init__(self, columns: List[str], degree=2, interaction_only=False):
        if not isinstance(columns, list):
            raise TypeError('`columns` should be a list.')
        if not columns:
            raise ValueError('`columns` should not be empty.')
        if not isinstance(degree, int):
            raise TypeError('`degree` should be an int.')
        if degree < 2:
            raise ValueError('`degree` should be at least 2.')
        if not isinstance(interaction_only, bool):
            raise TypeError('`interaction_only` should be a bool.')
        if interaction_only == True and len(columns) == 1:
            raise ValueError(
                'Cannot create interaction only terms from single feature.')
        self.columns = columns
        self.degree = degree
        self.method = (
            combinations if interaction_only else combinations_with_replacement
        )
        self.combinations = list(
            map(list, chain.from_iterable(
                self.method(columns, self.degree)
                for self.degree in range(self.degree + 1)))
        )
        self.combinations = [c for c in self.combinations if len(c) >= 2]
        self.column_names = ['__x__'.join(map(str, combination))
                             for combination in self.combinations]
        self.column_mapping = dict(
            zip(self.column_names, map(list, self.combinations)))

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'PolynomialFeatures':
        """
        Fit the dataframe X.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
            y (np.ndarray, optional): labels. Defaults to None.

        Returns
        -------
            PolynomialFeatures: Instance of itself.
        """
        self.check_dataframe(X)
        self.idx_columns = util.get_idx_columns(
            columns=X.columns,
            selected_columns=self.columns
        )
        self.n_rows = X[self.columns].shape[0]
        self.n_cols = X[self.columns].shape[1]
        self.combinations_np = list(
            map(list, chain.from_iterable(
                self.method(self.idx_columns, self.degree)
                for self.degree in range(self.degree + 1)))
        )
        self.combinations_np = [c for c in self.combinations_np if len(c) >= 2]
        for combo in self.combinations_np:
            combo.extend([-1 for _ in range(self.degree - len(combo))])
        self.combinations_np = np.array(self.combinations_np)
        return self

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """
        self.check_dataframe(X)
        X[self.columns] = X[self.columns].astype(float)
        if isinstance(X, pd.DataFrame):
            for combi, name in zip(self.combinations, self.column_names):
                X[name] = X[combi].prod(axis=1)
            return X
        # ks.set_option('compute.ops_on_diff_frames', True)
        for combi, name in zip(self.combinations, self.column_names):
            dummy = X[combi[0]] * X["__x__".join(combi[1:])]
            X = X.assign(
                dummy=dummy
            ).rename(columns={'dummy': name})
        #     X[name] = X[combi].prod(axis=1)
        # ks.set_option('compute.ops_on_diff_frames', False)

        return X

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        if X.dtype == int:
            X = X.astype(np.float64)
        self.check_array(X)
        if X.dtype == object:
            return polynomial_object(
                X, self.combinations_np, self.degree)
        return polynomial(
            X, self.combinations_np, self.degree)
