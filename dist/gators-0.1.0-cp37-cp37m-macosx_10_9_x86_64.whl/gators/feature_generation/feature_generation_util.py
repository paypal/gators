# License: Apache-2.0
import numpy as np
from typing import List, Union, Tuple, Dict
import pandas as pd
import databricks.koalas as ks


def get_num_days_in_month(year: Union[pd.Series, ks.Series],month: np.ndarray) -> np.ndarray:
    """Get the number of days in a month.

        Parameters
        ----------
        year : np.ndarray
            Years.
        month :np.ndarray
            Months of the year.

        Returns
        -------
        np.ndarray
            True if year is a leap year.
        """

    is_leap_year = \
        ((year % 4 == 0) & (year % 100 != 0)) | (year % 400 == 0)
    is_leap_year = is_leap_year.astype(int)
    n_days_of_month = np.array(
        [[0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
            [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
         ])
    return n_days_of_month[is_leap_year, month.astype(int)]
