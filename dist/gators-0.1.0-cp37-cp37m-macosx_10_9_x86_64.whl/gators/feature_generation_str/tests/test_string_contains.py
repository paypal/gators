# License: Apache-2.0
from gators.feature_generation_str import StringContains
from pandas.testing import assert_frame_equal
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    X = pd.DataFrame(np.zeros((3, 3)), columns=list('qwe'))
    X['a'] = ['0', '1Q', '1QQ']
    X['s'] = ['0', 'W2', 'W2W']
    X['d'] = ['0', 'Q', '']
    X_ks = ks.from_pandas(X)
    obj_pd = StringContains(
        columns=list('asd'), contains_vec=['1', '2', '0']).fit(X)
    obj_ks = StringContains(
        columns=list('asd'), contains_vec=['1', '2', '0']).fit(X_ks)
    columns_expected = [
        'q', 'w', 'e', 'a', 's', 'd',
        'a__contains_1', 's__contains_2',	'd__contains_0']
    X_expected = pd.DataFrame(
        [[0.0, 0.0, 0.0, '0', '0', '0', 0.0, 0.0, 1.0],
         [0.0, 0.0, 0.0, '1Q', 'W2', 'Q', 1.0, 1.0, 0.0],
         [0.0, 0.0, 0.0, '1QQ', 'W2W', '', 1.0, 1.0, 0.0]],
        columns=columns_expected)
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_with_names():
    X = pd.DataFrame(np.zeros((3, 3)), columns=list('qwe'))
    X['a'] = ['0', '1Q', '1QQ']
    X['s'] = ['0', 'W2', 'W2W']
    X['d'] = ['0', 'Q', '']
    X_ks = ks.from_pandas(X)
    obj_pd = StringContains(
        columns=list('asd'),
        contains_vec=['1', '2', '0'],
        column_names=['a_with_1', 's_with_2', 'd_with_0']).fit(X)
    obj_ks = StringContains(
        columns=list('asd'),
        contains_vec=['1', '2', '0'],
        column_names=['a_with_1', 's_with_2', 'd_with_0']).fit(X_ks)
    columns_expected = [
        'q', 'w', 'e', 'a', 's', 'd', 'a_contains_1',
        's_contains_2',	'd_contains_0']
    X_expected = pd.DataFrame(
        [[0.0, 0.0, 0.0, '0', '0', '0', 0.0, 0.0, 1.0],
         [0.0, 0.0, 0.0, '1Q', 'W2', 'Q', 1.0, 1.0, 0.0],
         [0.0, 0.0, 0.0, '1QQ', 'W2W', '', 1.0, 1.0, 0.0]],
        columns=columns_expected)
    return obj_pd, obj_ks, X, X_ks, X_expected


def test_pd(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected.astype(object))


@pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected.astype(object))


def test_init():
    with pytest.raises(TypeError):
        _ = StringContains(
            columns='x', contains_vec=['z', 'x'], column_names=['aa', 'ss']
        )
    with pytest.raises(TypeError):
        _ = StringContains(
            columns=['a', 's'], contains_vec='x', column_names=['aa', 'ss']
        )
    with pytest.raises(TypeError):
        _ = StringContains(
            columns=['a', 's'], contains_vec=['z', 'x'], column_names='x'
        )
    with pytest.raises(ValueError):
        _ = StringContains(
            columns=['a', 's'], contains_vec=['z'], column_names=['aa', 'ss']
        )
    with pytest.raises(ValueError):
        _ = StringContains(
            columns=['a', 's'], contains_vec=['z', 'x'], column_names=['aa']
        )
