# License: Apache-2.0
from typing import Union
import numpy as np
import pandas as pd
import databricks.koalas as ks


def get_num_days_in_month(
        year: Union[np.ndarray, int],
        month: Union[np.ndarray, int]) -> Union[np.ndarray, bool]:
    """Get the number of days in a month.

    Parameters
    ----------
    year (Union[np.ndarray, int]): Year.
    month (Union[np.ndarray, int]): Month of the year.

    Returns
    -------
    Union[np.ndarray, bool]
        True if the year is a leap year.
    """
    is_leap_year = \
        ((year % 4 == 0) & (year % 100 != 0)) | (year % 400 == 0)
    if isinstance(is_leap_year, int):
        is_leap_year = int(is_leap_year)
    else:
        is_leap_year = is_leap_year.astype(int)
    n_days_of_month = np.array(
        [[0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
            [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
         ])
    num_days_in_month = np.empty(month.shape)
    num_days_in_month = n_days_of_month[is_leap_year, month.astype(int)]
    return num_days_in_month
