# License: Apache-2.0
from gators.feature_generation_dt import CyclicMonthOfYear
from pandas.testing import assert_frame_equal
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    X = pd.DataFrame(
        {
            'A': {0: '2020-01-01T00'},
            'B': {0: '2020-04-08T06'},
            'C': {0: '2020-07-16T12'},
            'D': {0: '2020-10-24T18'},
            'E': {0: '2020-12-31T23'},
            'X': {0: 'x'}
        }
    )
    columns = ['A', 'B', 'C', 'D', 'E']
    X['A'] = X['A'].astype('datetime64[ns]')
    X['B'] = X['B'].astype('datetime64[ms]')
    X['C'] = X['C'].astype('datetime64[s]')
    X['D'] = X['D'].astype('datetime64[m]')
    X['E'] = X['E'].astype('datetime64[h]')
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(
        {
            'A__month_of_year_cos': {0: 1.0},
            'A__month_of_year_sin': {0: 0.0},
            'B__month_of_year_cos': {0: -0.142314838273285},
            'B__month_of_year_sin': {0: 0.9898214418809328},
            'C__month_of_year_cos': {0: -0.9594929736144975},
            'C__month_of_year_sin': {0: -0.28173255684142945},
            'D__month_of_year_cos': {0: 0.41541501300188605},
            'D__month_of_year_sin': {0: -0.9096319953545186},
            'E__month_of_year_cos': {0: 1.0},
            'E__month_of_year_sin': {0: -1.133107779529596e-15}
        }
    )
    X_expected = pd.concat([X.copy(), X_expected], axis=1)
    obj_pd = CyclicMonthOfYear(columns=columns).fit(X)
    obj_ks = CyclicMonthOfYear(columns=columns).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_with_nan():
    X = pd.DataFrame(
        {
            'A': {0: '2020-01-01T00', 1: None},
            'B': {0: '2020-04-08T06', 1: None},
            'C': {0: '2020-07-16T12', 1: None},
            'D': {0: '2020-10-24T18', 1: None},
            'E': {0: '2020-12-31T23', 1: None},
            'X': {0: 'x', 1: 'x'},
        }
    )
    columns = ['A', 'B', 'C', 'D', 'E']
    X['A'] = X['A'].astype('datetime64[ns]')
    X['B'] = X['B'].astype('datetime64[ms]')
    X['C'] = X['C'].astype('datetime64[s]')
    X['D'] = X['D'].astype('datetime64[m]')
    X['E'] = X['E'].astype('datetime64[h]')
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(
        {
            'A__month_of_year_cos': {0: 1.0, 1: np.nan},
            'A__month_of_year_sin': {0: 0.0, 1: np.nan},
            'B__month_of_year_cos': {0: -0.142314838273285, 1: np.nan},
            'B__month_of_year_sin': {0: 0.9898214418809328, 1: np.nan},
            'C__month_of_year_cos': {0: -0.9594929736144975, 1: np.nan},
            'C__month_of_year_sin': {0: -0.28173255684142945, 1: np.nan},
            'D__month_of_year_cos': {0: 0.41541501300188605, 1: np.nan},
            'D__month_of_year_sin': {0: -0.9096319953545186, 1: np.nan},
            'E__month_of_year_cos': {0: 1.0, 1: np.nan},
            'E__month_of_year_sin': {0: -1.133107779529596e-15, 1: np.nan},
        }
    )
    X_expected = pd.concat([X.copy(), X_expected], axis=1)
    obj_pd = CyclicMonthOfYear(columns=columns).fit(X)
    obj_ks = CyclicMonthOfYear(columns=columns).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


def test_pd(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_pd.fit_transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


def test_with_nan_pd(data_with_nan):
    obj_pd, obj_ks, X, X_ks, X_expected = data_with_nan
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_with_nan_ks(data_with_nan):
    obj_pd, obj_ks, X, X_ks, X_expected = data_with_nan
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_with_nan_pd_np(data_with_nan):
    obj_pd, obj_ks, X, X_ks, X_expected = data_with_nan
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_with_nan_ks_np(data_with_nan):
    obj_pd, obj_ks, X, X_ks, X_expected = data_with_nan
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


def test_init():
    with pytest.raises(TypeError):
        _ = CyclicMonthOfYear(columns=0)
    with pytest.raises(ValueError):
        _ = CyclicMonthOfYear(columns=[])
