# License: Apache-2.0
from gators.feature_generation_dt import CyclicDayOfMonth
from pandas.testing import assert_frame_equal
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    X = pd.DataFrame(
        {
            'A': {0: '2021-02-28T06'},
            'B': {0: '2020-02-29T06'},
            'C': {0: '2020-03-01T12'},
            'D': {0: '2020-04-01T18'},
            'E': {0: '2020-05-31T23'},
            'X': {0: 'x'}
        }
    )
    columns = ['A', 'B', 'C', 'D', 'E']
    X['A'] = X['A'].astype('datetime64[ns]')
    X['B'] = X['B'].astype('datetime64[ms]')
    X['C'] = X['C'].astype('datetime64[s]')
    X['D'] = X['D'].astype('datetime64[m]')
    X['E'] = X['E'].astype('datetime64[h]')
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(
        {
            'A__day_of_month_cos': {0: 1.0},
            'A__day_of_month_sin': {0: 0.0},
            'B__day_of_month_cos': {0: 1.0},
            'B__day_of_month_sin': {0: 0.0},
            'C__day_of_month_cos': {0: 1.0},
            'C__day_of_month_sin': {0: 0.0},
            'D__day_of_month_cos': {0: 1.0},
            'D__day_of_month_sin': {0: 0.0},
            'E__day_of_month_cos': {0: 1.0},
            'E__day_of_month_sin': {0: 0.0},
        }
    )
    X_expected = pd.concat([X.copy(), X_expected], axis=1)
    obj_pd = CyclicDayOfMonth(columns=columns).fit(X)
    obj_ks = CyclicDayOfMonth(columns=columns).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_with_nan():
    X = pd.DataFrame(
        {
            'A': {0: '2021-02-28T06', 1: None},
            'B': {0: '2020-02-29T06', 1: None},
            'C': {0: '2020-03-01T12', 1: None},
            'D': {0: '2020-04-01T18', 1: None},
            'E': {0: '2020-05-31T23', 1: None},
            'X': {0: 'x', 1: 'x'}
        }
    )
    columns = ['A', 'B', 'C', 'D', 'E']
    X['A'] = X['A'].astype('datetime64[ns]')
    X['B'] = X['B'].astype('datetime64[ms]')
    X['C'] = X['C'].astype('datetime64[s]')
    X['D'] = X['D'].astype('datetime64[m]')
    X['E'] = X['E'].astype('datetime64[h]')
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(
        {
            'A__day_of_month_cos': {0: 1.0, 1: np.nan},
            'A__day_of_month_sin': {0: 0.0, 1: np.nan},
            'B__day_of_month_cos': {0: 1.0, 1: np.nan},
            'B__day_of_month_sin': {0: 0.0, 1: np.nan},
            'C__day_of_month_cos': {0: 1.0, 1: np.nan},
            'C__day_of_month_sin': {0: 0.0, 1: np.nan},
            'D__day_of_month_cos': {0: 1.0, 1: np.nan},
            'D__day_of_month_sin': {0: 0.0, 1: np.nan},
            'E__day_of_month_cos': {0: 1.0, 1: np.nan},
            'E__day_of_month_sin': {0: 0.0, 1: np.nan},

        }
    )
    X_expected = pd.concat([X.copy(), X_expected], axis=1)
    obj_pd = CyclicDayOfMonth(columns=columns).fit(X)
    obj_ks = CyclicDayOfMonth(columns=columns).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


def test_pd(data):
    obj_pd, _, X, _, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


def test_with_nan_pd(data_with_nan):
    obj_pd, obj_ks, X, X_ks, X_expected = data_with_nan
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_with_nan_ks(data_with_nan):
    obj_pd, obj_ks, X, X_ks, X_expected = data_with_nan
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_with_nan_pd_np(data_with_nan):
    obj_pd, obj_ks, X, X_ks, X_expected = data_with_nan
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_with_nan_ks_np(data_with_nan):
    obj_pd, obj_ks, X, X_ks, X_expected = data_with_nan
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


# def test_get_num_days_in_month():
#     n_days_feb = get_num_days_in_month(
#         np.arange(2000, 2010).reshape(1, -1),
#         2 * np.ones(10, int).reshape(1, -1))
#     n_days_feb_expected = np.array([
#         29, 28, 28, 28, 29, 28, 28, 28, 29, 28])
#     assert np.allclose(n_days_feb, n_days_feb_expected)


def test_init():
    with pytest.raises(TypeError):
        _ = CyclicDayOfMonth(columns=0)
    with pytest.raises(ValueError):
        _ = CyclicDayOfMonth(columns=[])
