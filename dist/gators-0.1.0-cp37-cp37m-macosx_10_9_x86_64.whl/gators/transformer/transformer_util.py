# from typing import List


# def is_object_used(columns: List[str], patterns: List[str]) -> bool:
#     """True if object is used.

#     Parameters
#     ----------
#     columns : List[str]
#             List of column names.
#         patterns : List[str]
#             List of feature name patterns.

#     Returns
#     -------
#         bool: True if object is used.
#     """
#     used_columns = []
#     for pattern in patterns:
#         used_columns += [c for c in columns
#                          if pattern in c]
#     if not used_columns:
#         return False
#     return True


# def get_base_column_names(
#         columns: List[str], patterns: List[str]) -> List[str]:
#     """Return the base column names used to generate the columns.

#     Parameters
#     ----------
#     columns : List[str]
#             List of column names.
#         patterns : List[str]
#             List of feature name patterns.

#     Returns
#     -------
#         List[str]: List of column names.
#     """
#     base_columns = []
#     for pattern in patterns:
#         base_columns += [
#             c.split(pattern)[0] for c in columns
#             if pattern in c
#         ]
#     return list(set(base_columns))


# def get_unused_column_names(
#         columns: List[str], patterns) -> List[str]:
#     """Return the name of the engineered column names present in the input list.

#     Parameters
#     ----------
#     columns : List[str]
#             List of column names.
#         used_columns : List[str]
#             List of used column names.
#     Returns
#     -------
#         List[str]: List of unused column names.
#     """
#     base_columns = get_base_column_names(columns, patterns)
#     unused_columns = []
#     for c in base_columns:
#         for pattern in patterns:
#             gen_column = c + pattern
#             if c + pattern not in columns:
#                 unused_columns.append(gen_column)
#     return unused_columns
