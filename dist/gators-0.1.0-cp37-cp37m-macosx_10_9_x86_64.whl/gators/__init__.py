import os
os.environ["PYARROW_IGNORE_TIMEZONE"] = "1"
