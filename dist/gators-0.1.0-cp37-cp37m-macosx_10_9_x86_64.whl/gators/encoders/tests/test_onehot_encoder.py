# License: Apache-2.0
from gators.encoders.onehot_encoder import OneHotEncoder
from pandas.testing import assert_frame_equal
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():

    X = pd.DataFrame(
        {
            'A': ['Q', 'Q', 'W'],
            'B': ['Q', 'W', 'W'],
            'C': ['W', 'Q', 'W'],
            'D': [1, 2, 3]
        }
    )
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(
        {'D': {0: 1.0, 1: 2.0, 2: 3.0},
         'A__W': {0: 0.0, 1: 0.0, 2: 1.0},
         'A__Q': {0: 1.0, 1: 1.0, 2: 0.0},
         'A__MISSING': {0: 0.0, 1: 0.0, 2: 0.0},
         'A__OTHERS': {0: 0.0, 1: 0.0, 2: 0.0},
         'B__W': {0: 0.0, 1: 1.0, 2: 1.0},
         'B__Q': {0: 1.0, 1: 0.0, 2: 0.0},
         'B__MISSING': {0: 0.0, 1: 0.0, 2: 0.0},
         'B__OTHERS': {0: 0.0, 1: 0.0, 2: 0.0},
         'C__W': {0: 1.0, 1: 0.0, 2: 1.0},
         'C__Q': {0: 0.0, 1: 1.0, 2: 0.0},
         'C__MISSING': {0: 0.0, 1: 0.0, 2: 0.0},
         'C__OTHERS': {0: 0.0, 1: 0.0, 2: 0.0}}
    )
    obj_pd = OneHotEncoder().fit(X)
    obj_ks = OneHotEncoder().fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_no_cat():
    X = pd.DataFrame(
        np.arange(12).reshape(3, 4),
        columns=list('ABCD'), dtype=float,
    )
    X_ks = ks.from_pandas(X)
    obj_pd = OneHotEncoder().fit(X)
    obj_ks = OneHotEncoder().fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X.copy()


def test_pd(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy = X.to_numpy()
    X_numpy_new = obj_pd.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


####

def test_without_cat_pd(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_without_cat_ks(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_without_cat_pd_np(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_numpy = X.to_numpy()
    X_numpy_new = obj_pd.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_without_cat_ks_np(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)
