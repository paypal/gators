# License: Apache-2.0
from gators.clipping.clipping import Clipping
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
from pandas.testing import assert_frame_equal
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    np.random.seed(0)
    X = pd.DataFrame(
        np.random.randn(5, 3),
        columns=list('ABC')
    )
    X_ks = ks.from_pandas(X)
    clip_dict = {'A': [-0.5, 0.5], 'B': [-0.5, 0.5], 'C': [-100., 1.]}
    obj_pd = Clipping(clip_dict=clip_dict).fit(X)
    obj_ks = Clipping(clip_dict=clip_dict).fit(X_ks)
    X_expected = pd.DataFrame(
        {'A': {0: 0.5,
               1: 0.5,
               2: 0.5,
               3: 0.4105985019,
               4: 0.5},
         'B': {0: 0.400157208,
               1: 0.5,
               2: -0.1513572082976979,
               3: 0.144043571160878,
               4: 0.12167501649282841},
            'C': {0: 0.9787379841057392,
                  1: -0.977277879876411,
                  2: -0.10321885179355784,
                  3: 1.0,
                  4: 0.4438632327}}
    )
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_int16():
    np.random.seed(0)
    X = pd.DataFrame(
        5 * np.random.randn(5, 3),
        columns=list('ABC')
    ).astype(np.int16)
    X_ks = ks.from_pandas(X)
    clip_dict = {'A': [-5, 2], 'B': [-1, 3], 'C': [-2, 5]}
    obj_pd = Clipping(clip_dict=clip_dict, dtype=np.int16).fit(X)
    obj_ks = Clipping(clip_dict=clip_dict, dtype=np.int16).fit(X_ks)
    X_expected = pd.DataFrame({
        'A': {0: 2, 1: 2, 2: 2, 3: 2, 4: 2},
        'B': {0: 2, 1: 3, 2: 0, 3: 0, 4: 0},
        'C': {0: 4, 1: -2, 2: 0, 3: 5, 4: 2}}
    ).astype(np.int16)
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_partial():
    np.random.seed(0)
    X = pd.DataFrame(
        np.random.randn(5, 3),
        columns=list('ABC')
    )
    X_ks = ks.from_pandas(X)
    clip_dict = {'A': [-0.5, 0.5], 'B': [-0.5, 0.5]}
    obj_pd = Clipping(clip_dict=clip_dict).fit(X)
    obj_ks = Clipping(clip_dict=clip_dict).fit(X_ks)
    X_expected = pd.DataFrame(
        {'A': {0: 0.5,
               1: 0.5,
               2: 0.5,
               3: 0.4105985019,
               4: 0.5},
         'B': {0: 0.400157208,
               1: 0.5,
               2: -0.1513572082976979,
               3: 0.144043571160878,
               4: 0.12167501649282841},
            'C': {0: 0.9787379841057392,
                  1: -0.977277879876411,
                  2: -0.10321885179355784,
                  3: 1.454274,
                  4: 0.4438632327}}
    )
    return obj_pd, obj_ks, X, X_ks, X_expected


def test_pd(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    assert np.allclose(X_new, X_expected.to_numpy())


@ pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    assert np.allclose(X_new, X_expected.to_numpy())


def test_int16_pd(data_int16):
    obj_pd, obj_ks, X, X_ks, X_expected = data_int16
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_int16_ks(data_int16):
    obj_pd, obj_ks, X, X_ks, X_expected = data_int16
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_int16_pd_np(data_int16):
    obj_pd, obj_ks, X, X_ks, X_expected = data_int16
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    assert np.allclose(X_new, X_expected.to_numpy())


@ pytest.mark.koalas
def test_int16_ks_np(data_int16):
    obj_pd, obj_ks, X, X_ks, X_expected = data_int16
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    assert np.allclose(X_new, X_expected.to_numpy())


def test_partial_pd(data_partial):
    obj_pd, obj_ks, X, X_ks, X_expected = data_partial
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@ pytest.mark.koalas
def test_partial_ks(data_partial):
    obj_pd, obj_ks, X, X_ks, X_expected = data_partial
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_partial_pd_np(data_partial):
    obj_pd, obj_ks, X, X_ks, X_expected = data_partial
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    assert np.allclose(X_new, X_expected.to_numpy())


@ pytest.mark.koalas
def test_partial_ks_np(data_partial):
    obj_pd, obj_ks, X, X_ks, X_expected = data_partial
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    assert np.allclose(X_new, X_expected.to_numpy())


def test_init(data):
    with pytest.raises(TypeError):
        _ = Clipping(clip_dict=0)
    with pytest.raises(ValueError):
        _ = Clipping(clip_dict={})
