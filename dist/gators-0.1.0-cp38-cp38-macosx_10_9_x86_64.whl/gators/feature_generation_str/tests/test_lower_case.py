# License: Apache-2.0
from gators.feature_generation_str import LowerCase
from pandas.testing import assert_frame_equal
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    X = pd.DataFrame(np.zeros((3, 3)), columns=list('qwe'))
    X['a'] = ['q', 'qq', 'QQq']
    X['s'] = ['w', 'WW', 'WWw']
    X['d'] = ['nan', None, '']
    X_ks = ks.from_pandas(X)
    obj_pd = LowerCase(columns=list('asd')).fit(X)
    obj_ks = LowerCase(columns=list('asd')).fit(X_ks)
    columns_expected = [
        'q', 'w', 'e', 'a', 's', 'd']
    X_expected = pd.DataFrame(
        [[0.0, 0.0, 0.0, 'q', 'w', 'nan', ],
         [0.0, 0.0, 0.0, 'qq', 'ww', None, ],
         [0.0, 0.0, 0.0, 'qqq', 'www', '']],
        columns=columns_expected)
    return obj_pd, obj_ks, X, ks.from_pandas(X), X_expected


def test_pd(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected.astype(object))


@pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected.astype(object))


def test_init():
    with pytest.raises(TypeError):
        _ = LowerCase(columns='x')
    with pytest.raises(ValueError):
        _ = LowerCase(columns=[])
