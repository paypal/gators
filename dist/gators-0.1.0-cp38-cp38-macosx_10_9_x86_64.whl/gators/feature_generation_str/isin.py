# License: Apache-2.0
from ..transformer.transformer import Transformer
from ..util import util
from feature_gen_str import isin
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from._base_string_feature import _BaseStringFeature


class IsIn(_BaseStringFeature):
    """Is In Transformer.

    Parameters
    ----------
    columns : List[str]
        List of columns.

    column_names : List[str]
        List of the new column names.

    values_vec : List[List[str]]
        List of values to match.

    Examples
    ---------
    * fit & transform with pandas
    >>> import pandas as pd
    >>> from gators.feature_generation_str import IsIn
    >>> X = pd.DataFrame({'A': ['aaa', 'bbb', 'c'], 'B': ['dd', 'ee', None]}
    >>> obj = IsIn(
    ...    columns=['A', 'A', 'B'], column_names=['X', 'Y', 'Z'],
    ...    values_vec=[['aaa', 'bbb', 'ccc'], ['a', 'c'], ['dd']])
    >>> obj.fit_transform(X)
        A     B    X    Y    Z
    0  aaa    dd  1.0  0.0  1.0
    1  bbb    ee  1.0  0.0  0.0
    2    c  None  0.0  1.0  0.0

    * fit & transform with koalas
    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_str import IsIn
    >>> X = ks.DataFrame({'A': ['qwe', 'as', ''], 'B': [1, 22, 333]})
    >>> obj = IsIn(
    ...    columns=['A', 'A', 'B'], column_names=['X', 'Y', 'Z'],
    ...    values_vec=[['aaa', 'bbb', 'ccc'], ['a', 'c'], ['dd']])
    >>> obj.fit_transform(X)
        A     B    X    Y    Z
    0  aaa    dd  1.0  0.0  1.0
    1  bbb    ee  1.0  0.0  0.0
    2    c  None  0.0  1.0  0.0

    * fit with pandas & transform with numpy
    >>> import pandas as pd
    >>> from gators.feature_generation_str import IsIn
    >>> X = pd.DataFrame({'A': ['aaa', 'bbb', 'c'], 'B': ['dd', 'ee', None]}
    >>> obj = IsIn(
    ...    columns=['A', 'A', 'B'], column_names=['X', 'Y', 'Z'],
    ...    values_vec=[['aaa', 'bbb', 'ccc'], ['a', 'c'], ['dd']])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([['aaa', 'dd', 1.0, 0.0, 1.0, 1.0, 0.0, 1.0],
           ['bbb', 'ee', 1.0, 0.0, 0.0, 1.0, 0.0, 0.0],
           ['c', None, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0]], dtype=object)

    * fit with koalas & transform with numpy
    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_str import IsIn
    >>> X = ks.DataFrame({'A': ['qwe', 'as', ''], 'B': [1, 22, 333]})
    >>> obj = IsIn(
    ...    columns=['A', 'A', 'B'], column_names=['X', 'Y', 'Z'],
    ...    values_vec=[['aaa', 'bbb', 'ccc'], ['a', 'c'], ['dd']])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([['aaa', 'dd', 1.0, 0.0, 1.0, 1.0, 0.0, 1.0],
           ['bbb', 'ee', 1.0, 0.0, 0.0, 1.0, 0.0, 0.0],
           ['c', None, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0]], dtype=object)
    """

    def __init__(self, columns: List[str],
                 column_names: List[str],
                 values_vec: List[List[str]]):
        if not isinstance(values_vec, list):
            raise TypeError('`values_vec` should be a list of list.')
        if len(column_names) != len(values_vec):
            raise ValueError(
                'Length of `values_vec` and `column_names` should match.')
        _BaseStringFeature.__init__(
            self, columns, column_names)
        self.values_vec = values_vec
        max_elements = max([len(values) for values in self.values_vec])
        self.values_vec_np = np.empty((max_elements, len(columns)), object)
        self.n_elements_vec = np.empty(len(columns), np.int64)
        for i, values in enumerate(self.values_vec):
            n_values = len(values)
            self.values_vec_np[i, :n_values] = values
            self.n_elements_vec[i] = n_values

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'IsIn':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
        y None
            None.

        Returns
        -------
        IsIn
            Instance of itself.
        """
        self.check_dataframe(X)
        self.idx_columns = util.get_idx_columns(
            columns=X.columns,
            selected_columns=self.columns
        )
        return self

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """
        self.check_dataframe(X)
        for col, name, values in zip(
                self.columns, self.column_names, self.values_vec):
            X[name] = X[col].isin(values).astype(
                np.float64).replace({None: 0.})
        return X

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        return isin(
            X, self.idx_columns, self.values_vec_np, self.n_elements_vec)
