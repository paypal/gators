# License: Apache-2.0
from cython_binning import bin_numerics, bin_numerics_object
from ..util import util
from ..transformer.transformer import Transformer
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks


EPSILON = 1e-10


class BinNumerics(Transformer):
    """Bin Numerics Transformer.

    Note that difference between Pandas and Koalas are expected due
    to the different quantile computations.

    Parameters
    ----------
    n_bins : int
        Number of bins to use.
    accuracy : float, default to 0.05.
        Relative error to compute the quantiles.

    Examples
    ---------
    * fit & transform with pandas
    >>> import pandas as pd
    >>> from gators.binning import BinNumerics
    >>> X = pd.DataFrame({'A': [-1, 0, 1], 'B': [1, 2, 3]})
    >>> obj = BinNumerics(n_bins=2)
    >>> obj.fit_transform(X)
    A  B  A_bin  B_bin
    0 -1  1    0.0    0.0
    1  0  2    1.0    1.0
    2  1  3    1.0    1.0

    * fit & transform with koalas
    >>> import databricks.koalas as ks
    >>> from gators.binning import BinNumerics
    >>> X = ks.DataFrame({'A': [-1, 0, 1], 'B': [1, 2, 3]})
    >>> obj = BinNumerics(n_bins=2)
    >>> obj.fit_transform(X)
    A  B  A_bin  B_bin
    0 -1  1    0.0    0.0
    1  0  2    1.0    1.0
    2  1  3    1.0    1.0

    * fit with pandas & transform with numpy
    >>> import pandas as pd
    >>> from gators.binning import BinNumerics
    >>> X = pd.DataFrame({'A': [-1., 0., 1.], 'B': [1., 2., 3.]})
    >>> obj = BinNumerics(n_bins=2)
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[-1.,  1.,  0.,  0.],
           [ 0.,  2.,  1.,  1.],
           [ 1.,  3.,  1.,  1.]])

    * fit with koalas & transform with numpy
    >>> import databricks.koalas as ks
    >>> from gators.binning import BinNumerics
    >>> X = ks.DataFrame({'A': [-1, 0, 1], 'B': [1, 2, 3]})
    >>> obj = BinNumerics(n_bins=2)
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[-1.,  1.,  1.,  0.],
           [ 0.,  2.,  0.,  1.],
           [ 1.,  3.,  0.,  1.]])

    """

    def __init__(self, n_bins: int, accuracy: int = 10000):
        if not isinstance(n_bins, int):
            raise TypeError('`n_bins` should be an int.')
        if not isinstance(accuracy, int):
            raise TypeError('`accuracy` should be a float.')
        Transformer.__init__(self)
        self.n_bins = n_bins
        self.columns = []
        self.output_columns = []
        self.idx_columns: np.ndarray = None
        self.bins = pd.DataFrame([])
        self.bins_np = np.array([])
        self.bin_limits = np.array([])
        self.bin_limits_np = np.array([])
        self.q = np.linspace(0, 1, n_bins+1)[1:-1].tolist()
        self.accuracy = accuracy

    def fit(self, X: Union[pd.DataFrame, ks.DataFrame],
            y=None) -> 'BinNumerics':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None.
            labels.

        Returns
        -------
        'BinNumerics'
            Instance of itself.
        """
        self.check_dataframe(X)
        self.columns = util.get_numerical_columns(X)
        self.output_columns = [f'{c}__bin' for c in self.columns]
        self.idx_columns = util.get_idx_columns(
            X.columns, self.columns
        )
        n_cols = len(self.idx_columns)
        if n_cols == 0:
            return self
        if isinstance(X, pd.DataFrame):
            self.bin_limits = X[self.columns].apply(
                self.compute_bins_pd, args=(self.n_bins, )
            )
            self.bins = self.bin_limits.apply(self.get_intervals_pd)
            n_cols = len(self.columns)
            bin_limits_np = np.inf * np.ones((self.n_bins + 1, n_cols))
            for i in range(n_cols):
                j_max = self.bin_limits.iloc[0, i].shape[0]
                bin_limits_np[:j_max, i] = self.bin_limits.iloc[0, i]
            self.bin_limits_np = bin_limits_np
        else:
            self.bin_limits_np = np.inf * \
                np.ones((self.n_bins+1, len(self.columns)))
            self.bin_limits_np[0, :] = -np.inf
            for i, c in enumerate(self.columns):
                dummy = X[c].quantile(
                    self.q, accuracy=self.accuracy).to_numpy()
                dummy = np.unique(dummy)
                self.bin_limits_np[1:1+len(dummy), i] = dummy
        self.bins_np = (np.ones((n_cols, self.n_bins))
                        * np.arange(self.n_bins)).T
        return self

    def transform(self,
                  X: Union[pd.DataFrame, ks.DataFrame]
                  ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """
        self.check_dataframe(X)
        if self.idx_columns.size == 0:
            return X

        if isinstance(X, pd.DataFrame):
            X_bin = X[self.columns].apply(
                self.bin_numerics_pd, args=(self.bins, ))
            X_bin = X_bin.apply(self.replace_bins_pd, args=(
                self.bins, )).astype(np.float64)
            X_bin.columns = self.output_columns
            X_bin.index.name = X.index.name
            return X.join(X_bin)
        else:
            def f(x, cols, shift):
                dummy = 0
                for col in cols:
                    dummy = dummy + x[col]
                return dummy.astype(np.float64)

            for j, c in enumerate(self.columns):
                columns_ = []
                for i, (x, y) in enumerate(
                    zip(
                        self.bin_limits_np.T[j, :-1],
                        self.bin_limits_np.T[j, 1:])):
                    mask = (X[c] > x) & (X[c] <= y)
                    X = X.assign(
                        dummy=X[c].mask(mask, i).mask(~mask, -1)).rename(
                        columns={'dummy': f'{c}__bin__{i}'})

                    columns_.append(f'{c}__bin__{i}')
                X = X.assign(
                    dummy=lambda x: f(
                        x, columns_, self.bins-1) + self.n_bins - 1
                ).rename(columns={'dummy': f'{c}__bin'})
                X = X.drop(columns_, axis=1)
            return X

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the input numpy array.

        Parameters
        ----------
        X : np.ndarray
            Input numpy array.

        Returns
        -------
        np.ndarray
            Transformed numpy array.
        """
        self.check_array(X)
        if self.idx_columns.size == 0:
            return X
        if X.dtype == object:
            return bin_numerics_object(
                X,
                self.bin_limits_np,
                self.bins_np,
                self.idx_columns
            )
        return bin_numerics(
            X.astype(np.float64),
            self.bin_limits_np,
            self.bins_np,
            self.idx_columns
        )

    @ staticmethod
    def compute_bins_pd(x, q):
        if x.std() == 0:
            return [np.array([- np.inf, np.inf])]
        _, bins = pd.qcut(x, q=q, duplicates='drop', retbins=True)
        bins = bins.astype(np.float64).round(3)
        bins[0] = -np.inf
        bins[-1] = np.inf
        return [bins]

    @ staticmethod
    def get_intervals_pd(bins):
        return pd.IntervalIndex.from_arrays(
            bins[0][:-1], bins[0][1:], closed='right')

    @ staticmethod
    def replace_bins_pd(x, bins):
        return x.cat.codes

    @ staticmethod
    def bin_numerics_pd(x, bins):
        bins = pd.IntervalIndex(bins[x.name])
        return pd.cut(x, bins=bins)

    @ staticmethod
    def get_bin_limits_ks(bins: List[List[float]]):
        n_rows = max([len(x) for x in bins])
        n_cols = len(bins)
        bin_limits_np = np.zeros((n_rows, n_cols))
        for i, bin_limit in enumerate(bins):
            n = len(bin_limit)
            bin_limits_np[:n, i] = bin_limit
        return bin_limits_np
