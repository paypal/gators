# License: Apache-2.0
from gators.scalers.standard_scaler import StandardScaler
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    X = pd.DataFrame(
        np.random.randn(5, 5),
        columns=list('ABCDF')
    )
    X_ks = ks.from_pandas(X)
    obj_pd = StandardScaler().fit(X)
    obj_ks = StandardScaler().fit(X_ks)
    return obj_pd, obj_ks, X, X_ks


@pytest.fixture
def data_float32():
    X = pd.DataFrame(
        np.random.randn(5, 5),
        columns=list('ABCDF'),
        dtype=np.float32
    )
    X_ks = ks.from_pandas(X)
    obj_pd = StandardScaler().fit(X)
    obj_ks = StandardScaler().fit(X_ks)
    return obj_pd, obj_ks, X, X_ks


def test_pd(data):
    obj_pd, obj_ks, X, X_ks = data
    X_new = obj_pd.transform(X)
    assert np.allclose(X_new.mean().mean(), 0)
    assert np.allclose(X_new.std().mean(), 1)


@pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks = data
    X_new = obj_ks.transform(X_ks)
    assert np.allclose(X_new.mean().mean(), 0)
    assert np.allclose(X_new.std().mean(), 1)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks = data
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    assert np.allclose(X_new.mean().mean(), 0)
    assert np.allclose(X_new.std().mean(), 1)


@pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks = data
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    assert np.allclose(X_new.mean().mean(), 0)
    assert np.allclose(X_new.std().mean(), 1)


def test_float32_pd(data_float32):
    obj_pd, obj_ks, X, X_ks = data_float32
    X_new = obj_pd.transform(X)
    assert np.allclose(X_new.mean().mean(), 0, atol=1e-7)
    assert np.allclose(X_new.std().mean(), 1, atol=1e-7)


@pytest.mark.koalas
def test_float32_ks(data_float32):
    obj_pd, obj_ks, X, X_ks = data_float32
    X_new = obj_ks.transform(X_ks)
    assert np.allclose(X_new.mean().mean(), 0, atol=1e-7)
    assert np.allclose(X_new.std().mean(), 1, atol=1e-7)


def test_float32_pd_np(data_float32):
    obj_pd, obj_ks, X, X_ks = data_float32
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    assert np.allclose(X_new.mean().mean(), 0, atol=1e-7)
    assert np.allclose(X_new.std().mean(), 1, atol=1e-7)


@pytest.mark.koalas
def test_float32_ks_np(data_float32):
    obj_pd, obj_ks, X, X_ks = data_float32
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    assert np.allclose(X_new.mean().mean(), 0, atol=1e-7)
    assert np.allclose(X_new.std().mean(), 1, atol=1e-7)
