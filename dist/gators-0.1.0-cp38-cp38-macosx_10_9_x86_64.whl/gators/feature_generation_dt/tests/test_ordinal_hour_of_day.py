# License: Apache-2.0
from gators.feature_generation_dt import OrdinalHourOfDay
from pandas.testing import assert_frame_equal
import pytest
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    X = pd.DataFrame(
        {
            'A': {0: '2020-05-04-T00'},
            'B': {0: '2020-05-06-T06'},
            'C': {0: '2020-05-08-T12'},
            'D': {0: '2020-05-09-T18'},
            'E': {0: '2020-05-10-T23'},
            'X': {0: 'x'}
        }
    )
    columns = ['A', 'B', 'C', 'D', 'E']
    X['A'] = X['A'].astype('datetime64[ns]')
    X['B'] = X['B'].astype('datetime64[ms]')
    X['C'] = X['C'].astype('datetime64[s]')
    X['D'] = X['D'].astype('datetime64[m]')
    X['E'] = X['E'].astype('datetime64[h]')
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(
        {
            'A__hour_of_day': {0: '0.0'},
            'B__hour_of_day': {0: '6.0'},
            'C__hour_of_day': {0: '12.0'},
            'D__hour_of_day': {0: '18.0'},
            'E__hour_of_day': {0: '23.0'}
        }
    )
    X_expected = pd.concat([X.copy(), X_expected], axis=1)
    obj_pd = OrdinalHourOfDay(columns=columns).fit(X)
    obj_ks = OrdinalHourOfDay(columns=columns).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_with_nan():
    X = pd.DataFrame(
        {
            'A': {0: '2020-05-04-T00', 1: pd.NaT},
            'B': {0: '2020-05-06-T06', 1: pd.NaT},
            'C': {0: '2020-05-08-T12', 1: pd.NaT},
            'D': {0: '2020-05-09-T18', 1: pd.NaT},
            'E': {0: '2020-05-10-T23', 1: pd.NaT},
            'X': {0: 'x', 1: 'x'}
        }
    )
    columns = ['A', 'B', 'C', 'D', 'E']
    X['A'] = X['A'].astype('datetime64[ns]')
    X['B'] = X['B'].astype('datetime64[ms]')
    X['C'] = X['C'].astype('datetime64[s]')
    X['D'] = X['D'].astype('datetime64[m]')
    X['E'] = X['E'].astype('datetime64[h]')
    X_ks = ks.from_pandas(X)
    X_expected = pd.DataFrame(
        {
            'A__hour_of_day': {0: '0.0', 1: 'nan'},
            'B__hour_of_day': {0: '6.0', 1: 'nan'},
            'C__hour_of_day': {0: '12.0', 1: 'nan'},
            'D__hour_of_day': {0: '18.0', 1: 'nan'},
            'E__hour_of_day': {0: '23.0', 1: 'nan'}
        }
    )
    X_expected = pd.concat([X.copy(), X_expected], axis=1)
    obj_pd = OrdinalHourOfDay(columns=columns).fit(X)
    obj_ks = OrdinalHourOfDay(columns=columns).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


def test_pd(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


def test_with_nan_pd(data_with_nan):
    obj_pd, obj_ks, X, X_ks, X_expected = data_with_nan
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_with_nan_ks(data_with_nan):
    obj_pd, obj_ks, X, X_ks, X_expected = data_with_nan
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_with_nan_pd_np(data_with_nan):
    obj_pd, obj_ks, X, X_ks, X_expected = data_with_nan
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_with_nan_ks_np(data_with_nan):
    obj_pd, obj_ks, X, X_ks, X_expected = data_with_nan
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new)
    X_expected = pd.DataFrame(X_expected.values)
    assert_frame_equal(X_new, X_expected)


def test_init():
    with pytest.raises(TypeError):
        _ = OrdinalHourOfDay(columns=0)
    with pytest.raises(ValueError):
        _ = OrdinalHourOfDay(columns=[])
