from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..transformer.transformer import Transformer


class FrameToNumpy(Transformer):
    """Convert the Pandas or Koalas dataframe to a Numpy array.

    Examples
    ---------
    >>> import pandas as pd
    >>> from gators.frame_converter import FrameToNumpy
    >>> X = pd.DataFrame({'A': ['a', 'b'], 'B': [0, 1]})
    >>> obj = FrameToNumpy()
    >>> obj.fit_transform(X)
    array([['a', 0],
           ['b', 1]], dtype=object)

    >>> import databricks.koalas as ks
    >>> from gators.frame_converter import FrameToNumpy
    >>> X = ks.DataFrame({'A': ['a', 'b'], 'B': [0, 1]})
    obj = FrameToNumpy()
    obj.fit_transform(X)
    >>> obj = FrameToNumpy()
    >>> obj.fit_transform(X)
    array([['a', 0],
           ['b', 1]], dtype=object) 

    >>> import pandas as pd
    >>> from gators.frame_converter import FrameToNumpy
    >>> X = pd.DataFrame({'A': ['a', 'b'], 'B': [0, 1]})
    >>> obj = FrameToNumpy()
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([['a', 0],
           ['b', 1]], dtype=object)

    >>> import databricks.koalas as ks
    >>> from gators.frame_converter import FrameToNumpy
    >>> X = ks.DataFrame({'A': ['a', 'b'], 'B': [0, 1]})
    obj = FrameToNumpy()
    _ = obj.fit(X)
    obj.transform_numpy(X.to_numpy())>>> obj = FrameToNumpy()
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([['a', 0],
           ['b', 1]], dtype=object)
    """

    def __init__(self):
        Transformer.__init__(self)

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'FrameToNumpy':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.
            y (np.array, optional): Target values. Defaults to None.

        Returns
        -------
        FrameToNumpy
            Instance of itself.
        """
        self.check_dataframe(X)
        return self

    def transform(self, X: Union[pd.DataFrame, ks.DataFrame]
                  ) -> np.ndarray:
        """Drop the columns of the input Pandas dataframe.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataset.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Dataset without datetime columns.
        """
        self.check_dataframe(X)
        return X.to_numpy()

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        return X
