from typing import List, Union
from abc import ABC
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..transformer.transformer import Transformer


class KoalasToPandas(Transformer):
    """Convert the Koalas dataframe to a Pandas dataframe.

    Examples
    ---------

    >>> import databricks.koalas as ks
    >>> from gators.frame_converter import KoalasToPandas
    >>> X = ks.DataFrame({'A': [0., 0., 0.1], 'B': [1., 2., 3.]})
    >>> obj = KoalasToPandas()
    >>> obj.fit_transform(X)
        A    B
    0  0.0  1.0
    1  0.0  2.0
    2  0.1  3.0
    >>> 
    >>> 
    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.frame_converter import KoalasToPandas
    >>> X = pd.DataFrame({'A': [0., 0., 0.1], 'B': [1., 2., 3.]})
    >>> obj = KoalasToPandas()
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[0. , 1. ],
           [0. , 2. ],
           [0.1, 3. ]])
    >>> 
    >>>         
    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.frame_converter import KoalasToPandas
    >>> X = ks.DataFrame({'A': [0., 0., 0.1], 'B': [1., 2., 3.]})
    >>> obj = KoalasToPandas()
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[0. , 1. ],
           [0. , 2. ],
           [0.1, 3. ]])    
        """

    def __init__(self):
        Transformer.__init__(self)

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'KoalasToPandas':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.
            y (np.array, optional): Target values. Defaults to None.

        Returns
        -------
        KoalasToPandas
            Instance of itself.
        """
        self.check_dataframe(X)
        return self

    def transform(self, X: Union[pd.DataFrame, ks.DataFrame]
                  ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Drop the columns of the input Pandas dataframe.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame])
            Input dataset.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Dataset without datetime columns.
        """
        self.check_dataframe(X)
        if isinstance(X, ks.DataFrame):
            X = X.to_pandas()
        return X

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        return X
