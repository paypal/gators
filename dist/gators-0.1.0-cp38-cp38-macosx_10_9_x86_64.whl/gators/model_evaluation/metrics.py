# License: Apache-2.0
from typing import Union
from typing import Tuple
import numpy as np
import pandas as pd
import databricks.koalas as ks


def precision(y_true: Union[pd.Series, ks.Series], y_pred: np.ndarray) -> float:
    """Return the precision score.

    Parameters
    ----------
    y_true (np.ndarray): True target values.
        y_pred (np.ndarray): Predicted target values.

    Returns
    -------
        float: Precision score.
    """
    return y_true[y_pred == 1].mean()


def recall(y_true: Union[pd.Series, ks.Series], y_pred: np.ndarray) -> float:
    """Return the recall score.

    Parameters
    ----------
    y_true (np.ndarray): True target values.
        y_pred (np.ndarray): Predicted target values.

    Returns
    -------
        float: Recall score.
    """
    return y_pred[y_true == 1].mean()


def fbeta(beta: float,
          y_true: Union[pd.Series, ks.Series], y_pred: np.ndarray,
          ) -> float:
    """Return the f-beta score.

    Parameters
    ----------
    beta : float
            [description]
        y_true (np.ndarray): True target values.
        y_pred (np.ndarray): Predicted target values.

    Returns
    -------
        float: F-beta score.
    """
    p = precision(y_true, y_pred)
    r = recall(y_true, y_pred)
    return (1 + beta ** 2) * p * r / (beta ** 2 * p + r)


def fbeta_formula(beta: float, p: float, r: float) -> float:
    """Return the f-beta score from precision and recall.

    Parameters
    ----------
    beta : float
            Beta value.
        p : float
            Precision score.
        r : float
            Recall score.

    Returns
    -------
        float: F-beta score.
    """
    return (1 + beta ** 2) * p * r / (beta ** 2 * p + r)


def mask_true_positive(
        y_true: Union[pd.Series, ks.Series], y_pred: np.ndarray,) -> np.ndarray:
    """Return the True Positive mask.

    Parameters
    ----------
    y_true (np.ndarray): True target values.
        y_pred (np.ndarray): Predicted target values.

    Returns
    -------
        np.ndarray: True Positive mask.
    """
    return (y_pred == 1) & (y_true == 1)


def mask_false_positive(
        y_true: Union[pd.Series, ks.Series], y_pred: np.ndarray) -> np.ndarray:
    """Return the False Positive mask.

    Parameters
    ----------
    y_true (np.ndarray): True target values.
        y_pred (np.ndarray): Predicted target values.

    Returns
    -------
        np.ndarray: False Positive mask.
    """
    return (y_pred == 1) & (y_true == 0)


def mask_true_negative(
        y_true: Union[pd.Series, ks.Series], y_pred: np.ndarray) -> np.ndarray:
    """Return the True Negative mask.

    Parameters
    ----------
    y_true (np.ndarray): True target values.
        y_pred (np.ndarray): Predicted target values.

    Returns
    -------
        np.ndarray: True Negative mask.
    """
    return (y_pred == 0) & (y_true == 0)


def mask_false_negative(
        y_true: Union[pd.Series, ks.Series], y_pred: np.ndarray) -> np.ndarray:
    """Return the False Negative mask.

    Parameters
    ----------
    y_true (np.ndarray): True target values.
        y_pred (np.ndarray): Predicted target values.

    Returns
    -------
        np.ndarray: False Negative mask.
    """
    return (y_pred == 0) & (y_true == 1)


def confusion_matrix(
        y_true: Union[pd.Series, ks.Series], y_pred: np.ndarray,
        sample_weight: np.ndarray = None) -> np.ndarray:
    """Return the confusion matrix.

    Parameters
    ----------
    y_true (np.ndarray): True target values.
        y_pred (np.ndarray): Predicted target values.
        sample_weight: (np.ndarray): Weight values.
    Returns
    -------
        np.ndarray: Confusion matrix.
    """
    cm = np.zeros((2, 2))
    mask_tp = mask_true_positive(y_true, y_pred)
    mask_fp = mask_false_positive(y_true, y_pred)
    mask_tn = mask_true_negative(y_true, y_pred)
    mask_fn = mask_false_negative(y_true, y_pred)
    if sample_weight is None:
        cm[0, 0] = (mask_tp).sum()
        cm[0, 1] = (mask_fp).sum()
        cm[1, 0] = (mask_fn).sum()
        cm[1, 1] = (mask_tn).sum()
    else:
        cm[0, 0] = (mask_tp * sample_weight).sum()
        cm[0, 1] = (mask_fp * sample_weight).sum()
        cm[1, 0] = (mask_fn * sample_weight).sum()
        cm[1, 1] = (mask_tn * sample_weight).sum()
    return cm


def precision_recall_with_cm(cm: np.ndarray) -> Tuple[float, float]:
    """Return the precision and recall computed using the confusion matrix.

    Parameters
    ----------
    cm (np.ndarray): Confusion matrix.

    Returns
    -------
        Tuple[float, float]: Precision and recall values.
    """
    precision_value = cm[0, 0] / (cm[0, 0] + cm[0, 1])
    recall_value = cm[0, 0] / (cm[0, 0] + cm[1, 0])
    return precision_value, recall_value
