# License: Apache-2.0
# from ..model_evaluation.model_evaluation import ModelEvaluation
from typing import List
import numpy as np
import pandas as pd
from ..model_evaluation import model_evaluation_util
from ..model_evaluation import metrics
from scipy.optimize import bisect


class BinaryClassifEvaluation():
    """Binary Classification Evaluation class.

    Parameters
    ----------
    y_true : np.ndarray
        True target values.
    y_pred_proba : np.ndarray
        Model score values.
    values : np.ndarray,default to None
        mount values.
    """

    def __init__(self, y_true: np.array, y_pred_proba: np.ndarray,
                 sample_weights: np.ndarray = None):
        self.y_true = y_true
        self.y_pred_proba = y_pred_proba
        self.sample_weights = self.get_sample_weights(sample_weights)

    def fscores(self,
                thresholds: List[float] = np.linspace(0, 1, 11)[1: -1],
                betas: List[float] = [1.]) -> pd.DataFrame:
        """Return the f-scores for each beta value and threshold.

        Parameters
        ----------
        thresholds : List[float], defaults to np.linspace(0, 1, 11)[1: -1].
            List of threshold values.
        betas : List[float], defaults to [1.].
            List of beta values.

        Returns
        -------
        pd.DataFrame
            F-scores for each beta value and threshold.
        """
        fscores = pd.Series(thresholds, index=thresholds, dtype='float')
        fscores.index.name = 'threshold'
        kwds = {
            'y_true': self.y_true,
            'y_pred_proba': self.y_pred_proba,
            'betas': betas,
        }
        return fscores.apply(self.fscore, **kwds)

    def evaluations(
            self, thresholds: List[float], betas: List[float]) -> pd.DataFrame:
        """Return the model evaluation for the given thresholds and betas.

        Parameters
        ----------
        thresholds : List[float]
            List of threshold values to consider.
        betas : List[float]
            List of beta values to consider.

        Returns
        -------
        pd.DataFrame
            Model Evaluation dataframe.
        """
        perfs = pd.Series(thresholds, index=thresholds, dtype='float')
        perfs.index.name = 'threshold'
        kwds = {
            'y_true': self.y_true,
            'y_pred_proba': self.y_pred_proba,
            'sample_weights': self.sample_weights,
        }
        perfs = perfs.apply(self.Evaluation, **kwds)
        dump = pd.Series(betas, index=betas, dtype='float')
        kwds = {
            'p': perfs['precision'],
            'r': perfs['recall'],
        }

        fscores = dump.apply(metrics.fbeta_formula, **kwds).T
        fscores.columns = [
            model_Evaluation_util.get_fbeta_column_name(beta)
            for beta in betas
        ]
        return pd.concat([perfs, fscores], axis=1).round(5)

    def fptp_thresholds(
            self, fptps: List[float], min_val: float = 0.001,
            max_val: float = 0.999, ) -> pd.Series:
        """Return the thresholds for the given FP to TP rates.

        Parameters
        ----------
        fptps : List[float]
            FP to TP rates.
        min_val : float. default to 0.001
            Minimal threshold value to consider.
        max_val : float. default to 0.999
            Maximal threshold value to consider.

        Returns
        -------
        pd.Series
            Threshold values
        """
        fptps = pd.Series(fptps, index=fptps, dtype='float')
        fptps.index.name = 'fptp'
        kwds = {
            'y_true': self.y_true,
            'y_pred_proba': self.y_pred_proba,
            'sample_weights': self.sample_weights,
            'min_val': min_val,
            'max_val': max_val,
        }
        return fptps.apply(self.threshold_tpfp_values, **kwds).dropna()

    def positive_ratio_thesholds(
            self, positive_ratios: List[float], min_val: float = 0.001,
            max_val: float = 0.999, ) -> pd.Series:
        """Return the thresholds for the given reject ratios.

        Parameters
        ----------
        positive_ratios : List[float]
            Reject ratio values.
        min_val : float, defaults to 0.001
            Minimal threshold value to consider.
        max_val : float, defaults to 0.999
            Maximal threshold value to consider.

        Returns
        -------
        pd.Series:
            Threshold values.
        """
        positive_ratio = pd.Series(
            positive_ratios, index=positive_ratios, dtype='float')
        positive_ratio.index.name = 'positive_ratio'
        kwds = {
            'y_true': self.y_true,
            'y_pred_proba': self.y_pred_proba,
            'min_val': min_val,
            'max_val': max_val,
        }
        return positive_ratio.apply(
            self.positive_ratio_theshold, **kwds).dropna()

    @ staticmethod
    def fscore(
            threshold: float, y_true: np.array, y_pred_proba: np.ndarray,
            betas: List[float]) -> pd.DataFrame:
        """Return the fscores for each beta value and a given threshold.

        Parameters
        ----------
        threshold : float
            Score threshold.
        y_true : np.ndarray
            True target values.
        y_pred_proba : np.ndarray
            Model score values.
        betas : List[float]
            List of beta values.

        Returns
        -------
        pd.DataFrame:
        F-scores for each beta value and a given threshold.
        """
        y_pred = (y_pred_proba > threshold).astype(int)
        fscores = pd.Series(betas, index=betas)
        kwds = {'y_true': y_true, 'y_pred': y_pred}
        return fscores.apply(metrics.fbeta, **kwds)

    @staticmethod
    def evaluation(threshold: float, y_true: np.ndarray,
                   y_pred_proba: np.ndarray,
                   sample_weights: np.ndarray) -> pd.Series:
        """Return the model Evaluation for a given threshold.

        Parameters
        ----------
        threshold : float
            Score threshold value.
        y_true : np.ndarray
            True target values.
        y_pred_proba : np.ndarray
            odel score values.
        sample_weights : np.ndarray
            Sample weights.

        Returns
        -------
            pd.Series: Model Evaluation for a given threshold.
        """
        index = [
            'ratio_rejected(%)',
            'precision',
            'recall',
            'tp(count)',
            'tn(count)',
            'fp(count)',
            'fn(count)',
            'fp/tp(count)',
            'tp($)',
            'tn($)',
            'fp($)',
            'fn($)',
            'fp/tp($)',
        ]
        y_pred = (y_pred_proba > threshold).astype(int)
        cm = metrics.confusion_matrix(y_true, y_pred)
        precision, recall = metrics.precision_recall_with_cm(cm)
        perf = pd.Series(0., index=index, dtype='float')
        perf['ratio_rejected(%)'] = 100 * y_pred.mean()
        perf['precision'] = precision
        perf['recall'] = recall
        perf['tp(count)'] = cm[0, 0]
        perf['fp(count)'] = cm[0, 1]
        perf['fn(count)'] = cm[1, 0]
        perf['tn(count)'] = cm[1, 1]
        perf['fp/tp(count)'] = cm[0, 1] / cm[0, 0]
        cm = metrics.confusion_matrix(y_true, y_pred, sample_weights)
        perf['tp(weight)'] = cm[0, 0]
        perf['fp(weight)'] = cm[0, 1]
        perf['fn(weight)'] = cm[1, 0]
        perf['tn(weight)'] = cm[1, 1]
        perf['fp/tp(weight)'] = cm[0, 1] / cm[0, 0]
        return perf

    @staticmethod
    def threshold_tpfp_values(
            fptp: float, y_true: np.array, y_pred_proba: np.ndarray,
            sample_weights: np.array, min_val: float = 0.001,
            max_val: float = 0.999) -> float:
        """Return the threshold for a given FP to TP rate.

        Parameters
        ----------
        fptp : float
            FP to TP rate.
        y_true : np.ndarray
            True target values.
        y_pred_proba : np.ndarray
            Model score values.
        sample_weights : np.ndarray
            Sample weights.
        min_val : float. default to 0.001
            Minimal threshold value to consider.
        max_val : float. default to 0.999
            Maximal threshold value to consider.

        Returns
        -------
        float
            Threshold value.
        """

        def func_to_minimize(threshold: float) -> float:
            """            Return value to minimize.

            Parameters
            ----------
            threshold : float
                Threshold value.

            Returns
            -------
            float
                Value to minimize.
          """
            y_pred = (y_pred_proba > threshold).astype(int)
            mask_tp = metrics.mask_true_positive(y_true, y_pred)
            mask_fp = metrics.mask_false_positive(y_true, y_pred)
            x = sample_weights[mask_fp].sum() / \
                sample_weights[mask_tp].sum() - fptp
            return x

        if func_to_minimize(min_val) * func_to_minimize(max_val) > 0:
            return np.nan
        res = bisect(func_to_minimize, min_val, max_val, xtol=1e-15)
        return res

    @staticmethod
    def get_values(sample_weights: np.ndarray, n_samples):
        if sample_weights is None:
            return np.ones(n_samples)
        return sample_weights
