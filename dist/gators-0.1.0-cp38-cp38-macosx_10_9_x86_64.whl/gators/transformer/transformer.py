# License: Apache-2.0
from typing import List, Union
from abc import ABC
from abc import abstractmethod
import numpy as np
import pandas as pd
import databricks.koalas as ks

NUMERICS_DTYPE = [
    np.int8, np.int16, np.int32, np.int64,
    np.float16, np.float32, np.float64]


class Transformer(ABC):
    """Base class for all transformer in gators.

    Examples
    ---------
    * fit & transform with pandas
    >>> import pandas as pd
    * fit & transform with koalas
    >>> import databricks.koalas as ks
    >>> from gators.transformer import Transformer
    >>> class AddFirstColumn(Transformer):
    ...     def fit(self, X, y=None):
    ...         return self
    ...
    ...     def transform(self, X: pd.DataFrame):
    ...         return X[[X.columns[0]]]
    ...
    ...     def transform_numpy(self, X: np.ndarray):
    ...         return X[:, 0].reshape(-1, 1)
    ...
    ...

    >>> AddFirstColumn().fit_transform(pd.DataFrame({'A':[1, 2], 'B':[3, 4]}))
    A
    0  1
    1  2

    >>> obj = AddFirstColumn().fit(pd.DataFrame({'A':[1, 2], 'B':[3, 4]}))
    A
    0  1
    1  2

    >>> obj.transform_numpy(np.array([[5, 6], [7, 8]]))
    array([[5],
          [7]])

    >>> obj = AddFirstColumn().fit(ks.DataFrame({'A':[1, 2], 'B':[3, 4]}))
    >>> obj.transform_numpy(np.array([[5, 6], [7, 8]]))
    array([[5],
          [7]])
    """

    @abstractmethod
    def fit(
            self, X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> object:
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
        y None
            None.

        Returns
    -------
            object: Instance of itself.
        """

    @abstractmethod
    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame],
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.

        Returns
    -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """

    @abstractmethod
    def transform_numpy(self, X: Union[pd.Series, ks.Series], y: Union[pd.Series, ks.Series] = None):
        """Transform the array X.

        Parameters
        ----------
        X : np.ndarray
            Array
        """

    def fit_transform(
            self, X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> Union[pd.DataFrame, ks.DataFrame]:
        """Fit and Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
        y Union[pd.Series, ks.Series], default to None.
            Input target.

        Returns
    -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """
        _ = self.fit(X, y)
        return self.transform(X)

    @staticmethod
    def check_dataframe(X: Union[pd.DataFrame, ks.DataFrame]):
        """Validate dataframe.

        Args:
            X : Union[pd.DataFrame, ks.DataFrame]
                Input dataframe.]
        """
        if not isinstance(X, (pd.DataFrame, ks.DataFrame)):
            raise TypeError(
                '''`X` should be a pandas dataframe or a koalas dataframe.''')
        for c in X.columns:
            if not isinstance(c, str):
                raise TypeError('Column names of `X` should be of type str.')

    @ staticmethod
    def check_y(X: Union[pd.DataFrame, ks.DataFrame],
                y: Union[pd.Series, ks.Series]):
        """Validate target.

        Args:
        X : Union[pd.DataFrame, ks.DataFrame]
            Dataframe
        y : Union[pd.Series, ks.Series]
            Labels
        """
        if isinstance(X, pd.DataFrame) and (not isinstance(y, pd.Series)):
            raise TypeError('`y` should be a pandas series.')
        if isinstance(X, ks.DataFrame) and (not isinstance(y, ks.Series)):
            raise TypeError('`y` should be a koalas series.')
        if not isinstance(y.name, str):
            raise TypeError('Name of `y` should be a str.')
        if X.shape[0] != y.shape[0]:
            raise ValueError('Length of `X` and `y` should match.')

    @ staticmethod
    def check_array(X: np.ndarray):
        """Validate array.

        Args:
            X (np.ndarray): Array.
        """
        if not isinstance(X, np.ndarray):
            raise TypeError('`X` should be a numpy array.')

    @ staticmethod
    def check_dataframe_is_numerics(X: Union[pd.DataFrame, ks.DataFrame]):
        """Check if dataframe is only numerics.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Dataframe
        """
        X_dtypes = X.dtypes.unique()
        for x_dtype in X_dtypes:
            if x_dtype not in NUMERICS_DTYPE:
                raise TypeError('`X` should be of type `float`.')

    @ staticmethod
    def check_array_is_numerics(X: np.ndarray):
        """Check if array is only numerics.

        Parameters
        ----------
        X : np.ndarray
            Array
        """
        if X.dtype not in [np.float16, np.float32, np.float64]:
            raise TypeError('`X` should be of type `float`.')
