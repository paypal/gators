# License: Apache-2.0
from typing import List, Union
from abc import ABC
from abc import abstractmethod
import numpy as np
import pandas as pd
import databricks.koalas as ks


class TransformerXY(ABC):
    """TransformerXY. TODO

    Examples
    ---------
    >>> import pandas as pd
    >>> from gators.transformer import TransformerXY
    >>> class FirstRow(Transformer):
    ...     def fit_transform(self, X, y):
    ...         return X.iloc[:10], y.iloc[:10]

    >>> AddFirstColumn().fit_transform(pd.DataFrame({'A':[1, 2], 'B':[3, 4]}))
       A   B
    0  1   3

    >>> obj = AddFirstColumn().fit(pd.DataFrame({'A':[1, 2], 'B':[3, 4]}))
       A   B
    0  1   3
    """

    @abstractmethod
    def transform(
            self, X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series]):
        """Fit and Transform the dataframes `X`ad `y`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
        y Union[pd.Series, ks.Series]
            None.

        Returns
        -------
        Tuple[Union[pd.DataFrame, ks.DataFrame], Union[pd.Series, ks.Series]]
            Transformed dataframes.
        """

    @staticmethod
    def check_dataframe(X: Union[pd.DataFrame, ks.DataFrame]):
        """Validate dataframe.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.
        """
        if not isinstance(X, (pd.DataFrame, ks.DataFrame)):
            raise TypeError(
                '''`X` should be a pandas dataframe or a koalas dataframe.''')
        for c in X.columns:
            if not isinstance(c, str):
                raise TypeError('Column names of `X` should be of type str.')

    @ staticmethod
    def check_y(X: Union[pd.DataFrame, ks.DataFrame],
                y: Union[pd.Series, ks.Series]):
        """Validate target.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Dataframe
        y : Union[pd.Series, ks.Series]
            Labels
        """
        if isinstance(X, pd.DataFrame) and (not isinstance(y, pd.Series)):
            raise TypeError('`y` should be a pandas series.')
        if isinstance(X, ks.DataFrame) and (not isinstance(y, ks.Series)):
            raise TypeError('`y` should be a koalas series.')
        if not isinstance(y.name, str):
            raise TypeError('Name of `y` should be a str.')
        if X.shape[0] != y.shape[0]:
            raise ValueError('Length of `X` and `y` should match.')
