# License: Apache-2.0
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ._base_drop_columns import _BaseDropColumns
from ..util import util


LIST_NUMPY_NUM_DTYPES = [
    'np.int8',
    'np.int16',
    'np.int32',
    'np.int64',
    'np.uint8',
    'np.uint16',
    'np.uint32',
    'np.uint64',
    'np.float16',
    'np.float32',
    'np.float64',
]


class SetDatatype(_BaseDropColumns):
    """Drop Datetime Column Transformer.

    Parameters
    ----------
    columns_to_keep : List[str]
        List of columns.

    Examples
    ---------

    * fit & transform with pandas 
    >>> import pandas as pd
    >>> from gators.data_cleaning import KeepColumns
    >>> X = pd.DataFrame({'A': [1, 2, 3], 'B': [1, 1, 1]})
    >>> obj = KeepColumns(['A'])
    >>> obj.fit_transform(X) 
        A
    0	1
    1	2
    2	3

    * fit & transform with koalas 
    >>> import databricks.koalas as ks
    >>> from gators.data_cleaning import KeepColumns
    >>> X = ks.DataFrame({'A': [1, 2, 3], 'B': [1, 1, 1]})
    >>> obj = KeepColumns(['A'])
    >>> obj.fit_transform(X)
        A
    0	1
    1	2
    2	3

    * fit with pandas & transform with numpy 
    >>> import pandas as pd
    >>> from gators.data_cleaning import KeepColumns
    >>> X = pd.DataFrame({'A': [1, 2, 3], 'B': [1, 1, 1]})
    >>> obj = KeepColumns(['A'])
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1],
           [2],
           [3]])

    * fit with koalas & transform with numpy 
    >>> import databricks.koalas as ks
    >>> from gators.data_cleaning import KeepColumns
    >>> X = ks.DataFrame({'A': [1, 2, 3], 'B': [1, 1, 1]})
    >>> obj = KeepColumns(['A'])
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1],
           [2],
           [3]])
    """

    def __init__(self, columns, datatype):
        if not isinstance(columns, list):
            raise TypeError('`columns` should be a list.')
        _BaseDropColumns.__init__(self)
        self.columns = columns
        self.datatype = datatype

    def fit(self, X: Union[pd.DataFrame, ks.DataFrame],
            y=None) -> 'SetDatatype':
        """Fit the transformer on the dataframe X.

        Get the list of column names to be removed and the array of
          indices to be kept.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None. 
            Labels.

        Returns
        -------
        SetDatatype: Instance of itself.
        """
        self.check_dataframe(X)
        return self

    def transform(self, X: Union[pd.DataFrame, ks.DataFrame],
                  y=None) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame])
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """
        X[self.columns] = X[self.columns].astype(self.datatype)
        return X

    def transform_numpy(self, X: np.ndarray,
                        y=None) -> np.ndarray:
        """Transform the array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        if self.datatype in LIST_NUMPY_NUM_DTYPES:
            return X.astype(self.datatype)
        return X.astype(object)
