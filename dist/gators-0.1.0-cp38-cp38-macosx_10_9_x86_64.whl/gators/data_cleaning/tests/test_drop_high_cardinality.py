from gators.data_cleaning.drop_high_cardinality import DropHighCardinality
import pytest
import pandas as pd
from pandas.testing import assert_frame_equal
import databricks.koalas as ks


@pytest.fixture
def data():
    X = pd.DataFrame(
        {'A': list('qwe'), 'B': list('ass'), 'C': list('zxx'), 'D': [0, 1, 2]}
    )
    X_expected = pd.DataFrame({'B': list('ass'), 'C': list('zxx'), 'D': [0, 1, 2]}
                              )
    X_ks = ks.from_pandas(X)
    obj_pd = DropHighCardinality(max_categories=2).fit(X)
    obj_ks = DropHighCardinality(max_categories=2).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_no_drop():
    X = pd.DataFrame(
        {'A': list('qww'), 'B': list('ass'), 'C': list('zxx'), 'D': [0, 1, 2]}
    )
    X_expected = X.copy()
    X_ks = ks.from_pandas(X)
    obj_pd = DropHighCardinality(max_categories=2).fit(X)
    obj_ks = DropHighCardinality(max_categories=2).fit(X_ks)
    return obj_pd, obj_ks, X, X_ks, X_expected


def test_pd(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected.astype(object))


@pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected.astype(object))


def test_no_drop_pd(data_no_drop):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_drop
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_no_drop_ks(data_no_drop):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_drop
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_no_drop_pd_np(data_no_drop):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_drop
    X_numpy_new = obj_pd.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected.astype(object))


@pytest.mark.koalas
def test_no_drop_ks_np(data_no_drop):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_drop
    X_numpy_new = obj_ks.transform_numpy(X.to_numpy())
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected.astype(object))


def test_object_columns_empty(data_no_drop):
    X = pd.DataFrame({'A': [1, 2, 3]})
    X_new = DropHighCardinality(max_categories=2).fit_transform(X.copy())
    assert_frame_equal(X_new, X)


def test_init():
    with pytest.raises(TypeError):
        _ = DropHighCardinality(max_categories='q')
