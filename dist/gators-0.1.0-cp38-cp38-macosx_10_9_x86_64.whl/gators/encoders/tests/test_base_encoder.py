# License: Apache-2.0
from gators.encoders import WOEEncoder
from pandas.testing import assert_frame_equal
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


def test_check_y_dtype():
    y = pd.Series([1, 1, 0], name='TARGET')
    with pytest.raises(TypeError):
        WOEEncoder.check_y_dtype(y, float)


def test_init():
    with pytest.raises(TypeError):
        WOEEncoder(dtype=str)
