# License: Apache-2.0
from gators.encoders import WOEEncoder
from gators.encoders import MultiClassEncoder
from pandas.testing import assert_frame_equal
import pytest
import numpy as np
import pandas as pd
import databricks.koalas as ks
ks.set_option('compute.default_index_type', 'distributed-sequence')


@pytest.fixture
def data():
    X = pd.DataFrame({
        'A': ['Q', 'Q', 'Q', 'W', 'W', 'W'],
        'B': ['Q', 'Q', 'W', 'W', 'W', 'W'],
        'C': ['Q', 'Q', 'Q', 'Q', 'W', 'W'],
        'D': [1, 2, 3, 4, 5, 6]
    })
    X_ks = ks.from_pandas(X)
    y = pd.Series([0, 0, 1, 2, 1, 2], name='TARGET')
    y_ks = ks.from_pandas(y)
    obj_pd = MultiClassEncoder(
        WOEEncoder()).fit(X, y)
    obj_ks = MultiClassEncoder(
        WOEEncoder()).fit(X_ks, y_ks)

    X_expected = pd.DataFrame(
        {'D': {0: 1.0, 1: 2.0, 2: 3.0, 3: 4.0, 4: 5.0, 5: 6.0},
         'A__TARGET_1_WOEEncoder':
             {0: 0.0, 1: 0.0, 2: 0.0, 3: 0.0, 4: 0.0, 5: 0.0},
         'B__TARGET_1_WOEEncoder':
             {0: 0.0,
              1: 0.0,
              2: 0.6931471805599453,
              3: 0.6931471805599453,
              4: 0.6931471805599453,
              5: 0.6931471805599453},
         'C__TARGET_1_WOEEncoder':
             {0: -0.40546510810816444,
              1: -0.40546510810816444,
              2: -0.40546510810816444,
              3: -0.40546510810816444,
              4: 0.6931471805599453,
              5: 0.6931471805599453},
         'A__TARGET_2_WOEEncoder':
             {0: 0.0,
              1: 0.0,
              2: 0.0,
              3: 1.3862943611198906,
              4: 1.3862943611198906,
              5: 1.3862943611198906},
         'B__TARGET_2_WOEEncoder':
             {0: 0.0,
              1: 0.0,
              2: 0.6931471805599453,
              3: 0.6931471805599453,
              4: 0.6931471805599453,
              5: 0.6931471805599453},
         'C__TARGET_2_WOEEncoder':
             {0: -0.40546510810816444,
              1: -0.40546510810816444,
              2: -0.40546510810816444,
              3: -0.40546510810816444,
              4: 0.6931471805599453,
              5: 0.6931471805599453}}
    )
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_float32():
    X = pd.DataFrame({
        'A': ['Q', 'Q', 'Q', 'W', 'W', 'W'],
        'B': ['Q', 'Q', 'W', 'W', 'W', 'W'],
        'C': ['Q', 'Q', 'Q', 'Q', 'W', 'W'],
        'D': [1, 2, 3, 4, 5, 6]
    })
    X_ks = ks.from_pandas(X)
    y = pd.Series([0, 0, 1, 2, 1, 2], name='TARGET')
    y_ks = ks.from_pandas(y)
    obj_pd = MultiClassEncoder(
        WOEEncoder(), dtype=np.float32).fit(X, y)
    obj_ks = MultiClassEncoder(
        WOEEncoder(), dtype=np.float32).fit(X_ks, y_ks)

    X_expected = pd.DataFrame(
        {'D': {0: 1.0, 1: 2.0, 2: 3.0, 3: 4.0, 4: 5.0, 5: 6.0},
         'A__TARGET_1_WOEEncoder':
             {0: 0.0, 1: 0.0, 2: 0.0, 3: 0.0, 4: 0.0, 5: 0.0},
         'B__TARGET_1_WOEEncoder':
             {0: 0.0,
              1: 0.0,
              2: 0.6931471805599453,
              3: 0.6931471805599453,
              4: 0.6931471805599453,
              5: 0.6931471805599453},
         'C__TARGET_1_WOEEncoder':
             {0: -0.40546510810816444,
              1: -0.40546510810816444,
              2: -0.40546510810816444,
              3: -0.40546510810816444,
              4: 0.6931471805599453,
              5: 0.6931471805599453},
         'A__TARGET_2_WOEEncoder':
             {0: 0.0,
              1: 0.0,
              2: 0.0,
              3: 1.3862943611198906,
              4: 1.3862943611198906,
              5: 1.3862943611198906},
         'B__TARGET_2_WOEEncoder':
             {0: 0.0,
              1: 0.0,
              2: 0.6931471805599453,
              3: 0.6931471805599453,
              4: 0.6931471805599453,
              5: 0.6931471805599453},
         'C__TARGET_2_WOEEncoder':
             {0: -0.40546510810816444,
              1: -0.40546510810816444,
              2: -0.40546510810816444,
              3: -0.40546510810816444,
              4: 0.6931471805599453,
              5: 0.6931471805599453}}
    ).astype(np.float32)
    return obj_pd, obj_ks, X, X_ks, X_expected


@pytest.fixture
def data_no_cat():
    X = pd.DataFrame(
        np.zeros((3, 6)),
        columns=list('qweasd'),
    )
    X_ks = ks.from_pandas(X)
    y = pd.Series([1, 2, 0], name='TARGET')
    y_ks = ks.from_pandas(y)
    obj_pd = MultiClassEncoder(
        WOEEncoder()).fit(X, y)
    obj_ks = MultiClassEncoder(
        WOEEncoder()).fit(X_ks, y_ks)
    return obj_pd, obj_ks, X, X_ks, X.copy()


def test_pd(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_pd_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy = X.to_numpy()
    X_numpy_new = obj_pd.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_ks_np(data):
    obj_pd, obj_ks, X, X_ks, X_expected = data
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


def test_float32_pd(data_float32):
    obj_pd, obj_ks, X, X_ks, X_expected = data_float32
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_float32_ks(data_float32):
    obj_pd, obj_ks, X, X_ks, X_expected = data_float32
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_float32_pd_np(data_float32):
    obj_pd, obj_ks, X, X_ks, X_expected = data_float32
    X_numpy = X.to_numpy()
    X_numpy_new = obj_pd.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_float32_ks_np(data_float32):
    obj_pd, obj_ks, X, X_ks, X_expected = data_float32
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


def test_without_cat_pd(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_new = obj_pd.transform(X)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_without_cat_ks(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_new = obj_ks.transform(X_ks)
    assert_frame_equal(X_new.to_pandas(), X_expected)


def test_without_cat_pd_np(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_numpy = X.to_numpy()
    X_numpy_new = obj_pd.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


@pytest.mark.koalas
def test_without_cat_ks_np(data_no_cat):
    obj_pd, obj_ks, X, X_ks, X_expected = data_no_cat
    X_numpy = X.to_numpy()
    X_numpy_new = obj_ks.transform_numpy(X_numpy)
    X_new = pd.DataFrame(X_numpy_new, columns=X_expected.columns)
    assert_frame_equal(X_new, X_expected)


def test_init():
    with pytest.raises(TypeError):
        _ = MultiClassEncoder(encoder='q')
    with pytest.raises(TypeError):
        _ = MultiClassEncoder(encoder='q')
