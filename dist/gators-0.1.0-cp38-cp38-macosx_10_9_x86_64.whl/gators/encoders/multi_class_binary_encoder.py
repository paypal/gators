# License: Apache-2.0
from typing import List, Union
import copy
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..transformer.transformer import Transformer
from ..data_cleaning.drop_columns import DropColumns
from ..util import util
from .onehot_encoder import OneHotEncoder
from ._base_encoder import _BaseEncoder


class MultiClassBinaryEncoder(_BaseEncoder):
    """Multi-Class Binary Encoder Transformer.
    Parameters
    ----------
    encoder : _BaseEncoder
        Binary Encoder.
    Examples
    --------
    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.encoders import MultiClassBinaryEncoder
    >>> from gators.encoders import WOEEncoder
    >>> X = pd.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> y = pd.Series([1, 1, 0], name='TARGET')
    >>> obj = MultiClassBinaryEncoder(WOEEncoder())
    >>> obj.fit_transform(X, y)
    >>>    A  B  A_0_WOEEncoder  B_0_WOEEncoder  A_1_WOEEncoder  B_1_WOEEncoder
    >>> 0  a  c       -1.098612       -0.693147        1.098612        0.693147
    >>> 1  a  d       -1.098612        0.405465        1.098612       -0.405465
    >>> 2  b  d        1.098612        0.405465       -1.098612       -0.405465
    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.encoders import MultiClassBinaryEncoder
    >>> from gators.encoders import WOEEncoder
    >>> X = ks.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> y = pd.Series([1, 1, 0], name='TARGET')
    >>> obj = MultiClassBinaryEncoder(WOEEncoder())
    >>> obj.fit_transform(X, y)
    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.encoders import MultiClassBinaryEncoder
    >>> from gators.encoders import WOEEncoder
    >>> X = pd.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> y = pd.Series([1, 1, 0], name='TARGET')
    >>> obj = MultiClassBinaryEncoder(WOEEncoder())
    >>> obj.fit(X, y)
    >>> obj.transform_numpy(X.to_numpy())
    array([['a', 'c', -1.0986122886681098, -0.6931471805599453,
            1.0986122886681098, 0.6931471805599453],
           ['a', 'd', -1.0986122886681098, 0.4054651081081644,
            1.0986122886681098, -0.40546510810816444],
           ['b', 'd', 1.0986122886681098, 0.4054651081081644,
            -1.0986122886681098, -0.40546510810816444]], dtype=object)
    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.encoders import MultiClassBinaryEncoder
    >>> from gators.encoders import WOEEncoder
    >>> X = ks.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> y = pd.Series([1, 1, 0], name='TARGET')
    >>> obj = MultiClassBinaryEncoder(WOEEncoder())
    >>> obj.fit(X, y)
    >>> obj.transform(X.to_numpy())
    array([['a', 'c', -1.0986122886681098, -0.6931471805599453,
            1.0986122886681098, 0.6931471805599453],
           ['a', 'd', -1.0986122886681098, 0.4054651081081644,
            1.0986122886681098, -0.40546510810816444],
           ['b', 'd', 1.0986122886681098, 0.4054651081081644,
            -1.0986122886681098, -0.40546510810816444]], dtype=object)
    """

    def __init__(self, encoder: Transformer):
        if not isinstance(encoder, Transformer):
            raise TypeError('`encoder` should be a transformer.')
        _BaseEncoder.__init__(self)
        self.encoder = encoder
        self.one_hot_encoder = OneHotEncoder()
        self.drop_columns = None
        self.label_names = []
        self.encoder_dict = {}
        self.columns = []
        self.idx_columns = np.ndarray([])
        self.column_names = []
        self.column_mapping = {}
        self.name = type(encoder).__name__

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series]) -> 'MultiClassBinaryEncoder':
        """Fit the transformer on the dataframe `X`.
        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None.
            labels.
        Returns
        -------
        MultiClassBinaryEncoder
            Instance of itself.
        """
        self.check_dataframe(X)
        self.check_y(X, y)
        self.check_y_dtype(y, int)
        self.columns = util.get_datatype_columns(X, object)
        self.check_nans(X, self.columns)
        self.drop_columns = DropColumns(self.columns).fit(X)
        if not self.columns:
            return self
        self.idx_columns = util.get_idx_columns(
            columns=X.columns,
            selected_columns=self.columns,
        )
        if isinstance(X, pd.DataFrame):
            y_one_hot = self.one_hot_encoder.fit_transform(
                pd.DataFrame(y, dtype=object)
            )
        else:
            y_one_hot = self.one_hot_encoder.fit_transform(
                ks.DataFrame(y.apply(lambda x: str(x)))
            )
        y_name = y.name
        y_one_hot = y_one_hot.drop(
            [
                f'{y_name}__0',
                f'{y_name}__MISSING',
                f'{y_name}__OTHERS'],
            axis=1
        ).astype(int)
        self.label_names = y_one_hot.columns
        for label_name in self.label_names:
            self.encoder_dict[label_name] = copy.deepcopy(self.encoder)
            self.encoder_dict[label_name].fit(
                X[self.columns], y_one_hot[label_name])
        return self

    def transform(self,
                  X: Union[pd.DataFrame, ks.DataFrame]
                  ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.
        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.       
        """
        self.check_dataframe(X)
        for i, label_name in enumerate(self.label_names):
            dummy = self.encoder_dict[label_name].transform(X[self.columns].copy())[
                self.encoder_dict[label_name].columns]
            column_names = [
                f'{col}__{label_name}_{self.name}' for col in dummy.columns]
            dummy.columns = column_names
            self.column_names.extend(column_names)
            for name, col in zip(column_names, self.columns):
                self.column_mapping[name] = col
            X = X.join(dummy)
        return self.drop_columns.transform(X).astype(np.float64)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.
        Parameters
        ----------
        X  : np.ndarray
            Input array.
        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        if not self.columns:
            return X
        X_encoded_list = []
        for i, label_name in enumerate(self.label_names):
            if not self.encoder_dict[label_name].idx_columns.shape[0]:
                continue
            dummy = self.encoder_dict[label_name].transform_numpy(
                X[:, self.idx_columns].copy())
            X_encoded_list.append(dummy)
        if not X_encoded_list:
            return X
        X_new = np.concatenate(
            [self.drop_columns.transform_numpy(X)] + X_encoded_list, axis=1)
        return X_new.astype(np.float64)
