import os

__version__ = "0.2.0"
os.environ["PYARROW_IGNORE_TIMEZONE"] = "1"
