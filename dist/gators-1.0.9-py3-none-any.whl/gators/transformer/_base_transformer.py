from pydantic import BaseModel, ConfigDict
from sklearn.base import BaseEstimator, TransformerMixin


class _BaseTransformer(BaseModel, BaseEstimator, TransformerMixin):
    """
    Base class for all transformers in the gators library.

    This class provides common functionality for all transformers.

    """

    model_config = ConfigDict(extra="forbid")
