from abc import ABCMeta

import polars as pl
from pydantic import Field, PositiveFloat, PositiveInt, PrivateAttr

from ..transformer._base_transformer import _BaseTransformer


class _BaseEncoder(_BaseTransformer, metaclass=ABCMeta):
    """
    Base encoder class for encoding categorical columns.

    Parameters
    ----------
    subset : list of str, default=None
        List of columns to encode. If None, all applicable columns are encoded.
    min_count : PositiveInt, PositiveFloat, default=1
        Minimum count or frequency for encoding categories.
    drop_columns : bool, default=True
        If True, the original columns are dropped after encoding.
    inplace : bool, default=True
        If True, replaces column values in-place. If False, creates new columns with suffix.

    Note
    ----
    _BaseEncoder is a base class and should not be used directly.
    Use one of the concrete encoder implementations instead.

    """

    subset: list[str] | None = None
    mapping_: dict[str, dict[str, float]] = Field(default_factory=dict)
    _column_mapping: dict[str, list[str]] = PrivateAttr(default_factory=dict)
    min_count: PositiveInt | PositiveFloat = 1
    drop_columns: bool = True
    inplace: bool = True

    _CAT_DTYPES: set = {pl.String, pl.Categorical, pl.Enum, pl.Boolean}

    def transform(self, X: pl.DataFrame) -> pl.DataFrame:
        """Transform the input DataFrame by extracting specified components.

        Parameters
        ----------
        X : pl.DataFrame
            Input DataFrame to transform.

        Returns
        -------
        pl.DataFrame
            Transformed DataFrame.
        """
        default_value = 0.0

        dtypes = dict(zip(X.columns, X.dtypes, strict=False))
        boolean_cols = {col for col in self.mapping_ if dtypes.get(col) == pl.Boolean}

        boolean_string_mappings = {
            col: {str(k).lower(): v for k, v in self.mapping_[col].items()} for col in boolean_cols
        }

        expressions = []

        if self.inplace:
            for col in self.mapping_:
                if col in boolean_cols:
                    # Boolean column: cast to string then replace
                    expr = (
                        pl.col(col)
                        .cast(pl.String)
                        .replace_strict(
                            boolean_string_mappings[col],
                            default=default_value,
                            return_dtype=pl.Float64,
                        )
                    )
                else:
                    # Non-boolean: direct replacement
                    expr = pl.col(col).replace_strict(
                        self.mapping_[col],
                        default=default_value,
                        return_dtype=pl.Float64,
                    )
                expressions.append(expr)
            return X.with_columns(expressions)

        for col in self.mapping_:
            new_col_name = self._column_mapping[col][0]

            if col in boolean_cols:
                expr = (
                    pl.col(col)
                    .cast(pl.String)
                    .replace_strict(
                        boolean_string_mappings[col], default=default_value, return_dtype=pl.Float64
                    )
                    .alias(new_col_name)
                )
            else:
                expr = (
                    pl.col(col)
                    .replace_strict(
                        self.mapping_[col], default=default_value, return_dtype=pl.Float64
                    )
                    .alias(new_col_name)
                )
            expressions.append(expr)

        X = X.with_columns(expressions)

        if self.drop_columns and self.subset:
            X = X.drop(self.subset)

        return X
