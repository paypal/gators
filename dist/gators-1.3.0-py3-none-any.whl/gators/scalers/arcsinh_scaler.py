import polars as pl
from pydantic import PrivateAttr

from ..transformer._base_transformer import _BaseTransformer


class ArcSinhScaler(_BaseTransformer):
    """
    Applies inverse hyperbolic sine (arcsinh) transformation.

    The transformation asinh(X) = log(X + sqrt(X^2 + 1)) is similar to log
    transformation but can handle zero and negative values. It's useful for
    stabilizing variance in data with both positive and negative values or
    wide dynamic range.

    Properties:

    - Defined for all real numbers (unlike log)
    - Approximately linear near zero
    - Approximately logarithmic for large abs(X)
    - Symmetric around zero: asinh(-X) = -asinh(X)

    This transformation is commonly used in:

    - Financial data with positive and negative returns
    - Data with extreme outliers
    - Variables spanning multiple orders of magnitude with zeros

    Parameters
    ----------
    subset : list[str], default=None
        List of numeric column names to transform. If None, all numeric columns
        (Float64, Int64, Float32, Int32) are automatically selected.
    inplace : bool, default=True
        If True, transform values in the original columns (keep original column names).
        If False, create new columns with suffix ``__arcsinh``.
    drop_columns : bool, default=True
        If ``inplace=False``, whether to drop the original columns after transformation.
        Ignored when ``inplace=True``.

    Examples
    --------
    Create an instance of the ArcSinhScaler class:

    >>> import polars as pl
    >>> from gators.scalers import ArcSinhScaler
    >>> scaler = ArcSinhScaler(subset=["returns", "profit"])

    Fit the transformer:

    >>> X = pl.DataFrame({
    ...     "returns": [-100, -10, 0, 10, 100],
    ...     "profit": [-50, -5, 0, 5, 50]
    ... })
    >>> scaler.fit(X)

    Transform the DataFrame:

    >>> transformed_X = scaler.transform(X)
    >>> print(transformed_X)
    shape: (5, 2)
    ┌───────────────────┬─────────────────┐
    │ returns__arcsinh  ┆ profit__arcsinh │
    │ ---               ┆ ---             │
    │ f64               ┆ f64             │
    ├───────────────────┼─────────────────┤
    │ -5.298            ┆ -4.606          │
    │ -2.998            ┆ -2.312          │
    │ 0.0               ┆ 0.0             │
    │ 2.998             ┆ 2.312           │
    │ 5.298             ┆ 4.606           │
    └───────────────────┴─────────────────┘

    Notes
    -----
    The transformation is symmetric:
    - asinh(X) ≈ log(2X) for large positive X
    - asinh(X) ≈ X for X near 0
    - asinh(-X) = -asinh(X)
    """

    subset: list[str] | None = None
    inplace: bool = True
    drop_columns: bool = True
    _column_mapping: dict[str, list[str]] = PrivateAttr(default_factory=dict)

    def fit(self, X: pl.DataFrame, y: pl.Series | None = None) -> "ArcSinhScaler":
        """Fit the transformer by storing column names.

        Parameters
        ----------
        X : pl.DataFrame
            Input DataFrame to fit.
        y : pl.Series, default=None
            Target series (not used, present for sklearn compatibility).

        Returns
        -------
        ArcSinhScaler
            The fitted transformer instance.
        """
        if not self.subset:
            # Use set for O(1) dtype lookup instead of list O(n) lookup
            self.subset = [
                col for col, dtype in zip(X.columns, X.dtypes, strict=False) if dtype.is_numeric()
            ]

        if not self.inplace:
            self._column_mapping = {col: [f"{col}__arcsinh"] for col in self.subset}
            self._output_dtypes = {new: X.schema[old] for old, news in self._column_mapping.items() for new in news}
        return self

    def transform(self, X: pl.DataFrame) -> pl.DataFrame:
        """Transform the input DataFrame by applying asinh(X).

        Parameters
        ----------
        X : pl.DataFrame
            Input DataFrame to transform.

        Returns
        -------
        pl.DataFrame
            Transformed DataFrame with arcsinh-transformed columns.
        """
        if self.inplace:
            assert self.subset is not None
            transformations = [pl.col(col).arcsinh().alias(col) for col in self.subset]
            return X.with_columns(transformations)

        transformations = [
            pl.col(col).arcsinh().alias(new) for col, [new] in self._column_mapping.items()
        ]
        X = X.with_columns(transformations)
        if self.drop_columns:
            assert self.subset is not None
            return X.drop(self.subset)
        return X

    def inverse_transform(self, X: pl.DataFrame) -> pl.DataFrame:
        """Reverse the arcsinh transformation via sinh.

        Parameters
        ----------
        X : pl.DataFrame
            DataFrame with arcsinh-transformed columns (output of ``transform``).

        Returns
        -------
        pl.DataFrame
            DataFrame with columns restored to their original scale.
        """
        if self.inplace:
            assert self.subset is not None
            exprs = [pl.col(col).sinh().alias(col) for col in self.subset]
            return X.with_columns(exprs)
        reverse_map = {v: k for k, values in self._column_mapping.items() for v in values}
        exprs = [
            pl.col(new).sinh().alias(orig) for new, orig in reverse_map.items() if new in X.columns
        ]
        X = X.with_columns(exprs)
        if self.drop_columns:
            return X.drop([c for c in reverse_map if c in X.columns])
        return X
