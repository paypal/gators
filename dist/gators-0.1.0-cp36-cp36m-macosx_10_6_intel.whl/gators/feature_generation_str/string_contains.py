# License: Apache-2.0
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from._base_string_feature import _BaseStringFeature


class StringContains(_BaseStringFeature):
    """String Contain Transformer.

    Parameters
    ----------
    columns : List[str]
        List of columns.
    contains_vec : List[int]
        List of substrings.
    column_names : List[int], default to None.
        List new column names. 

    Examples
    ---------
    >>> import pandas as pd
    >>> from gators.feature_generation_str import StringContains
    >>> X = pd.DataFrame({'A': ['qwe', 'qwd', 'zwe'], 'B': [1, 2, 3]})
    >>> obj = StringContains(columns=['A', 'A'], contains_vec=['qw', 'we'])
    >>> obj.fit_transform(X)
        A  B  A__contains_qw  A__contains_we
    0  qwe  1             1.0             1.0
    1  qwd  2             1.0             0.0
    2  zwe  3             0.0             1.0

    >>> import pandas as pd
    >>> from gators.feature_generation_str import StringContains
    >>> X = pd.DataFrame({'A': ['qwe', 'qwd', 'zwe'], 'B': [1, 2, 3]})
    >>> obj = StringContains(
    ...     columns=['A', 'A'], contains_vec=['qw', 'we'], column_names=['with_qw', 'qith_we'])
    >>> obj.fit_transform(X)
        A  B  with_qw  qith_we
    0  qwe  1      1.0      1.0
    1  qwd  2      1.0      0.0
    2  zwe  3      0.0      1.0

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_str import StringLength
    >>> X = ks.DataFrame({'A': ['qwe', 'asd', 'zxc'], 'B': [1, 2, 3]})
    >>> obj = StringContains(columns=['A', 'A'], contains_vec=['qw', 'we'])
    >>> obj.fit_transform(X)
        A  B  A__contains_qw  A__contains_we                                       
    0  qwe  1             1.0             1.0
    1  asd  2             0.0             0.0
    2  zxc  3             0.0             0.0

    >>> import pandas as pd
    >>> from gators.feature_generation_str import StringLength
    >>> X = ks.DataFrame({'A': ['qwe', 'asd', 'zxc'], 'B': [1, 2, 3]})
    >>> obj = StringContains(columns=['A', 'A'], contains_vec=['qw', 'we'])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([['qwe', 1, 1.0, 1.0],
           ['asd', 2, 0.0, 0.0],
           ['zxc', 3, 0.0, 0.0]], dtype=object)

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_str import StringLength
    >>> X = ks.DataFrame({'A': ['qwe', 'asd', 'zxc'], 'B': [1, 2, 3]})
    obj = StringContains(columns=['A', 'A'], contains_vec=['qw', 'we'])
    _ = obj.fit(X)
    obj.transform_numpy(X.to_numpy())
     array([['qwe', 1, 1.0, 1.0],
            ['asd', 2, 0.0, 0.0],
            ['zxc', 3, 0.0, 0.0]], dtype=object)  
    """

    def __init__(self, columns: List[str], contains_vec: List[str],
                 column_names: List[str] = None):
        if not isinstance(columns, list):
            raise TypeError('`columns` should be a list.')
        if not isinstance(contains_vec, list):
            raise TypeError('`contains_vec` should be a list.')
        if len(columns) != len(contains_vec):
            raise ValueError(
                'Length of `columns` and `contains_vec` should match.')
        if not column_names:
            column_names = [
                f'{col}__contains_{val}'
                for col, val in zip(columns, contains_vec)
            ]
        _BaseStringFeature.__init__(
            self, columns, column_names)
        self.contains_vec = np.array(contains_vec, str)

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        self.check_dataframe(X)
        val_dict = dict(zip(self.columns, self.contains_vec))

        def f(x, val_dict):
            return x.str.contains(val_dict[x.name], regex=False).astype(np.float64)
        X_new = X[self.columns].apply(f, args=(val_dict, ))
        X_new.columns = self.column_names
        return X.join(X_new)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        X_features = np.empty((X.shape[0], self.idx_columns.shape[0]), float)
        for i, (idx, val) in enumerate(zip(self.idx_columns, self.contains_vec)):
            X_features[:, i] = (np.core.defchararray.find(
                X[:, idx].astype(str), val) != -1)
        return np.concatenate((X, X_features.astype(np.float64)), axis=1)
