# License: Apache-2.0
from cython_feature_gen_str import cython_split_and_extract_str
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from._base_string_feature import _BaseStringFeature


class ExtractSplitString(_BaseStringFeature):
    """Extract Split Substring Transformer.

    Parameters
    ----------
    columns : List[str]
        List of columns.

    str_split_vec : List[int]
        List of separators.

    idx_split_vec : List[int]
        List of split indices.

    column_names : List[int]
        List of new column names.

    Examples
    ---------

    >>> import pandas as pd
    >>> from gators.feature_generation_str import ExtractSplitString
    >>> X = pd.DataFrame({'A': ['qw*e', 'a*qd', 'zxq*'], 'B': [1, 2, 3]})
    >>> obj = ExtractSplitString(
    ...     columns=['A','A'], str_split_vec=['*', '*'], idx_split_vec=[0, 1])
    >>> obj.fit_transform(X)
        A  B A__split_by_*_idx_0 A__split_by_*_idx_1
    0  qw*e  1                  qw                   e
    1  a*qd  2                   a                  qd
    2  zxq*  3                 zxq                    
    >>> import pandas as pd
    >>> from gators.feature_generation_str import ExtractSplitString
    >>> X = pd.DataFrame({'A': ['qw*e', 'a*qd', 'zxq*'], 'B': [1, 2, 3]})
    >>> obj = ExtractSplitString(
    ...     columns=['A','A'], str_split_vec=['*', '*'], idx_split_vec=[0, 1],
    ...     column_names=['A_before_star', 'A_after_star'])
    >>> obj.fit_transform(X)
        A  B A_before_star A_after_star
    0  qw*e  1            qw            e
    1  a*qd  2             a           qd
    2  zxq*  3           zxq             

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_str import ExtractSplitString
    >>> X = pd.DataFrame({'A': ['qw*e', 'a*qd', 'zxq*'], 'B': [1, 2, 3]})
    >>> obj = ExtractSplitString(
    ...     columns=['A','A'], str_split_vec=['*', '*'], idx_split_vec=[0, 1])
    >>> obj.fit_transform(X)
        A  B A__split_by_*_idx_0 A__split_by_*_idx_1
    0  qw*e  1                  qw                   e
    1  a*qd  2                   a                  qd
    2  zxq*  3                 zxq                    

    >>> import pandas as pd
    >>> from gators.feature_generation_str import ExtractSplitString
    >>> X = pd.DataFrame({'A': ['qw*e', 'a*qd', 'zxq*'], 'B': [1, 2, 3]})
    >>> obj = ExtractSplitString(
    ...     columns=['A','A'], str_split_vec=['*', '*'], idx_split_vec=[0, 1])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([['qw*e', 1, 'qw', 'e'],
        ['a*qd', 2, 'a', 'qd'],
        ['zxq*', 3, 'zxq', '']], dtype=object)

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_str import ExtractSplitString
    >>> X = pd.DataFrame({'A': ['qw*e', 'a*qd', 'zxq*'], 'B': [1, 2, 3]})
    >>> obj = ExtractSplitString(
    ...     columns=['A','A'], str_split_vec=['*', '*'], idx_split_vec=[0, 1])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([['qw*e', 1, 'qw', 'e'],
        ['a*qd', 2, 'a', 'qd'],
        ['zxq*', 3, 'zxq', '']], dtype=object)
    """

    def __init__(self, columns: List[str],
                 str_split_vec: List[int], idx_split_vec: List[int],
                 column_names: List[str] = None):
        if not isinstance(columns, list):
            raise TypeError('`columns` should be a list.')
        if not isinstance(str_split_vec, list):
            raise TypeError('`str_split_vec` should be a list.')
        if len(columns) != len(str_split_vec):
            raise ValueError(
                'Length of `columns` and `str_split_vec` should match.')
        if not isinstance(idx_split_vec, list):
            raise TypeError('`idx_split_vec` should be a list.')
        if len(columns) != len(idx_split_vec):
            raise ValueError(
                'Length of `columns` and `idx_split_vec` should match.')
        if not column_names:
            column_names = [
                f'{col}__split_by_{split}_idx_{idx}' for
                col, split, idx in zip(columns, str_split_vec, idx_split_vec)
            ]
        _BaseStringFeature.__init__(self, columns, column_names)
        self.str_split_vec = np.array(str_split_vec, object)
        self.idx_split_vec = np.array(idx_split_vec, int)

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        self.check_dataframe(X)
        str_split_dict = dict(zip(self.columns, self.str_split_vec))
        idx_dict = dict(zip(self.columns, self.idx_split_vec))

        def f(x, str_split_dict, idx_dict):
            str_split = str_split_dict[x.name]
            idx = idx_dict[x.name]
            return x.str.split(str_split).str[idx].fillna('MISSING')

        X_new = X[self.columns].apply(
            f, args=(str_split_dict, idx_dict))
        X_new.columns = self.column_names
        return X.join(X_new)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        return cython_split_and_extract_str(
            X, self.idx_columns, self.str_split_vec, self.idx_split_vec
        )
