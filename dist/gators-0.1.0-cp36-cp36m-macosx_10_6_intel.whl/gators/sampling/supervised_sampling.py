from typing import Tuple, Dict, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ..transformer import TransformerXY


class SupervisedSampling(TransformerXY):

    def __init__(self, n_samples: int):
        self.n_samples = n_samples

    def transform(self, X: Union[pd.DataFrame, ks.DataFrame],
                  y: Union[pd.Series, ks.Series]
                  ) -> Tuple[Union[pd.DataFrame, ks.DataFrame],
                             Union[pd.Series, ks.Series]]:
        """Fit and transform the dataframe `X` and the series `y`.

        Args:
        X Union[pd.DataFrame, ks.DataFrame]:
            Input dataframe.
        y Union[pd.Series, ks.Series]: 
            Input target.

        Returns:
        Tuple[Union[pd.DataFrame, ks.DataFrame], Union[pd.Series, ks.Series]]:
            Transformed dataframe and the series.
        """
        self.check_dataframe(X)
        self.check_y(X, y)
        y_name = y.name
        frac_vec = self.compute_sampling_fractions(y, self.n_samples)
        X_y = X.join(y)
        X_y_sampled = self.sample_frame(
            X_y=X_y,
            frac_vec=frac_vec,
            y_name=y_name
        )
        return X_y_sampled.drop(y_name, axis=1), X_y_sampled[y_name]

    @staticmethod
    def compute_sampling_fractions(y, n_samples):
        class_count = y.value_counts()
        n_classes = len(class_count)
        n_samples_per_class = int(n_samples / n_classes)
        mask = class_count > n_samples_per_class
        n_classes_ = mask.sum()
        n_samples_ = n_samples - class_count[~ mask].sum()
        frac_vec = n_samples_ / (class_count * n_classes_)
        if isinstance(frac_vec, ks.Series):
            frac_vec = frac_vec.to_pandas()
        frac_vec[frac_vec > 1] = 1.
        return frac_vec

    @staticmethod
    def sample_frame(X_y, frac_vec, y_name):
        if isinstance(X_y, pd.DataFrame):
            X_y_sampled = pd.DataFrame(columns=X_y.columns)
        else:
            X_y_sampled = ks.DataFrame(columns=X_y.columns)
        for c, frac in frac_vec.iteritems():
            if frac == 1:
                X_y_sampled = util.concat(
                    [X_y_sampled, X_y[X_y[y_name] == int(c)]], axis=0)
            else:
                X_y_sampled = util.concat(
                    [X_y_sampled,
                     X_y[X_y[y_name] == int(c)].sample(frac=frac, random_state=0)],
                    axis=0
                )
        return X_y_sampled.astype(X_y.dtypes.to_dict())
