
from typing import Tuple, Dict, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..transformer import TransformerXY


class UnsupervisedSampling(TransformerXY):
    """Unsupervised Sampling class.

    Parameters
    ----------
    n_samples : int
        Number of samples to keep.
    """

    def __init__(self, n_samples: int):
        if not isinstance(n_samples, int):
            raise TypeError('`n_samples` should be an int.')
        self.n_samples = n_samples

    def transform(self,
                  X: Union[pd.DataFrame, ks.DataFrame],
                  y: Union[pd.Series, ks.Series],
                  ) -> Tuple[Union[pd.DataFrame, ks.DataFrame], Union[pd.Series, ks.Series]]:
        """Fit and transform the dataframe `X` and the series `y`.

        Args:
        X Union[pd.DataFrame, ks.DataFrame]:
            Input dataframe.
        y Union[pd.Series, ks.Series]: 
            Input target.

        Returns:
        Tuple[Union[pd.DataFrame, ks.DataFrame], Union[pd.Series, ks.Series]]:
            Transformed dataframe and the series.
        """
        self.check_dataframe(X)
        self.check_y(X, y)
        frac = self.n_samples / X.shape[0]
        if frac >= 1.:
            return X, y
        y_name = y.name
        X_y = X.join(y).sample(frac=round(frac, 3), random_state=0)
        return X_y.drop(y_name, axis=1), X_y[y_name]
