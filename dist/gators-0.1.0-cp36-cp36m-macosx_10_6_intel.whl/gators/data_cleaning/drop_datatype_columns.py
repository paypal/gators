# License: Apache-2.0
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ._base_drop_columns import _BaseDropColumns


class DropDatatypeColumns(_BaseDropColumns):
    """Drop Datatype Columns Transformer.

    Parameters
    ----------
    dtype : dtype
        Colum datatype to drop.

    Examples
    ---------
    * fit & transform with pandas 
    >>> import pandas as pd
    >>> from gators.data_cleaning import DropDatatypeColumns
    >>> X = pd.DataFrame({'A': [1, 2, 3], 'B': [1., 1., 1.]})
    >>> obj = DropDatatypeColumns(float)
    >>> obj.fit_transform(X) 
        A
    0	1
    1	2
    2	3

    * fit & transform with koalas 
    >>> import databricks.koalas as ks
    >>> from gators.data_cleaning import DropDatatypeColumns
    >>> X = ks.DataFrame({'A': [1, 2, 3], 'B': [1., 1., 1.]})
    >>> obj = DropDatatypeColumns(float)
    >>> obj.fit_transform(X)
        A
    0	1
    1	2
    2	3

    * fit with pandas & transform with numpy 
    >>> import pandas as pd
    >>> from gators.data_cleaning import DropDatatypeColumns
    >>> X = pd.DataFrame({'A': [1, 2, 3], 'B': [1., 1., 1.]})
    >>> obj = DropDatatypeColumns(float)
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1.],
           [2.],
           [3.]])

    * fit with koalas & transform with numpy 
    >>> import databricks.koalas as ks
    >>> from gators.data_cleaning import DropDatatypeColumns
    >>> X = ks.DataFrame({'A': [1, 2, 3], 'B': [1., 1., 1.]})
    >>> obj = DropDatatypeColumns(float)
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1.],
           [2.],
           [3.]])
    """

    def __init__(self,  dtype: type):
        if not isinstance(dtype, type):
            raise TypeError('`dtype` should be a type.')
        _BaseDropColumns.__init__(self)
        self.dtype = dtype

    def fit(self, X: Union[pd.DataFrame, ks.DataFrame],
            y=None) -> 'DropDatatypeColumns':
        """Fit the transformer on the dataframe X.

        Get the list of column names to be removed and the array of
            indices to be kept.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.
        y : None
           None
        Returns
        -------
        DropDatatypeColumns: Instance of itself.
        """
        self.check_dataframe(X)
        self.columns_to_drop = util.get_datatype_columns(
            X,
            self.dtype,
        )
        self.columns_to_keep = util.get_columns_not_in_selected_columns(
            columns=X.columns,
            selected_columns=self.columns_to_drop,
        )
        self.idx_columns_to_keep = self.get_idx_columns_to_keep(
            columns=X.columns,
            columns_to_drop=self.columns_to_drop
        )
        return self
