# License: Apache-2.0
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ._base_drop_columns import _BaseDropColumns


class DropHighCardinality(_BaseDropColumns):
    """Drop High Cardinality Transformer.

    Parameters
    ----------
    max_categories : int
        Maximum number of categories allowed.

    Examples
    ---------
    * fit & transform with pandas 
    >>> import pandas as pd
    >>> from gators.data_cleaning import DropColumns
    >>> X = pd.DataFrame({'A': [1, 2, 3], 'B': [1, 1, 1]})
    >>> obj = DropColumns(['B'])
    >>> obj.fit_transform(X) 
        A
    0	1
    1	2
    2	3

    * fit & transform with koalas 
    >>> import databricks.koalas as ks
    >>> from gators.data_cleaning import DropColumns
    >>> X = ks.DataFrame({'A': [1, 2, 3], 'B': [1, 1, 1]})
    >>> obj = DropColumns(['B'])
    >>> obj.fit_transform(X)
        A
    0	1
    1	2
    2	3

    * fit with pandas & transform with numpy 
    >>> import pandas as pd
    >>> from gators.data_cleaning import DropColumns
    >>> X = pd.DataFrame({'A': [1, 2, 3], 'B': [1, 1, 1]})
    >>> obj = DropColumns(['B'])
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1],
           [2],
           [3]])

    * fit with koalas & transform with numpy 
    >>> import databricks.koalas as ks
    >>> from gators.data_cleaning import DropColumns
    >>> X = ks.DataFrame({'A': [1, 2, 3], 'B': [1, 1, 1]})
    >>> obj = DropColumns(['B'])
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1],
           [2],
           [3]])
    """

    def __init__(self, max_categories: int):
        if not isinstance(max_categories, int):
            raise TypeError('`max_categories` should be an int.')
        _BaseDropColumns.__init__(self)
        self.max_categories = max_categories

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'DropHighCardinality':
        """Fit the transformer on the dataframe `X`.

        Get the list of column names to be removed and the array of
           indices to be kept.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.
        y : None
           None
        Returns
        -------
            DropHighCardinality: Instance of itself.
        """
        self.check_dataframe(X)
        self.columns_to_drop = self.get_columns_to_drop(
            X=X,
            max_categories=self.max_categories
        )
        self.columns_to_keep = util.get_columns_not_in_selected_columns(
            columns=X.columns,
            selected_columns=self.columns_to_drop,
        )
        self.idx_columns_to_keep = self.get_idx_columns_to_keep(
            columns=X.columns,
            columns_to_drop=self.columns_to_drop,
        )
        return self

    @ staticmethod
    def get_columns_to_drop(
            X: Union[pd.DataFrame, ks.DataFrame],
            max_categories: int) -> List[str]:
        """Get the column names to drop.

        Parameters
        ----------
        X_nunique : pd.DataFrame
            Input dataframe.
        max_categories : int
            Maximum number of categories allowed.

        Returns
        -------
        List[str]
            List of column names to drop.
        """
        object_columns = util.get_datatype_columns(X, object)
        if not object_columns:
            return []
        if isinstance(X, pd.DataFrame):
            X_nunique = X[object_columns].nunique()
        else:
            X_nunique = X[object_columns].nunique(approx=True)
        mask_columns = X_nunique > max_categories
        columns_to_drop = X_nunique[mask_columns].index
        return list(columns_to_drop.to_numpy())
