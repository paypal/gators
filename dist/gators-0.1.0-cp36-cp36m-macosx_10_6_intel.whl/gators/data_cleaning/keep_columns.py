# License: Apache-2.0
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ._base_drop_columns import _BaseDropColumns
from ..util import util


class KeepColumns(_BaseDropColumns):
    """Drop Datetime Column Transformer.

    Parameters
    ----------
    columns_to_keep : List[str]
        List of columns.

    Examples
    ---------

    * fit & transform with pandas 
    >>> import pandas as pd
    >>> from gators.data_cleaning import KeepColumns
    >>> X = pd.DataFrame({'A': [1, 2, 3], 'B': [1, 1, 1]})
    >>> obj = KeepColumns(['A'])
    >>> obj.fit_transform(X) 
        A
    0	1
    1	2
    2	3

    * fit & transform with koalas 
    >>> import databricks.koalas as ks
    >>> from gators.data_cleaning import KeepColumns
    >>> X = ks.DataFrame({'A': [1, 2, 3], 'B': [1, 1, 1]})
    >>> obj = KeepColumns(['A'])
    >>> obj.fit_transform(X)
        A
    0	1
    1	2
    2	3

    * fit with pandas & transform with numpy 
    >>> import pandas as pd
    >>> from gators.data_cleaning import KeepColumns
    >>> X = pd.DataFrame({'A': [1, 2, 3], 'B': [1, 1, 1]})
    >>> obj = KeepColumns(['A'])
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1],
           [2],
           [3]])

    * fit with koalas & transform with numpy 
    >>> import databricks.koalas as ks
    >>> from gators.data_cleaning import KeepColumns
    >>> X = ks.DataFrame({'A': [1, 2, 3], 'B': [1, 1, 1]})
    >>> obj = KeepColumns(['A'])
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1],
           [2],
           [3]])
    """

    def __init__(self, columns_to_keep):
        if not isinstance(columns_to_keep, list):
            raise TypeError('`columns_to_keep` should be a list.')
        _BaseDropColumns.__init__(self)
        self.columns_to_keep = columns_to_keep

    def fit(self, X: Union[pd.DataFrame, ks.DataFrame],
            y=None) -> 'KeepColumns':
        """Fit the transformer on the dataframe X.

        Get the list of column names to be removed and the array of
          indices to be kept.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None. 
            labels.

        Returns
        -------
        KeepColumns: Instance of itself.
        """
        self.check_dataframe(X)
        self.columns_to_drop = util.get_columns_not_in_selected_columns(
            columns=X.columns,
            selected_columns=self.columns_to_keep)
        self.idx_columns_to_keep = util.get_idx_columns_not_in_selected_columns(
            columns=X.columns,
            selected_columns=self.columns_to_drop
        )
        return self
