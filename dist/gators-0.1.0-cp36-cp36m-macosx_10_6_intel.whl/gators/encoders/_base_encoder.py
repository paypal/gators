# License: Apache-2.0
from typing import List, Tuple, Union, Dict, Collection, Any
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..transformer.transformer import Transformer
from ..util import util
from cython_encoder import cython_encoder


class _BaseEncoder(Transformer):
    """Base Encoder Transformer.

    Parameters
    ----------
        Transformer (Transformer): Abstract transformer.
    """

    def __init__(self):
        """Init Base Encoder Transformer."""
        Transformer.__init__(self)
        self.columns = []
        self.idx_columns = np.array([])
        self.num_categories_vec = np.array([])
        self.values_vec = np.array([])
        self.encoded_values_vec = np.array([])
        self.mapping: Dict[str, Collection[Any]] = {}
        self.X_dtypes: Union[pd.DataFrame, ks.DataFrame] = None

    def transform(self,
                  X: Union[pd.DataFrame, ks.DataFrame]
                  ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """
        self.check_dataframe(X)
        if isinstance(X, pd.DataFrame):
            def encode(x, mapping):
                col = x.name
                return x.map(mapping[col])

            X[self.columns] = X[self.columns].apply(
                encode, args=(self.mapping, )).astype(np.float64)
        else:
            for key, val in self.mapping.items():
                X[key] = X[key].map(val).astype(np.float64)
        return X.astype(np.float64)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the input array.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray: Encoded array.
        """
        self.check_array(X)
        if len(self.idx_columns) == 0:
            return X
        return cython_encoder(
            X,
            self.num_categories_vec,
            self.values_vec,
            self.encoded_values_vec,
            self.idx_columns,
        ).astype(np.float64)

    @ staticmethod
    def decompose_mapping(
            mapping: List[Dict[str, Collection[Any]]],
    ) -> Tuple[List[str], np.ndarray, np.ndarray]:
        """Decompose the mapping.

        Parameters
        ----------
        mapping List[Dict[str, Collection[Any]]]:
            Mapping obtained from the categorical encoder package.

        Returns
        -------
        Tuple[List[str], np.ndarray, np.ndarray]
            Decomposed mapping.
        """
        columns = list(mapping.keys())
        n_columns = len(columns)
        max_categories = max([len(m) for m in mapping.values()])
        encoded_values_vec = np.zeros((n_columns, max_categories))
        values_vec = np.zeros(
            (n_columns, max_categories), dtype=object
        )
        for i, c in enumerate(columns):
            mapping_col = mapping[c]
            n_values = len(mapping_col)
            encoded_values_vec[i, :n_values] = np.array(
                list(mapping_col.values()))
            values_vec[i, :n_values] = np.array(
                list(mapping_col.keys()))
        return columns, values_vec, encoded_values_vec

    @staticmethod
    def check_nans(X: Union[pd.DataFrame, ks.DataFrame],
                   columns: List[str]):
        """Raise an error if X contains NaN values.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Dataframe.
        columns : List[str]
            List of columns.
        """
        if X[columns].isnull().sum().sum() != 0:
            raise ValueError(
                '''The object columns should not contain
                any NaN values, use `ObjectImputer` before
                calling an encoder.`'''
            )

    @staticmethod
    def check_y_dtype(y: Union[pd.Series, ks.Series],
                      dtype: type):
        """Raise an error if the target datatype is not expected.

        Parameters
        ----------
        y : Union[pd.Series, ks.Series]
            Target values.
        dtype : type
            Datatype.
        """
        if y.dtype != dtype:
            raise TypeError(f'`y` should be a Series of {dtype}.')

    @staticmethod
    def check_if_y_is_binary(y: Union[pd.Series, ks.Series]):
        """Raise an error if the target datatype is not expected.

        Parameters
        ----------
        y : Union[pd.Series, ks.Series]
            Target values.
        """
        if y.nunique() != 2:
            raise ValueError('`y` should be binary.')
