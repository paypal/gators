# License: Apache-2.0
from typing import List, Union
import copy
import pandas as pd
import databricks.koalas as ks
import numpy as np
from ..util import util
from ..transformer import Transformer
from ..binning import BinNumerics
from ..data_cleaning import DropColumns
from ._base_encoder import _BaseEncoder
from .onehot_encoder import OneHotEncoder


class RegressionBinaryEncoder(_BaseEncoder):
    """Regression Encoder Transformer.

    Parameters
    ----------
    encoder : Transformer.
        Encoder.

    n_bins(int): Number of bins.
        The continuous labels will be binned in `n_bins` categories.
    """

    def __init__(self, encoder: Transformer, n_bins: int):
        if not isinstance(n_bins, int):
            raise TypeError('`n_bins` should be an int.')
        if not isinstance(encoder, Transformer):
            raise TypeError('`encoder` should be a transformer.')

        self.encoder = encoder
        self.binning = BinNumerics(n_bins)
        self.onehot_encoder = OneHotEncoder()
        self.drop_columns = None
        self.label_names = []
        self.encoder_dict = {}
        self.columns = []
        self.idx_columns = np.array([])
        self.name = type(encoder).__name__

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series]) -> 'RegressionBinaryEncoder':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None. 
            labels.

        Returns
        -------
        RegressionBinaryEncoder
            Instance of itself.
        """
        self.check_dataframe(X)
        self.check_y(X, y)
        self.check_y_dtype(y, float)
        self.columns = util.get_datatype_columns(X, object)
        self.check_nans(X, self.columns)
        self.drop_columns = DropColumns(self.columns).fit(X)
        if not self.columns:
            return self
        self.idx_columns = util.get_idx_columns_in_selected_columns(
            columns=X.columns,
            selected_columns=self.columns,
        )
        y_name = y.name
        if isinstance(X, pd.DataFrame):
            y_binned = self.binning.fit_transform(pd.DataFrame(y))
            y_binned = y_binned.drop(y_name, axis=1).astype(int).astype(object)
            y_onehot = self.onehot_encoder.fit_transform(
                pd.DataFrame(y_binned)
            )
        else:
            y_binned = self.binning.fit_transform(ks.DataFrame(y))
            y_binned = y_binned.drop(y_name, axis=1)
            y_binned = y_binned.astype(int)
            y_binned.columns = [str(c) for c in y_binned.columns]
            y_onehot = self.onehot_encoder.fit_transform(
                ks.DataFrame(
                    y_binned[f'{y_name}__bin'].apply(lambda x: str(x)))
            )
        y_onehot = y_onehot.drop(
            [
                f'{y_name}__bin__0',
                f'{y_name}__bin__MISSING',
                f'{y_name}__bin__OTHERS'],
            axis=1
        ).astype(int)
        self.label_names = y_onehot.columns
        for label_name in self.label_names:
            self.encoder_dict[label_name] = copy.deepcopy(self.encoder)
            self.encoder_dict[label_name].fit(
                X[self.columns], y_onehot[label_name])
        return self

    def transform(self,
                  X: Union[pd.DataFrame, ks.DataFrame]
                  ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        self.check_dataframe(X)
        X_encoded_list = []
        for label_name, encoder in self.encoder_dict.items():
            dummy = encoder.transform(X[self.columns].copy())[
                encoder.columns]
            dummy.columns = [
                f'{col}__{label_name}__{self.name}' for col in dummy.columns]
            X_encoded_list.append(dummy)
        X_new = util.concat(
            [self.drop_columns.transform(X)] + X_encoded_list, axis=1).astype(np.float64)
        return X_new.astype(np.float64)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        if not self.columns:
            return X
        X_encoded_list = []
        for i, label_name in enumerate(self.label_names):
            if not self.encoder_dict[label_name].idx_columns.shape[0]:
                continue
            dummy = self.encoder_dict[label_name].transform_numpy(
                X[:, self.idx_columns].copy())
            X_encoded_list.append(dummy)
        if not X_encoded_list:
            return X
        X_new = np.concatenate(
            [self.drop_columns.transform_numpy(X)] + X_encoded_list, axis=1)
        return X_new.astype(np.float64)
