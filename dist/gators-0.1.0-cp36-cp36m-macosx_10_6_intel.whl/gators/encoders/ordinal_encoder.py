# License: Apache-2.0
from typing import List, Union, Dict, Union, Collection, Any
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ._base_encoder import _BaseEncoder
from ..util import util


class OrdinalEncoder(_BaseEncoder):
    """Ordinal Encoder Transformer.

    Examples
    ---------

    * fit & transform with pandas 
    >>> import pandas as pd
    >>> from gators.encoders import OrdinalEncoder
    >>> X = pd.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> obj = OrdinalEncoder()
    >>> obj.fit_transform(X)
        A	B
    0	2.0	2.0
    1	2.0	1.0
    2	1.0	1.0

    * fit & transform with koalas 
    >>> import databricks.koalas as ks
    >>> from gators.encoders import OrdinalEncoder
    >>> X = ks.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> obj = OrdinalEncoder()
    >>> obj.fit_transform(X)
        A	B
    0	2.0	2.0
    1	2.0	1.0
    2	1.0	1.0

    * fit pandas & transform numpy 
    >>> import pandas as pd
    >>> from gators.encoders import OrdinalEncoder
    >>> X = pd.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> obj = OrdinalEncoder()
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[2.0, 2.0],
           [2.0, 1.0],
           [1.0, 1.0]], dtype=object)

    * fit koalas & transform numpy 
    >>> import databricks.koalas as ks
    >>> from gators.encoders import OrdinalEncoder
    >>> X = ks.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> obj = OrdinalEncoder()
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[2.0, 2.0],
           [2.0, 1.0],
           [1.0, 1.0]], dtype=object)
    """

    def __init__(self):
        _BaseEncoder.__init__(self)

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'OrdinalEncoder':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None. 
            labels.

        Returns
        -------
        OrdinalEncoder: Instance of itself.
        """
        self.check_dataframe(X)
        self.columns = util.get_datatype_columns(X, object)
        self.check_nans(X, self.columns)
        if not self.columns:
            return self
        self.mapping = self.generate_mapping(X, self.columns)
        self.num_categories_vec = np.array(
            [len(m) for m in self.mapping.values()]
        )
        columns, self.values_vec, self.encoded_values_vec = \
            self.decompose_mapping(
                mapping=self.mapping,
            )
        self.idx_columns = util.get_idx_columns_in_selected_columns(
            columns=X.columns, selected_columns=columns
        )
        return self

    @staticmethod
    def generate_mapping(
            X: Union[pd.DataFrame, ks.DataFrame],
            columns: List[str]) -> Dict[str, Dict[str, float]]:
        """Generate the mapping to perform the encoding.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame])
            Input dataframe.
        self.columns : List[str]
            List of  columns.

        Returns
        -------
        Dict[str, Dict[str, float]]
            Mapping.
        """
        mapping = {}
        for c in columns:
            categories = X[c].value_counts().to_dict()
            n_categories = len(categories)
            category_names = list(categories.keys())
            category_names = sorted(category_names)
            category_mapping = dict(zip(
                category_names,
                np.arange(n_categories-1, -1, -1).astype(str)
            ))
            if 'MISSING' not in category_mapping:
                category_mapping['MISSING'] = str(len(category_mapping))
            if 'OTHERS' not in category_mapping:
                category_mapping['OTHERS'] = str(len(category_mapping))
            mapping[c] = category_mapping

        return mapping
