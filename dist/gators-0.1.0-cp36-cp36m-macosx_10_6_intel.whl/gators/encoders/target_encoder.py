# License: Apache-2.0
from typing import List, Union, Dict, Union, Collection, Any
from math import log
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ._base_encoder import _BaseEncoder


def clean_mapping(mapping: Dict[str, Dict[str, List[float]]]
                  ) -> Dict[str, Dict[str, List[float]]]:
    mapping = {
        col: {k: v for k, v in mapping[col].items() if v == v}
        for col in mapping.keys()
    }
    for m in mapping.values():
        if 'OTHERS' not in m:
            m['OTHERS'] = 0.
        if 'MISSING' not in m:
            m['MISSING'] = 0.
    return mapping


class TargetEncoder(_BaseEncoder):
    """Weight of Evidence Encoder Transformer.


    Examples
    ---------

    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.encoders import TargetEncoder
    >>> X = pd.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> y = pd.Series([1, 1, 0], name='TARGET')
    >>> obj = TargetEncoder()
    >>> obj.fit_transform(X, y)
            A         B
    0  1.098612  0.693147
    1  1.098612 -0.405465
    2 -1.098612 -0.405465

    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.encoders import TargetEncoder
    >>> X = ks.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> y = pd.Series([1, 1, 0], name='TARGET')
    >>> obj = TargetEncoder()
    >>> obj.fit_transform(X, y)
            A         B
    0  1.098612  0.693147
    1  1.098612 -0.405465
    2 -1.098612 -0.405465

    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.encoders import TargetEncoder
    >>> X = pd.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> y = pd.Series([1, 1, 0], name='TARGET')
    >>> obj = TargetEncoder()
    >>> obj.fit(X, y)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1.0986122886681098, 0.6931471805599453],
        [1.0986122886681098, -0.40546510810816444],
        [-1.0986122886681098, -0.40546510810816444]], dtype=object)

    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.encoders import TargetEncoder
    >>> X = ks.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> y = pd.Series([1, 1, 0], name='TARGET')
    >>> obj = TargetEncoder()
    >>> obj.fit(X, y)
    >>> obj.transform(X.to_numpy())
    array([[1.0986122886681098, 0.6931471805599453],
        [1.0986122886681098, -0.40546510810816444],
        [-1.0986122886681098, -0.40546510810816444]], dtype=object)
    """

    def __init__(self):
        _BaseEncoder.__init__(self)

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series]) -> 'TargetEncoder':
        """Fit the encoder.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]:
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None. 
            labels.

        Returns
        -------
        TargetEncoder:
            Instance of itself.
        """
        self.check_dataframe(X)
        self.check_y(X, y)
        self.check_y_dtype(y, int)
        self.columns = util.get_datatype_columns(X, object)
        self.check_nans(X, self.columns)
        if not self.columns:
            return self
        self.mapping = self.generate_mapping(
            X[self.columns], y)
        self.num_categories_vec = np.array(
            [len(m) for m in self.mapping.values()]
        )
        columns, self.values_vec, self.encoded_values_vec = \
            self.decompose_mapping(mapping=self.mapping)
        self.idx_columns = util.get_idx_columns_in_selected_columns(
            columns=X.columns, selected_columns=columns
        )
        return self

    @staticmethod
    def generate_mapping(
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series],

    ) -> Dict[str, Dict[str, float]]:
        """Generate the mapping to perform the encoding.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.
        y Union[pd.Series, ks.Series]:
            labels.
        Returns
        -------
        Dict[str, Dict[str, float]]
            Mapping.
        """
        y_name = y.name
        if isinstance(X, pd.DataFrame):
            def f(x):
                return pd.DataFrame(x).join(y).groupby(x.name).mean()[y_name]

            mapping = X.apply(f).to_dict()
            return clean_mapping(mapping)

        mapping_list = []
        for name in X.columns:
            dummy = ks.DataFrame(X[name]).join(y).groupby(
                name).mean()[y_name].to_pandas()
            dummy.name = name
            mapping_list.append(dummy)

        mapping = pd.concat(mapping_list, axis=1).to_dict()
        return clean_mapping(mapping)
