# License: Apache-2.0
from typing import List, Union, Dict, Union, Collection, Any
import numpy as np
from scipy.sparse import csr_matrix
import pandas as pd
import databricks.koalas as ks
from ._base_encoder import _BaseEncoder
from ..util import util
from . import OrdinalEncoder


class OneHotEncoder(_BaseEncoder):
    """One Hot Encoder Transformer.

    Examples
    ---------

    >>> import pandas as pd
    >>> from gators.encoders import OneHotEncoder
    >>> X = pd.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> obj = OneHotEncoder()
    >>> obj.fit_transform(X)
        A__a	A__b	B__c	B__d
    0	1.0	0.0	1.0	0.0
    1	1.0	0.0	0.0	1.0
    2	0.0	1.0	0.0	1.0

    >>> import databricks.koalas as ks
    >>> from gators.encoders import OneHotEncoder
    >>> X = ks.DataFrame({'A': ['a', 'b', 'c'], 'B': ['c', 'd', 'd']})
    >>> obj = OneHotEncoder()
    >>> obj.fit_transform(X)
        A__a	A__b	B__c	B__d
    0	1.0	0.0	1.0	0.0
    1	1.0	0.0	0.0	1.0
    2	0.0	1.0	0.0	1.0

    >>> import pandas as pd
    >>> from gators.encoders import OneHotEncoder
    >>> X = pd.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> obj = OneHotEncoder()
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1, 0, 1, 0],
        [1, 0, 0, 1],
        [0, 1, 0, 1]], dtype=object)

    >>> import databricks.koalas as ks
    >>> from gators.encoders import OneHotEncoder
    >>> X = ks.DataFrame({'A': ['a', 'a', 'b'], 'B': ['c', 'd', 'd']})
    >>> obj = OneHotEncoder()
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1, 0, 1, 0],
        [1, 0, 0, 1],
        [0, 1, 0, 1]], dtype=object)
    """

    def __init__(self):
        _BaseEncoder.__init__(self)
        self.ordinal_encoder = OrdinalEncoder()
        self.idx_other_columns = np.array([])
        self.onehot_columns = []
        self.other_columns = []
        self.column_mapping = {}

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'OneHotEncoder':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.
        y None
            None.

        Returns
        -------
        OneHotEncoder: Instance of itself.
        """
        self.check_dataframe(X)
        self.columns = util.get_datatype_columns(X, object)
        self.check_nans(X, self.columns)
        self.other_columns = util.get_columns_not_in_selected_columns(
            X.columns, self.columns)
        _ = self.ordinal_encoder.fit(X)
        self.onehot_columns = []  # important to keep for RegressionBinaryRegression
        for key, val in self.ordinal_encoder.mapping.items():
            self.onehot_columns.extend(
                [f'{key}__{float(c)}'
                 for c in sorted(val.values(), key=int)])
        for key, val in self.ordinal_encoder.mapping.items():
            for k, v in val.items():
                self.column_mapping[f'{key}__{float(v)}'] = \
                    f'{key}__{k}'
        self.all_columns = self.other_columns + self.onehot_columns
        self.idx_other_columns = util.get_idx_columns_in_selected_columns(
            X.columns, self.other_columns)
        self.idx_columns = np.arange(
            len(self.other_columns),
            len(self.other_columns)+len(self.onehot_columns),
            dtype=int)
        self.n_categories_vec = np.empty(
            len(self.ordinal_encoder.columns), int)
        for i, c in enumerate(self.columns):
            self.n_categories_vec[i] = \
                len(self.ordinal_encoder.mapping[c])
        return self

    def transform(self,
                  X: Union[pd.DataFrame, ks.DataFrame],
                  ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame].
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """
        self.check_dataframe(X)
        if not self.columns:
            return X
        dummy = X[self.columns].copy()
        X_new = self.ordinal_encoder.transform(X)
        X[self.columns] = dummy
        if isinstance(X, pd.DataFrame):
            X_new = pd.get_dummies(
                X_new,
                prefix_sep='__',
                columns=self.columns)
        else:
            X_new = ks.get_dummies(
                X_new,
                prefix_sep='__',
                columns=self.columns)
        X_new = X_new.reindex(columns=self.all_columns, fill_value=0.)
        return X_new.rename(columns=self.column_mapping).astype(np.float64)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the input array.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray: Encoded array.
        """
        self.check_array(X)
        if len(self.idx_columns) == 0:
            return X
        n_rows = X.shape[0]
        X_ordinal = self.ordinal_encoder.transform_numpy(X)
        X_new = X[:, self.idx_other_columns].astype(float)
        X_onehot = np.zeros((n_rows, self.n_categories_vec.sum()))
        j_max = 0
        for i, n in enumerate(self.n_categories_vec):
            i_col = self.ordinal_encoder.idx_columns[i]
            j_min, j_max = j_max, j_max+n  # +1
            n_cols = self.n_categories_vec[i]
            dummy = csr_matrix(
                (np.ones(n_rows),
                 (np.arange(n_rows), X_ordinal[:, i_col])),
                shape=(n_rows, n_cols)
            ).toarray()
            X_onehot[:, j_min: j_max] = dummy
        return np.concatenate((X_new, X_onehot), axis=1)
