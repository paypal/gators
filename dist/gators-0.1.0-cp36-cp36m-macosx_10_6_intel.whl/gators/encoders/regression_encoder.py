# License: Apache-2.0
from typing import List, Union
import copy
import pandas as pd
import databricks.koalas as ks
import numpy as np
from ..util import util
from ..transformer import Transformer
from ..binning import BinNumerics
from ..data_cleaning import DropColumns
from ._base_encoder import _BaseEncoder
from .onehot_encoder import OneHotEncoder


class RegressionEncoder(_BaseEncoder):
    """Regression Encoder Transformer.

    Parameters
    ----------
    encoder : Transformer.
        Encoder.

    n_bins(int): Number of bins.
        The continuous labels will be binned in `n_bins` categories.
    """

    def __init__(self, encoder: Transformer, n_bins: int):
        if not isinstance(n_bins, int):
            raise TypeError('`n_bins` should be an int.')
        if not isinstance(encoder, Transformer):
            raise TypeError('`encoder` should be a transformer.')

        self.encoder = encoder
        self.binning = BinNumerics(n_bins)
        self.one_hot_encoder = OneHotEncoder()
        self.drop_columns = None
        self.label_names = []
        self.encoder_dict = {}
        self.columns = []
        self.idx_columns = np.array([])
        self.name = type(encoder).__name__

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series]) -> 'RegressionEncoder':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None. 
            labels.

        Returns
        -------
        RegressionEncoder
            Instance of itself.
        """
        self.check_dataframe(X)
        self.check_y(X, y)
        self.check_y_dtype(y, float)
        self.columns = util.get_datatype_columns(X, object)
        self.check_nans(X, self.columns)
        self.drop_columns = DropColumns(self.columns).fit(X)
        if not self.columns:
            return self
        self.idx_columns = util.get_idx_columns_in_selected_columns(
            columns=X.columns,
            selected_columns=self.columns,
        )
        y_name = y.name
        if isinstance(X, pd.DataFrame):
            y_binned = self.binning.fit_transform(pd.DataFrame(y))

        else:
            y_binned = self.binning.fit_transform(ks.DataFrame(y))
        y_binned = y_binned[f'{y_name}__bin'].astype(int)
        self.encoder.fit(X, y_binned)
        return self

    def transform(self,
                  X: Union[pd.DataFrame, ks.DataFrame]
                  ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        return self.encoder.transform(X)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        return self.encoder.transform_numpy(X)
