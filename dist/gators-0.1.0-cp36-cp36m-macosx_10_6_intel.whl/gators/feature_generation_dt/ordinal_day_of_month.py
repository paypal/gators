# Licence Apache-2.0
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ._base_datetime_features import _BaseDatetimeFeatures
import cython_feature_gen_dt


class OrdinalDayOfMonth(_BaseDatetimeFeatures):
    """Ordinal Datetime Transformer.

    Parameters
    ----------
    columns : List[str]
        List of columns.

    Examples
    ---------
    >>> import pandas as pd
    >>> from gators.feature_generation_dt import OrdinalDayOfMonth
    >>> X = pd.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = OrdinalDayOfMonth(columns=['A'])
    >>> obj.fit_transform(X)
                        A  B  A__month_of_year_cos  A__month_of_year_sin
    0 2020-01-01 23:00:00  0              0.866025          5.000000e-01
    1 2020-12-15 18:00:00  1              1.000000         -2.449294e-16

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_dt import OrdinalDayOfMonth
    >>> X = ks.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = OrdinalDayOfMonth(columns=['A'])
    >>> obj.fit_transform(X)
                        A  B  A__month_of_year_cos  A__month_of_year_sin
    0 2020-01-01 23:00:00  0              0.866025          5.000000e-01
    1 2020-12-15 18:00:00  1              1.000000         -2.449294e-16

    >>> import pandas as pd
    >>> from gators.feature_generation_dt import OrdinalDayOfMonth
    >>> X = pd.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = OrdinalDayOfMonth(columns=['A'])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[Timestamp('2020-01-01 23:00:00'), 0, 0.8660254037844387,
            0.49999999999999994],
        [Timestamp('2020-12-15 18:00:00'), 1, 1.0,
            -2.4492935982947064e-16]], dtype=object)

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_dt import OrdinalDayOfMonth
    >>> X = ks.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = OrdinalDayOfMonth(columns=['A'])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[Timestamp('2020-01-01 23:00:00'), 0, 0.8660254037844387,
            0.49999999999999994],
        [Timestamp('2020-12-15 18:00:00'), 1, 1.0,
            -2.4492935982947064e-16]], dtype=object)
    """

    def __init__(self, columns: List[str]):
        if not isinstance(columns, list):
            raise TypeError('`columns` should be a list.')
        if not columns:
            raise ValueError('`columns` should not be empty.')
        column_names = [f'{c}__day_of_month' for c in columns]
        column_mapping = {
            name: [col] for name, col in zip(column_names, columns)}
        _BaseDatetimeFeatures.__init__(
            self, columns, column_names, column_mapping)

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        self.check_dataframe(X)
        days_str = [str(float(i)) for i in range(1, 32)] + ['nan']
        days_str_new = [f'D{h}' for h in range(1, 32)] + [None]
        day_mapping = dict(zip(days_str, days_str_new))
        columns = [f'{c}__day_of_month' for c in self.columns]
        X_datetime = X[self.columns].apply(
            lambda x: x.dt.day.astype(np.float64).astype(str)).replace(day_mapping)
        X_datetime.columns = columns
        self.column_names = columns
        return X.join(X_datetime)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the array X.

        Parameters
        ----------
        X : np.ndarray
            Input array.

        Returns
        -------
            np.ndarray: Dataset with the Tree features.
        """
        self.check_array(X)
        n_new_cols = len(self.columns)
        X_new = self.create_X_new(X, n_new_cols)
        days_of_month = np.nan * np.empty((X.shape[0], n_new_cols))
        mask = X[:, self.idx_columns] == X[:, self.idx_columns]
        X_datetime = X[:, self.idx_columns][mask].astype('datetime64[ns]')
        days = X_datetime.astype('datetime64[D]')
        months = X_datetime.astype('datetime64[M]')
        days_of_month[mask] = (days - months + 1).astype(int)
        X_new[:, -n_new_cols:] = \
            cython_feature_gen_dt.ordinal_day_of_month(
                days_of_month
        )
        return X_new
