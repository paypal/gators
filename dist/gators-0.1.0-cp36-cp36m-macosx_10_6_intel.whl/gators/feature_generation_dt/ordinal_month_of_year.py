# Licence Apache-2.0
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ._base_datetime_features import _BaseDatetimeFeatures
import cython_feature_gen_dt


class OrdinalMonthOfYear(_BaseDatetimeFeatures):
    """Ordinal Datetime Transformer.

    Parameters
    ----------
    columns : List[str]
        List of columns.

    Examples
    ---------

    >>> import pandas as pd
    >>> from gators.feature_generation_dt import OrdinalMonthOfYear
    >>> X = pd.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = OrdinalMonthOfYear(columns=['A'])
    >>> obj.fit_transform(X)
                        A  B A__month_of_year
    0 2020-01-01 23:00:00  0          January
    1 2020-12-15 18:00:00  1         December

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_dt import OrdinalMonthOfYear
    >>> X = ks.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = OrdinalMonthOfYear(columns=['A'])
    >>> obj.fit_transform(X)
                        A  B A__month_of_year
    0 2020-01-01 23:00:00  0          January
    1 2020-12-15 18:00:00  1         December
    >>> import pandas as pd
    >>> from gators.feature_generation_dt import OrdinalMonthOfYear
    >>> X = pd.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = OrdinalMonthOfYear(columns=['A'])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[Timestamp('2020-01-01 23:00:00'), 0, 'January'],
        [Timestamp('2020-12-15 18:00:00'), 1, 'December']], dtype=object)

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_dt import OrdinalMonthOfYear
    >>> X = ks.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = OrdinalMonthOfYear(columns=['A'])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[Timestamp('2020-01-01 23:00:00'), 0, 'January'],
        [Timestamp('2020-12-15 18:00:00'), 1, 'December']], dtype=object)
    """

    def __init__(self, columns: List[str]):
        if not isinstance(columns, list):
            raise TypeError('`columns` should be a list.')
        if not columns:
            raise ValueError('`columns` should not be empty.')
        column_names = [f'{c}__month_of_year' for c in columns]
        column_mapping = {
            name: [col] for name, col in zip(column_names, columns)}
        _BaseDatetimeFeatures.__init__(
            self, columns, column_names, column_mapping)

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        self.check_dataframe(X)
        columns = [
            f'{c}__month_of_year' for c in self.columns]
        nums_month_of_year = [str(float(m))
                              for m in np.arange(1, 13)] + ['nan']
        names_month_of_year = [
            'January',
            'February',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December',
            None
        ]
        month_of_year_mapping = dict(
            zip(nums_month_of_year, names_month_of_year))
        X_datetime = X[self.columns].apply(
            lambda x:
                x.dt.month.astype(np.float64).astype(str)
        ).replace(month_of_year_mapping)
        X_datetime.columns = columns
        self.column_names = columns
        return X.join(X_datetime)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the array X.

        Parameters
        ----------
        X : np.ndarray
            Input array.

        Returns
        -------
            np.ndarray: Dataset with the Tree features.
        """
        self.check_array(X)
        n_new_cols = len(self.columns)
        X_new = self.create_X_new(X, n_new_cols)
        X_datetime = X[:, self.idx_columns]
        mask = X_datetime == X_datetime
        X_datetime[~ mask] = 0
        month_of_year = \
            X_datetime.astype('datetime64[M]').astype(int) % 12
        X_new[:, -n_new_cols:] = \
            cython_feature_gen_dt.ordinal_month_of_year(
                month_of_year
        )
        X_new[:, -n_new_cols:][~ mask] = None
        return X_new
