# Licence Apache-2.0
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ._base_datetime_features import _BaseDatetimeFeatures
import cython_feature_gen_dt


class OrdinalDayOfWeek(_BaseDatetimeFeatures):
    """Ordinal Day Of week Transformer.

    Parameters
    ----------
    columns : List[str]
        List of columns.

    Examples
    ---------

    >>> import pandas as pd
    >>> from gators.feature_generation_dt import OrdinalDayOfWeek
    >>> X = pd.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = OrdinalDayOfWeek(columns=['A'])
    >>> obj.fit_transform(X)
                        A  B A__day_of_week
    0 2020-01-01 23:00:00  0      Wednesday
    1 2020-12-15 18:00:00  1        Tuesday

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_dt import OrdinalDayOfWeek
    >>> X = ks.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = OrdinalDayOfWeek(columns=['A'])
    >>> obj.fit_transform(X)
                        A  B A__day_of_week
    0 2020-01-01 23:00:00  0      Wednesday
    1 2020-12-15 18:00:00  1        Tuesday
    >>> import pandas as pd
    >>> from gators.feature_generation_dt import OrdinalDayOfWeek
    >>> X = pd.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = OrdinalDayOfWeek(columns=['A'])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[Timestamp('2020-01-01 23:00:00'), 0, 'Wednesday'],
        [Timestamp('2020-12-15 18:00:00'), 1, 'Tuesday']], dtype=object)

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_dt import OrdinalDayOfWeek
    >>> X = ks.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = OrdinalDayOfWeek(columns=['A'])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[Timestamp('2020-01-01 23:00:00'), 0, 'Wednesday'],
        [Timestamp('2020-12-15 18:00:00'), 1, 'Tuesday']], dtype=object)
    """

    def __init__(self, columns: List[str]):
        if not isinstance(columns, list):
            raise TypeError('`columns` should be a list.')
        if not columns:
            raise ValueError('`columns` should not be empty.')
        column_names = [f'{c}__day_of_week' for c in columns]
        column_mapping = {
            name: [col] for name, col in zip(column_names, columns)}
        _BaseDatetimeFeatures.__init__(
            self, columns, column_names, column_mapping)

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
        Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.
        """
        self.check_dataframe(X)
        columns = [f'{c}__day_of_week' for c in self.columns]
        nums_day_of_week = np.array([
            '0.0', '1.0', '2.0', '3.0', '4.0', '5.0', '6.0', 'nan'
        ])
        names_day_of_week = [
            'Monday',
            'Tuesday',
            'Wednesday',
            'Thursday',
            'Friday',
            'Saturday',
            'Sunday',
            None
        ]
        days_of_week_mapping = dict(
            zip(nums_day_of_week, names_day_of_week))

        X_datetime = X[self.columns].apply(
            lambda x: x.dt.dayofweek.astype(np.float64).astype(str)).replace(
                days_of_week_mapping)

        X_datetime.columns = columns
        self.column_names = columns
        return X.join(X_datetime)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the array X.

        Parameters
        ----------
        X : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray:
            Transformed array.
        """
        self.check_array(X)
        n_new_cols = len(self.columns)
        X_new = self.create_X_new(X, n_new_cols)
        X_datetime = X[:, self.idx_columns]
        mask = X_datetime == X_datetime
        X_datetime[~mask] = 0
        X_new[:, -n_new_cols:] = \
            cython_feature_gen_dt.ordinal_day_of_week(
                X_datetime.astype('datetime64[h]').astype(int)
        )
        X_new[:, -n_new_cols:][~ mask] = None
        return X_new
