# Licence Apache-2.0
from typing import List, Dict, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ..transformer.transformer import Transformer


class _BaseDatetimeFeatures(Transformer):
    """Cyclic Datetime Transformer.

    Useful links:
    * https://stackoverflow.com/questions/13648774/get-year-month-or-day-from-numpy-datetime64
    * https://stackoverflow.com/questions/52398383/finding-day-of-the-week-for-a-datetime64


    Parameters
    ----------
    columns : List[str]
        List of columns.
    column_names : List[str]
        List of column names.
    column_mapping: Dict[str, List[str]]
        Mapping between generated features and base features.
    """

    def __init__(self, columns: List[str], column_names: List[str],
                 column_mapping: Dict[str, str]):
        Transformer.__init__(self)
        self.columns = columns
        self.column_names = column_names
        self.column_mapping = column_names
        self.idx_columns: np.ndarray = np.array([])
        self.n_columns = len(self.columns)

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> '_BaseDatetimeFeatures':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X : pd.DataFrame
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None.
            Target values. 

        Returns
        -------
        _BaseDatetimeFeatures
            Instance of itself.
        """
        self.check_dataframe(X)
        X_datetime_dtype = X[self.columns].to_numpy().dtype
        if not np.issubdtype(X_datetime_dtype, np.datetime64):
            raise TypeError(
                """            
                Datetime columns should be of subtype np.datetime64.
              """)
        self.idx_columns = util.get_idx_columns_in_selected_columns(
            columns=X.columns,
            selected_columns=self.columns,
        )
        return self

    @staticmethod
    def create_X_new(X: Union[pd.Series, ks.Series], n_new_cols: int
                     ) -> np.ndarray:
        """Create a new numpy array containing the input array 
            and `n_new_cols` new columns.

        Parameters
        ----------
        X : np.ndarray: 
            Numpy array
        n_new_cols : int
            Number of new columns to add.

        Returns
        -------
        np.ndarray: 
            New numpy array.
        """
        n_rows = X.shape[0]
        n_cols = X.shape[1]
        X_new = np.empty(
            (n_rows, n_cols + n_new_cols), dtype=object)
        X_new[:, :n_cols] = X
        return X_new
