# Licence Apache-2.0
from typing import List, Union
from math import pi
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
import cython_feature_gen_dt
from ._base_datetime_features import _BaseDatetimeFeatures


PREFACTOR = 2 * pi / 11.


class CyclicMonthOfYear(_BaseDatetimeFeatures):
    """Cyclic Datetime Transformer.

    Parameters
    ----------
    columns : List[str]
        List of columns.

    Examples
    ---------
    >>> import pandas as pd
    >>> from gators.feature_generation_dt import CyclicMonthOfYear
    >>> X = pd.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = CyclicMonthOfYear(columns=['A'])
    >>> obj.fit_transform(X)
                        A  B  A__month_of_year_cos  A__month_of_year_sin
    0 2020-01-01 23:00:00  0              0.866025          5.000000e-01
    1 2020-12-15 18:00:00  1              1.000000         -2.449294e-16

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_dt import CyclicMonthOfYear
    >>> X = ks.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = CyclicMonthOfYear(columns=['A'])
    >>> obj.fit_transform(X)
                        A  B  A__month_of_year_cos  A__month_of_year_sin
    0 2020-01-01 23:00:00  0              0.866025          5.000000e-01
    1 2020-12-15 18:00:00  1              1.000000         -2.449294e-16

    >>> import pandas as pd
    >>> from gators.feature_generation_dt import CyclicMonthOfYear
    >>> X = ks.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = CyclicMonthOfYear(columns=['A'])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[Timestamp('2020-01-01 23:00:00'), 0, 0.8660254037844387,
            0.49999999999999994],
        [Timestamp('2020-12-15 18:00:00'), 1, 1.0,
            -2.4492935982947064e-16]], dtype=object)

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_dt import CyclicMonthOfYear
    >>> X = pd.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = CyclicMonthOfYear(columns=['A'])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[Timestamp('2020-01-01 23:00:00'), 0, 0.8660254037844387,
            0.49999999999999994],
        [Timestamp('2020-12-15 18:00:00'), 1, 1.0,
            -2.4492935982947064e-16]], dtype=object)
    """

    def __init__(self, columns: List[str]):
        if not isinstance(columns, list):
            raise TypeError('`columns` should be a list.')
        if not columns:
            raise ValueError('`columns` should not be empty.')
        column_names = [f'{c}__month_of_year_cos' for c in columns]
        column_names += [f'{c}__month_of_year_sin' for c in columns]
        column_mapping = {
            name: [col] for name, col in zip(column_names, columns + columns)}
        _BaseDatetimeFeatures.__init__(
            self, columns, column_names, column_mapping)

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        self.check_dataframe(X)
        X_datetime = self.compute_cyclic_month_of_year(
            X[self.columns])
        self.column_names = list(X_datetime.columns)
        return X.join(X_datetime)

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        X_datetime = X[:, self.idx_columns]
        mask = X_datetime != X_datetime
        X_datetime[mask] = 0
        month_of_year = X_datetime.astype('datetime64[M]').astype(int) % 12
        n_rows, n_cols = X_datetime.shape
        X_new = np.empty((n_rows, X.shape[1] + 2 * n_cols), object)
        X_new[:, :-2 * n_cols] = X
        X_new[:, -2 * n_cols: -n_cols] = np.cos(PREFACTOR * month_of_year)
        X_new[:, -2 * n_cols: -n_cols][mask] = np.nan
        X_new[:, -n_cols:] = np.sin(PREFACTOR * month_of_year)
        X_new[:, -n_cols:][mask] = np.nan
        return X_new

    @ staticmethod
    def compute_cyclic_month_of_year(
            X_datetime: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Compute the cyclic hours of the day features.

        Parameters
        ----------
       X_datetime : Union[pd.DataFrame, ks.DataFrame])
                Dataframe of datetime columns.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Dataframe of cyclic hours of the day features.
        """
        columns = list(X_datetime.columns)
        X_cos = X_datetime.apply(
            lambda x: np.cos(PREFACTOR * (x.dt.month.astype(np.float64) - 1)))
        X_cos.columns = [
            f'{c}__month_of_year_cos' for c in columns]
        X_sin = X_datetime.apply(
            lambda x: np.sin(PREFACTOR * (x.dt.month.astype(np.float64)-1)))
        X_sin.columns = [
            f'{c}__month_of_year_sin' for c in columns]
        X_datetime = X_cos.join(X_sin)
        return X_datetime
