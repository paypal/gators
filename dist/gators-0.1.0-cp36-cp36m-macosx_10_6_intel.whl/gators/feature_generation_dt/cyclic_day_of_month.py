# Licence Apache-2.0
from typing import List, Union
from math import pi
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ._base_datetime_features import _BaseDatetimeFeatures
import cython_feature_gen_dt

TWO_PI = 2 * pi


class CyclicDayOfMonth(_BaseDatetimeFeatures):
    """Cyclic Datetime Transformer.

    Parameters
    ----------
    columns: List[str]
        List of columns.

    Examples
    ---------

    >>> import pandas as pd
    >>> from gators.feature_generation_dt import CyclicDayOfMonth
    >>> X = pd.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = CyclicDayOfMonth(columns=['A'])
    >>> obj.fit_transform(X)
                        A  B  A__day_of_month_cos  A__day_of_month_sin
    0 2020-01-01 23:00:00  0             0.979530             0.201299
    1 2020-12-15 18:00:00  1            -0.994869             0.101168

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_dt import CyclicDayOfMonth
    >>> X = ks.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = CyclicDayOfMonth(columns=['A'])
    >>> obj.fit_transform(X)
                        A  B  A__day_of_month_cos  A__day_of_month_sin
    0 2020-01-01 23:00:00  0             0.979530             0.201299
    1 2020-12-15 18:00:00  1            -0.994869             0.101168

    >>> import pandas as pd
    >>> from gators.feature_generation_dt import CyclicDayOfMonth
    >>> X = pd.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = CyclicDayOfMonth(columns=['A'])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[Timestamp('2020-01-01 23:00:00'), 0, 0.9795299412524945, 0.20129852008866006],
           [Timestamp('2020-12-15 18:00:00'), 1, -0.9948693233918952, 0.10116832198743228]], dtype=object)

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_dt import CyclicDayOfMonth
    >>> X = ks.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = CyclicDayOfMonth(columns=['A'])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[Timestamp('2020-01-01 23:00:00'), 0, 0.9795299412524945, 0.20129852008866006],
           [Timestamp('2020-12-15 18:00:00'), 1, -0.9948693233918952, 0.10116832198743228]], dtype=object)
    """

    def __init__(self, columns: List[str]):
        if not isinstance(columns, list):
            raise TypeError('`columns` should be a list.')
        if not columns:
            raise ValueError('`columns` should not be empty.')
        column_names = [f'{c}__day_of_month_cos' for c in columns]
        column_names += [f'{c}__day_of_month_sin' for c in columns]
        column_mapping = {
            name: [col] for name, col in zip(column_names, columns + columns)}
        _BaseDatetimeFeatures.__init__(
            self, columns, column_names, column_mapping)

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X(pd.DataFrame): 
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        self.check_dataframe(X)
        X_datetime = self.compute_cyclic_day_of_month(
            X[self.columns])
        self.column_names = list(X_datetime.columns)
        X = X.join(X_datetime)

        return X

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        X_datetime = X[:, self.idx_columns]
        mask = X_datetime != X_datetime
        X_datetime[mask] = 0
        day_of_month = (
            X_datetime.astype('datetime64[D]')
            - X_datetime.astype('datetime64[M]') + 1).astype(int) - 1
        years = X_datetime.astype('datetime64[Y]').astype(int) + 1970
        months = X_datetime.astype('datetime64[M]').astype(int) % 12 + 1
        n_days_in_month = cython_feature_gen_dt.get_num_days_in_month(
            years, months)
        prefactors = TWO_PI / (n_days_in_month - 1)
        n_rows, n_cols = X_datetime.shape
        X_new = np.empty((n_rows, X.shape[1] + 2 * n_cols), object)
        X_new[:, :-2 * n_cols] = X
        X_new[:, -2 * n_cols: -n_cols] = np.cos(prefactors * day_of_month)
        X_new[:, -2 * n_cols: -n_cols][mask] = np.nan
        X_new[:, -n_cols:] = np.sin(prefactors * day_of_month)
        X_new[:, - n_cols:][mask] = np.nan
        return X_new

    @ staticmethod
    def compute_cyclic_day_of_month(
            X_datetime: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Compute the cyclic day of the month features.

        Parameters
        ----------
        X_datetime : Union[pd.DataFrame, ks.DataFrame]
            Dataframe of datetime columns.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Dataframe of cyclic day of the month features.
        """
        def f_cos(x):
            day_of_month = x.dt.day - 1
            n_days_in_month = x.dt.daysinmonth - 1
            prefactors = 2 * np.pi / n_days_in_month
            return np.cos(prefactors * day_of_month)

        def f_sin(x):
            day_of_month = x.dt.day - 1
            n_days_in_month = x.dt.daysinmonth - 1
            prefactors = 2 * np.pi / n_days_in_month
            return np.sin(prefactors * day_of_month)

        columns = list(X_datetime.columns)
        X_cos = X_datetime.apply(f_cos)
        X_cos.columns = [
            f'{c}__day_of_month_cos' for c in columns]
        X_sin = X_datetime.apply(f_sin)
        X_sin.columns = [
            f'{c}__day_of_month_sin' for c in columns]
        return X_cos.join(X_sin)
