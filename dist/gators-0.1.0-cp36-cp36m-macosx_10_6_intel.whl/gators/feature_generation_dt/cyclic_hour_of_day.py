# Licence Apache-2.0
from typing import List, Union
from math import pi
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ..transformer import transformer_util
from ._base_datetime_features import _BaseDatetimeFeatures
import cython_feature_gen_dt


PREFACTOR = 2 * pi / 23.


class CyclicHourOfDay(_BaseDatetimeFeatures):
    """Cyclic Datetime Transformer.

    Parameters
    ----------
    columns : List[str]
        List of columns.

    Examples
    ---------

    >>> import pandas as pd
    >>> from gators.feature_generation_dt import CyclicHourOfDay
    >>> X = pd.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = CyclicHourOfDay(columns=['A'])
    >>> obj.fit_transform(X)
                        A  B  A__hour_of_day_cos  A__hour_of_day_sin
    0 2020-01-01 23:00:00  0            1.000000       -2.449294e-16
    1 2020-12-15 18:00:00  1            0.203456       -9.790841e-01

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_dt import CyclicHourOfDay
    >>> X = ks.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = CyclicHourOfDay(columns=['A'])
    >>> obj.fit_transform(X)
                        A  B  A__hour_of_day_cos  A__hour_of_day_sin
    0 2020-01-01 23:00:00  0            1.000000       -2.449294e-16
    1 2020-12-15 18:00:00  1            0.203456       -9.790841e-01

    >>> import pandas as pd
    >>> from gators.feature_generation_dt import CyclicHourOfDay
    >>> X = pd.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = CyclicHourOfDay(columns=['A'])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[Timestamp('2020-01-01 23:00:00'), 0, 1.0,
            -2.4492935982947064e-16],
        [Timestamp('2020-12-15 18:00:00'), 1, 0.20345601305263328,
            -0.979084087682323]], dtype=object)

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation_dt import CyclicHourOfDay
    >>> X = ks.DataFrame({'A': ['2020-01-01T23', '2020-12-15T18'], 'B': [0, 1]})
    >>> X['A'] = X['A'].astype('datetime64[ns]')
    >>> obj = CyclicHourOfDay(columns=['A'])
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[Timestamp('2020-01-01 23:00:00'), 0, 1.0,
            -2.4492935982947064e-16],
        [Timestamp('2020-12-15 18:00:00'), 1, 0.20345601305263328,
            -0.979084087682323]], dtype=object)
    """

    def __init__(self, columns: List[str]):
        if not isinstance(columns, list):
            raise TypeError('`columns` should be a list.')
        if not columns:
            raise ValueError('`columns` should not be empty.')
        column_names = [f'{c}__hour_of_day_cos' for c in columns]
        column_names += [f'{c}__hour_of_day_sin' for c in columns]
        column_mapping = {
            name: [col] for name, col in zip(column_names, columns + columns)}
        _BaseDatetimeFeatures.__init__(
            self, columns, column_names, column_mapping)

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        self.check_dataframe(X)
        X_datetime = self.compute_cyclic_hour_of_day(
            X[self.columns])
        self.column_names = list(X_datetime.columns)
        X = X.join(X_datetime)

        return X

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        X_datetime = X[:, self.idx_columns]
        mask = X_datetime != X_datetime
        X_datetime[mask] = 0
        hours = X_datetime.astype('datetime64[h]').astype(int) % 24
        n_rows, n_cols = X_datetime.shape
        X_new = np.empty((n_rows, X.shape[1] + 2 * n_cols), object)
        X_new[:, :-2 * n_cols] = X
        X_new[:, -2 * n_cols: -n_cols] = np.cos(PREFACTOR * hours)
        X_new[:, -2 * n_cols: -n_cols][mask] = np.nan
        X_new[:, -n_cols:] = np.sin(PREFACTOR * hours)
        X_new[:, -n_cols:][mask] = np.nan
        return X_new

    @ staticmethod
    def compute_cyclic_hour_of_day(
            X_datetime: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Compute the cyclic hours of the day features.

        Parameters
        ----------
        X_datetime : Union[pd.DataFrame, ks.DataFrame])
            Dataframe of datetime columns.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Dataframe of cyclic hours of the day features.
        """
        columns = list(X_datetime.columns)
        X_cos = X_datetime.apply(
            lambda x: np.cos(PREFACTOR * x.dt.hour))
        X_cos.columns = [
            f'{c}__hour_of_day_cos' for c in columns]
        X_sin = X_datetime.apply(
            lambda x: np.sin(PREFACTOR * x.dt.hour))
        X_sin.columns = [
            f'{c}__hour_of_day_sin' for c in columns]
        X_datetime = X_cos.join(X_sin)
        return X_datetime
