# License: Apache-2.0
from typing import Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from cython_imputer import float_imputer
from cython_imputer import int_imputer
from cython_imputer import float_imputer_object
from ._base_imputer import _BaseImputer


class IntImputer(_BaseImputer):
    """Int imputer Transformer.

    Parameters
    ----------
    strategy : str
        Imputation strategy. 
            Supported imputation strategies are:

                - 'constant'
                - 'most_frequent'
                - 'mean'
                - 'median'

    value : str, default to None
        Imputation value used for `strategy=constant`.

    Examples
    ---------

    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.imputers import IntImputer
    >>> X = pd.DataFrame({'A': [1, 2, np.nan], 'B': ['z', 'a', 'a']})
    >>> obj = IntImputer(strategy='constant', value=-999)
    >>> obj.fit_transform(X)
        A     B
    0  1.0    z
    1  2.0    a
    2  -999.  a

    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.imputers import IntImputer
    >>> X = ks.DataFrame({'A': [1, 2, np.nan], 'B': ['z', 'a', 'a']})
    >>> obj = IntImputer(strategy='most_frequent', value=-999)
    >>> obj.fit_transform(X)
        A     B
    0  1.0    z
    1  2.0    a
    2  -999.  a

    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.imputers import IntImputer
    >>> X = pd.DataFrame({'A': [1, 2, np.nan], 'B': ['z', 'a', 'a']})
    >>> obj = IntImputer(strategy='most_frequent', value=-999)
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1.0, 'z'],
           [2.0, 'a'],
           [-999., 'a']], dtype=object)

    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.imputers import IntImputer
    >>> X = ks.DataFrame({'A': [1, 2, np.nan], 'B': ['z', 'a', 'a']})
    >>> obj = IntImputer(strategy='most_frequent', value=-999)
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1.0, 'z'],
           [2.0, 'a'],
           [-999., 'a']], dtype=object)

    """

    def __init__(
            self, strategy: str,
            value: int = None):
        _BaseImputer.__init__(self, strategy, value)
        if strategy == 'constant' and not isinstance(value, int):
            raise TypeError(
                '''`value` should be a integer
                for the IntImputer class''')

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'IntImputer':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.
        y None 
            None.

        Returns
        -------
            Imputer: Instance of itself.
        """
        self.check_dataframe(X)
        self.columns = util.get_int_only_columns(X=X)
        self.idx_columns = np.array(
            util.get_idx_int_only_columns(X=X))
        self.statistics = self.compute_statistics(
            X=X,
            columns=self.columns,
            strategy=self.strategy,
            value=self.value,
        )
        self.statistics_values = np.array(
            list(self.statistics.values())).astype(np.float64)
        return self

    def transform_numpy(self, X: Union[pd.Series, ks.Series], y=None):
        """Transform the numpy ndarray X.

        Parameters
        ----------
        X (np.ndarray): Input ndarray.

        Returns
        -------
            np.ndarray: Imputed ndarray.
        """
        self.check_array(X)
        X_dtype = X.dtype
        if X_dtype == object:
            return float_imputer_object(
                X,
                self.statistics_values.astype(object),
                self.idx_columns)
        elif X_dtype == int:
            return X
        return float_imputer(
            X,
            self.statistics_values,
            self.idx_columns)
