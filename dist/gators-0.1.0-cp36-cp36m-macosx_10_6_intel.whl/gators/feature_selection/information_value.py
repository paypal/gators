# License: Apache-2.0
from typing import List, Union
from math import log
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..binning.bin_numerics import BinNumerics
from ..util import util
from ._base_feature_selector import _BaseFeatureSelector


class InformationValue(_BaseFeatureSelector):
    """Information Value Transformer.

    Parameters
    ----------
    k : int
        Number of features to keep.
    n_bins : int
        Number of bins used for BinNumerics Transformer.

    Examples
    ---------

    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.feature_selection import InformationValue
    >>> X = pd.DataFrame({'A': [0., 0., 0.1], 'B': [1., 2., 3.], 'C': ['a', 'b', 'b']})
    >>> y = pd.Series([0, 1, 1])
    >>> obj = InformationValue(k=2)
    >>> obj.fit_transform(X, y)
        B  C
    0  1.0  a
    1  2.0  b
    2  3.0  b


    """

    def __init__(self, k: int, n_bins):
        if not isinstance(k, int):
            raise TypeError('`k` should be an int.')
        if not isinstance(n_bins, int):
            raise TypeError('`n_bins` should be an int.')
        _BaseFeatureSelector.__init__(self)
        self.k = k
        self.n_bins = n_bins

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'InformationValue':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None. 
            labels.

        Returns
        -------
            InformationValue: Instance of itself.
        """
        self.check_dataframe(X)
        self.check_y(X, y)
        columns = X.columns
        self.feature_importances_ = self.compute_information_value(
            X, y, self.n_bins
        )
        self.feature_importances_.sort_values(ascending=False, inplace=True)
        self.feature_importances_.index = [
            c.split('__bin')[0] for c in self.feature_importances_.index
        ]
        if self.k == -1:
            mask = self.feature_importances_ != 0
            self.feature_importances_ = self.feature_importances_[mask]
        else:
            self.feature_importances_ = self.feature_importances_[:self.k]
        self.selected_columns = list(self.feature_importances_.index)
        self.columns_to_drop = [
            c for c in columns if c not in self.selected_columns
        ]
        self.idx_selected_columns = util.get_idx_columns_in_selected_columns(
            X.columns, self.selected_columns)
        return self

    @staticmethod
    def compute_information_value(
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series],
            n_bins: int) -> pd.Series:
        """Compute information value.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame])
            Input dataframe.
        object_columns : List[str]
            List of columns.

        Returns
        -------
        pd.Series
            Information value.
        """
        binning = BinNumerics(n_bins=n_bins)
        X = binning.fit_transform(X)
        X = X.drop(binning.columns, axis=1)
        binned_columns = [c for c in X if c.endswith('__bin')]
        X[binned_columns] = X[binned_columns].astype(str)

        def compute_iv_pd(x, y):
            tab = pd.crosstab(x, y, normalize='columns')
            if tab.shape[1] == 1:
                return 0
            with np.errstate(divide='ignore'):
                woe = pd.Series(np.log(tab[1] / tab[0]))
            woe[(woe == np.inf) | (woe == -np.inf)] = 0.
            return np.sum(woe.to_numpy() * (tab[1].to_numpy() - tab[0].to_numpy()))

        def compute_iv_ks(x, y):
            name = x.name
            y_name = y.name
            dummy = ks.DataFrame(x).join(y)
            tab = dummy.to_spark().crosstab(name, y_name).toPandas()
            tab = tab.set_index(f'{name}_{y_name}')
            tab.columns = [str(int(c)) for c in tab.columns]
            if tab.shape[1] == 1:
                return 0.
            tab = tab / tab.sum(0)
            with np.errstate(divide='ignore'):
                woe = np.log(tab['1'] / tab['0'])
            woe[(woe == np.inf) | (woe == -np.inf)] = 0.
            return np.sum(woe.to_numpy() * (tab['1'].to_numpy() - tab['0'].to_numpy()))

        if isinstance(X, pd.DataFrame):
            information_value = X.apply(compute_iv_pd, args=(y, ))
        else:
            information_value = X.apply(compute_iv_ks, args=(y, ))
            information_value = information_value.to_pandas()
        return information_value.sort_values(ascending=False).dropna()
