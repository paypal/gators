# License: Apache-2.0
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ..transformer.transformer import Transformer
from ._base_feature_selector import _BaseFeatureSelector
from pyspark.ml.feature import VectorAssembler


# NOT WORKING KOALAS/SPARK
class SelectFromModel(_BaseFeatureSelector):
    """Select From Model Transformer.

    Parameters
    ----------
    columns_to_drop : List[str]
        List of columns to be removed.
    selected_columns : List[str]
        List of selected columns.
    feature_importance : pd.Series
        Feature importance.
    model : model
        Machine learning model.
    k : int
        Number of features to keep.

    Examples
    ---------
    >>> import databricks.koalas as ks
    >>> import numpy as np  
    >>> from pyspark.ml.classification import RandomForestClassifier as RFCSpark
    >>> from gators.feature_selection import SelectFromModel
    >>> X = ks.DataFrame({'A': [0., 0., 1., 1.], 'B': [0., 1., 0., 1.], 'C':[1., 0., 1., 0.]})
    >>> y = pd.Series([0, 0, 0, 1])
    >>> rfs = RFCSpark(numTrees=1, maxDepth=1, seed=0)
    >>> rf_selector = SelectFromModel(model=model, k=10)
    >>> obj = SelectFromModel(model=rfs, k=2)
    >>> obj.fit_transform(X, y)
    """

    def __init__(self, model: 'model', k: int):
        if not isinstance(k, int):
            raise TypeError('`k` should be an int.')
        if not hasattr(model, 'fit'):
            raise TypeError(
                '`model` should have the attribute `fit`.'
            )
        _BaseFeatureSelector.__init__(self)
        self.model = model
        self.k = k

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'SelectFromModel':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None. 
            labels.

        Returns
        -------
            SelectFromModel: Instance of itself.
        """
        self.check_dataframe(X)
        self.check_y(X, y)
        columns = list(X.columns)
        if isinstance(X, pd.DataFrame):
            self.feature_importances_ = self._calculate_feature_importances_pandas(
                model=self.model, X=X, y=y, columns=columns)
        else:
            self.feature_importances_ = self._calculate_feature_importances_koalas(
                model=self.model, X=X, y=y, columns=columns)
        mask = self.feature_importances_ != 0
        self.feature_importances_ = self.feature_importances_[mask]
        self.feature_importances_.sort_values(ascending=False, inplace=True)
        self.selected_columns = list(self.feature_importances_.index[:self.k])
        self.columns_to_drop = [
            c for c in columns if c not in self.selected_columns]
        self.idx_selected_columns = util.get_idx_columns_in_selected_columns(
            X.columns, self.selected_columns)
        return self

    @staticmethod
    def _calculate_feature_importances_pandas(
            model: object, X: pd.DataFrame,
            y: Union[pd.Series, ks.Series], columns: list) -> pd.Series:
        model.fit(X.to_numpy(), y)
        feature_importances_ = pd.Series(
            model.feature_importances_,
            index=columns,
        )
        return feature_importances_

    @staticmethod
    def _calculate_feature_importances_koalas(
            model: object, X: ks.DataFrame,
            y: ks.Series, columns: list) -> pd.Series:
        spark_df = util.generate_spark_dataframe(X=X, y=y)
        trained_model = model.fit(spark_df)
        feature_importances_ = pd.Series(
            trained_model.featureImportances.toArray(),
            index=columns
        )
        return feature_importances_
