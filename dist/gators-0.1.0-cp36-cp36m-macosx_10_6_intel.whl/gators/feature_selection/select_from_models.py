# License: Apache-2.0
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
import pyspark.sql.dataframe as ps
from pyspark.ml.feature import VectorAssembler
from ..util import util
from ..transformer.transformer import Transformer
from ..scalers.minmax_scaler import MinMaxScaler
from ._base_feature_selector import _BaseFeatureSelector


class SelectFromModels(_BaseFeatureSelector):
    """From Models By Vote Transformer.

    Parameters
    ----------
    models : List[model]
        List of machine learning models.
    k : int
        Number of features to keep.
    """

    def __init__(self, models: List['model'], k: int):
        if not isinstance(models, list):
            raise TypeError('`models` should be a list.')
        if not isinstance(k, int):
            raise TypeError('`k` should be an int.')
        for model in models:
            if not hasattr(model, 'fit'):
                raise TypeError(
                    'All the elements of `models` should have the attribute `fit`.'
                )
        _BaseFeatureSelector.__init__(self)
        self.models = models
        self.k = k

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'SelectFromModels':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.
        y : Union[pd.Series, ks.Series], default to None. 
            labels.

        Returns
        -------
        SelectFromModels: Instance of itself.
        """
        self.check_dataframe(X)
        self.check_y(X, y)
        self.feature_importances_ = self.get_feature_importances_frame(
            X, self.models)
        if isinstance(X, ks.DataFrame):
            spark_df = util.generate_spark_dataframe(X=X, y=y)
        for col, model in zip(self.feature_importances_.columns, self.models):
            if isinstance(X, pd.DataFrame):
                model_feature_importances_ = self.get_feature_importances_pd(
                    model=model, X=X, y=y)
            else:
                model_feature_importances_ = self.get_feature_importances_sk(
                    model=model, spark_df=spark_df)
            self.feature_importances_[col] = model_feature_importances_
        self.feature_importances_ = self.clean_feature_importances_frame(
            self.feature_importances_)
        self.selected_columns = list(
            self.feature_importances_['count'].iloc[:self.k].index)
        self.columns_to_drop = [
            c for c in self.feature_importances_.index
            if c not in self.selected_columns
        ]
        self.idx_selected_columns = util.get_idx_columns_in_selected_columns(
            X.columns, self.selected_columns)
        return self

    @staticmethod
    def get_feature_importances_pd(
            model: object, X: pd.DataFrame, y: Union[pd.Series, ks.Series]):
        model.fit(X, y)
        feature_importances_ = model.feature_importances_
        return feature_importances_

    @staticmethod
    def get_feature_importances_sk(
            model: object, spark_df: ps.DataFrame):
        trained_model = model.fit(spark_df)
        feature_importances_ = trained_model.featureImportances.toArray()
        return feature_importances_

    @staticmethod
    def get_feature_importances_frame(X, models):
        index = np.array(list(X.columns))
        columns = []
        for i, model in enumerate(models):
            model_str = str(model)
            if 'catboost' in model_str:
                col = str(model).split('.')[-1].split(' ')[0]
            else:
                col = str(model).split('(')[0]
            columns.append(col + '_' + str(i))
        return pd.DataFrame(
            columns=columns, index=index, dtype=np.float64)

    @staticmethod
    def clean_feature_importances_frame(feature_importances):
        feature_importances = MinMaxScaler(
        ).fit_transform(feature_importances)
        feature_importances_sum = feature_importances.sum(1)
        feature_importances_count = (feature_importances != 0).sum(1)
        feature_importances['sum'] = feature_importances_sum
        feature_importances['count'] = feature_importances_count
        feature_importances.sort_values(
            by=['count', 'sum'], ascending=False, inplace=True)
        return feature_importances
