# License: Apache-2.0
from typing import List, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ..transformer.transformer import Transformer


class _BaseFeatureSelector(Transformer):
    """Feature Selector Transformer.

    Parameters
    ----------
        Transformer (Transformer): Abstract transformer.

    Attributes:
        columns_to_drop : List[str]
            List of columns to be removed.
        selected_columns : List[str]
            List of selected columns.
        feature_importance : pd.Series
        Feature importance.

    Examples
    ---------
    >>> import pandas as pd
    >>> from gators.feature_selection import CorrelationFilter
    >>> X = pd.DataFrame({'A': [0., 0., 0.1], 'B': [1., 2., 3.]})
    >>> obj = CorrelationFilter(max_corr=0.1)
    >>> obj.fit_transform(X)
        B
    0  1.0
    1  2.0
    2  3.0

    >>> import databricks.koalas as ks
    >>> from gators.feature_selection import CorrelationFilter
    >>> X = ks.DataFrame({'A': [0., 0., 0.1], 'B': [1., 2., 3.]})
    >>> obj = CorrelationFilter(max_corr=0.1)
    >>> obj.fit_transform(X)
        B
    0  1.0
    1  2.0
    2  3.0

    >>> import pandas as pd
    >>> from gators.feature_selection import CorrelationFilter
    >>> X = pd.DataFrame({'A': [0., 0., 0.1], 'B': [1., 2., 3.]})
    >>> obj = CorrelationFilter(max_corr=0.1)
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1.],
           [2.],
           [3.]])

    >>> import databricks.koalas as ks
    >>> from gators.feature_selection import CorrelationFilter
    >>> X = ks.DataFrame({'A': [0., 0., 0.1], 'B': [1., 2., 3.]})
    >>> obj = CorrelationFilter(max_corr=0.1)
    >>> _ = obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([[1.],
           [2.],
           [3.]])
    """

    def __init__(self):
        self.feature_importances_ = pd.Series([], dtype=np.float64)
        self.selected_columns: List[str] = []
        self.idx_selected_columns: List[str] = []
        self.columns_to_drop: List[str] = []

    def transform(
            self, X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.
        y : np.ndarray
            labels.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        self.check_dataframe(X)
        if len(self.columns_to_drop):
            X_new = X.drop(self.columns_to_drop, axis=1)
        else:
            X_new = X
        return X_new

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        self.idx_selected_columns.sort()
        return X[:, self.idx_selected_columns]
