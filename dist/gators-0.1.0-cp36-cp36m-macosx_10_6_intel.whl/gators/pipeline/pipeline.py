# License: Apache-2.0
from typing import List, Tuple, Union
import copy
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..transformer.transformer import Transformer
from ..transformer import transformer_util
from ..feature_selection._base_feature_selector import _BaseFeatureSelector
from . import pipeline_util


class Pipeline(Transformer):
    """Pipeline Transformer.

    Parameters
    ----------
    steps : List[Transformer]
        List of transformations.

    Examples
    ---------

    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.imputers import IntImputer
    >>> from gators.imputers import FloatImputer
    >>> from gators.imputers import ObjectImputer
    >>> from gators.pipeline import Pipeline
    >>> X = pd.DataFrame(
    ...     {'A': [0.1, 0.2, 0.3, np.nan], 'B': [1, 2, 2, np.nan], 'C': ['a', 'b', 'c', np.nan]})
    >>> steps = [
    ...     ObjectImputer(strategy='constant', value='MISSING'),
    ...     FloatImputer(strategy='median'),
    ...     IntImputer(strategy='most_frequent'),
    ... ]
    >>> obj = Pipeline(steps=steps)
    >>> obj.fit_transform(X)
        A    B        C
    0  0.1  1.0        a
    1  0.2  2.0        b
    2  0.3  2.0        c
    3  0.2  2.0  MISSING

    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.imputers import IntImputer
    >>> from gators.imputers import FloatImputer
    >>> from gators.imputers import ObjectImputer
    >>> from gators.pipeline import Pipeline
    >>> X = ks.DataFrame(
    ...     {'A': [0.1, 0.2, 0.3, np.nan], 'B': [1, 2, 2, np.nan], 'C': ['a', 'b', 'c', np.nan]})
    steps = [
            ObjectImputer(strategy='constant', value='MISSING'),
            FloatImputer(strategy='median'),
            IntImputer(strategy='most_frequent'),
    ]
    obj = Pipeline(steps=steps)
    obj.fit_transform(X)
    >>> steps = [
    ...     ObjectImputer(strategy='constant', value='MISSING'),
    ...     FloatImputer(strategy='median'),
    ...     IntImputer(strategy='most_frequent'),
    ... ]
    >>> obj = Pipeline(steps=steps)
    >>> obj.fit_transform(X)
        A    B        C
    0  0.1  1.0        a
    1  0.2  2.0        b
    2  0.3  2.0        c
    3  0.2  2.0  MISSING

    >>> import pandas as pd
    >>> import numpy as np
    >>> from gators.imputers import IntImputer
    >>> from gators.imputers import FloatImputer
    >>> from gators.imputers import ObjectImputer
    >>> from gators.pipeline import Pipeline
    >>> X = pd.DataFrame(
    ...     {'A': [0.1, 0.2, 0.3, np.nan], 'B': [1, 2, 2, np.nan], 'C': ['a', 'b', 'c', np.nan]})
    >>> steps = [
    ...     ObjectImputer(strategy='constant', value='MISSING'),
    ...     FloatImputer(strategy='median'),
    ...     IntImputer(strategy='most_frequent'),
    ... ]
    >>> obj = Pipeline(steps=steps)
    >>> _ = obj.fit(X)
    obj.transform_numpy(X.to_numpy())
    >>> obj.transform_numpy(X.to_numpy())
    array([[0.1, 1.0, 'a'],
           [0.2, 2.0, 'b'],
           [0.3, 2.0, 'c'],
           [0.2, 2.0, 'MISSING']], dtype=object)

    >>> import databricks.koalas as ks
    >>> import numpy as np
    >>> from gators.imputers import IntImputer
    >>> from gators.imputers import FloatImputer
    >>> from gators.imputers import ObjectImputer
    >>> from gators.pipeline import Pipeline
    >>> X = ks.DataFrame(
    ...     {'A': [0.1, 0.2, 0.3, np.nan], 'B': [1, 2, 2, np.nan], 'C': ['a', 'b', 'c', np.nan]})
    steps = [
            ObjectImputer(strategy='constant', value='MISSING'),
            FloatImputer(strategy='median'),
            IntImputer(strategy='most_frequent'),
    ]
    obj = Pipeline(steps=steps)
    _ = obj.fit(X)
    obj.transform_numpy(X.to_numpy())
    >>> steps = [
    ...     ObjectImputer(strategy='constant', value='MISSING'),
    ...     FloatImputer(strategy='median'),
    ...     IntImputer(strategy='most_frequent'),
    ... ]
    >>> obj = Pipeline(steps=steps)
    >>> _ = obj.fit(X)
    obj.transform_numpy(X.to_numpy())

    >>> obj.transform_numpy(X.to_numpy())
    array([[0.1, 1.0, 'a'],
           [0.2, 2.0, 'b'],
           [0.3, 2.0, 'c'],
           [0.2, 2.0, 'MISSING']], dtype=object)
    """

    def __init__(self, steps: List[Transformer]):
        if not isinstance(steps, list):
            raise TypeError('`steps` should be a list.')
        if not steps:
            raise TypeError('`steps` should be an empty list.')
        self.steps = steps
        self.is_model = pipeline_util.is_pipeline_with_model(steps)
        self.n_transformations = pipeline_util.get_num_transformations(
            self.steps)

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'Pipeline':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.
        y None 
            None.

        Returns
        -------
        Pipeline
            Instance of itself.
        """
        for step in self.steps[:self.n_transformations]:
            step = step.fit(X, y)
            X = step.transform(X)
        if self.is_model:
            _ = self.steps[-1].fit(X, y)
        return self

    def transform(
        self, X: Union[pd.DataFrame, ks.DataFrame]
    ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        self.check_dataframe(X)
        for step in self.steps[:self.n_transformations]:
            X = step.transform(X)
        return X

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        for step in self.steps[:self.n_transformations]:
            X = step.transform_numpy(X)
        return X

    def fit_transform(self,
                      X: Union[pd.DataFrame, ks.DataFrame],
                      y: Union[pd.Series, ks.Series] = None
                      ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Fit and transform the pandas dataframe.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed pandas dataframe.
        """
        n_steps = pipeline_util.get_num_transformations(self.steps)
        for step in self.steps[:n_steps]:
            step = step.fit(X, y)
            X = step.transform(X)
        return X

    def predict(self,
                X: Union[pd.DataFrame, ks.DataFrame],
                y: Union[pd.Series, ks.Series] = None) -> np.ndarray:
        """Predict on X, and predict.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        np.ndarray
            Model predictions.
        """
        for step in self.steps[:-1]:
            X = step.transform(X)
        return self.steps[-1].predict(X)

    def predict_proba(self,
                      X: Union[pd.DataFrame, ks.DataFrame],
                      y: np.array = None) -> np.ndarray:
        """Predict on X, and return the probability of success.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        np.ndarray
            Model probabilities of success.
        """
        for step in self.steps[:-1]:
            X = step.transform(X)
        return self.steps[-1].predict_proba(X)

    def predict_numpy(self,
                      X: np.ndarray,
                      y: Union[pd.Series, ks.Series] = None) -> np.ndarray:
        """Predict on X, and predict.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        np.ndarray
            Model predictions.
        """
        for step in self.steps[:-1]:
            X = step.transform_numpy(X)
        return self.steps[-1].predict(X)

    def predict_proba_numpy(self,
                            X: np.ndarray) -> np.ndarray:
        """Predict on X, and return the probability of success.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Model probabilities of success.
        """
        for step in self.steps[:-1]:
            X = step.transform_numpy(X)
        return self.steps[-1].predict_proba(X)

    def get_feature_importances(self) -> pd.Series:
        """Get the feature importances of the pipeline.

        Returns
        -------
        List[str] 
            List of columns.
        """
        feature_names = pipeline_util.get_final_feature_names(self.steps)
        last_transformation = self.steps[-1]
        feature_importances = last_transformation.feature_importances_
        feature_importances_series = pd.Series(
            feature_importances, index=feature_names)
        return feature_importances_series.sort_values(ascending=False)

    def get_prod_pipeline_and_colums(self) -> Tuple:
        """Return the cleaned pipeline and input columns.

        Returns
        -------
        Tuple
            Pipeline and input columns.
        """
        columns = self.steps[-1].selected_columns
        cleaned_steps = []
        base_columns = []
        used_columns = []
        unused_columns = []
        for step in self.steps:
            if isinstance(step, _BaseFeatureSelector):
                continue
            if not hasattr(step, 'is_object_used'):
                cleaned_steps.append(step)
                continue
            if step.is_object_used(columns):
                cleaned_steps.append(step)
                base_columns.extend(
                    transformer_util.get_base_column_names(columns, step.patterns))
                used_columns.extend(
                    transformer_util.get_used_column_names(columns, step.patterns))
                unused_columns.extend(
                    transformer_util.get_unused_column_names(columns, step.patterns))
                step.columns = [c for c in step.columns if c in base_columns]
        for step in self.steps:
            if step.__class__.__name__ == 'DropColumns':
                step.columns_to_drop = base_columns + unused_columns
        self.steps = cleaned_steps
        z = [c for c in columns if c not in used_columns]
        return self, z + base_columns

    @staticmethod
    def clean_steps(steps: List[Transformer], features: List[str]):
        base_columns = [f for f in features if '__'not in f]
        gen_columns = [f for f in features if '__' in f]
        used_columns = []
        clean_steps = []
        features_ = gen_columns
        for step in steps[::-1]:
            if hasattr(step, 'column_mapping'):
                is_used = False
                step.columns = []
                step.column_names = []
                step = copy.deepcopy(step)
                for c in features_:
                    if c in step.column_mapping.keys():
                        is_used = True
                        step.columns.extend(step.column_mapping[c])
                        step.column_names.append(c)
                        used_columns.extend(step.column_mapping[c])
                        features_.extend(
                            [c for c in step.column_mapping[c] if '__' in c])
                if is_used:
                    clean_steps.append(step)
            else:
                clean_steps.append(copy.deepcopy(step))
        used_columns = list(
            set(base_columns+[c for c in used_columns if '__' not in c]))
        return clean_steps[::-1], used_columns
