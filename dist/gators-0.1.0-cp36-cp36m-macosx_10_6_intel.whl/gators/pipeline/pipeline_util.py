# License: Apache-2.0
from typing import List, Dict, Union
import pandas as pd
import databricks.koalas as ks
from ..transformer.transformer import Transformer


def is_pipeline_with_model(steps: List[Transformer]) -> bool:
    """Return True if the pipeline ends with an estimator.
    Parameters
    ----------
        pipeline List[Transformer]: Input pipeline.

    Returns:
        bool: True if the pipeline ends with an estimator.
    """
    last_step = steps[-1]
    return 'predict' in dir(last_step)


def get_num_transformations(steps: List[Transformer]) -> int:
    """Get the number of transformations.

    Parameters
    ----------
        steps (List[Transformer]): List of transformer.

    Returns:
        int: Number of transformations of the input pipeline.
    """
    n_steps = len(steps)
    is_model = is_pipeline_with_model(steps)
    if is_model:
        n_steps -= 1
    return n_steps


def get_important_features(feature_importances: pd.Series) -> List[str]:
    """Get the feature with non zero feature importance values.

    Returns:
    List[str] 
        List of columns.
    """
    return list(
        feature_importances[feature_importances != 0].index)


def get_base_columns(feature_importances: pd.Series,
                     clusters_dict: Dict[str, List[str]] = None) -> List[str]:
    """Get the column names of the input dataframe.

    Skip the generated features.

    Parameters
    ----------
        feature_importances : pd.Series
        Feature importances.
        clusters_dict (Dict[str, List[str]], optional): Dictionary of clustered columns.
            Defaults to None

    Returns:
    List[str] 
        List of columns.
    """
    features = list(feature_importances.index)
    flatten_features = []
    if clusters_dict is not None:
        cluster_features = [val for key, val in clusters_dict.items()
                            if key + '_mean' in features or key + '_std' in features]
        flatten_features = [
            item for sublist in cluster_features for item in sublist]

    base_features = [
        f for f in features
        if not f.startswith('tree_') and
        not f.startswith('pca_') and
        not f.startswith('cluster_') and
        not f.endswith('_isnull') and
        not f.endswith('_mean') and
        not f.endswith('_std') and
        not f.endswith('_hour_of_day') and
        not f.endswith('_day_of_week') and
        not f.endswith('_month_of_year') and
        not f.endswith('_day_of_month') and
        not f.endswith('_hour_of_day_cos') and
        not f.endswith('_day_of_week_cos') and
        not f.endswith('_month_of_year_cos') and
        not f.endswith('_day_of_month_cos') and
        not f.endswith('_hour_of_day_sin') and
        not f.endswith('_day_of_week_sin') and
        not f.endswith('_month_of_year_sin') and
        not f.endswith('_day_of_month_sin') and
        '_is_' not in f and
        '_+_' not in f and
        '_-_' not in f and
        '_*_' not in f and
        '_/_' not in f
    ]
    datetime_base_features = list(
        set(
            [f[:-12] for f in features if f.endswith('_hour_of_day')] +
            [f[:-12] for f in features if f.endswith('_day_of_week')] +
            [f[:-13] for f in features if f.endswith('_day_of_month')] +
            [f[:-14] for f in features if f.endswith('_month_of_year')] +
            [f[:-16] for f in features if f.endswith('_hour_of_day_cos')] +
            [f[:-16] for f in features if f.endswith('_day_of_week_cos')] +
            [f[:-17] for f in features if f.endswith('_day_of_month_cos')] +
            [f[:-18] for f in features if f.endswith('_month_of_year_cos')] +
            [f[:-16] for f in features if f.endswith('_hour_of_day_sin')] +
            [f[:-16] for f in features if f.endswith('_day_of_week_sin')] +
            [f[:-17] for f in features if f.endswith('_day_of_month_sin')] +
            [f[:-18] for f in features if f.endswith('_month_of_year_sin')]
        ))
    final_base_features = base_features + datetime_base_features
    final_base_features = list(set(final_base_features + flatten_features))
    return sorted(final_base_features)


def get_summary(pipeline) -> pd.DataFrame:
    """Get the input pipeline summary.

    Parameters
    ----------
        pipeline Pipeline: Input pipeline.

    Returns:
        pd.DataFrame: Summary of the pipeline.
    """
    pipeline_summary = []
    n_steps = get_num_transformations(pipeline.steps)
    for step in pipeline.steps[:n_steps]:
        series = get_column_dtypes(step)
        pipeline_summary.append(series)
    return pd.concat(pipeline_summary, axis=1, sort=True).fillna(0)
