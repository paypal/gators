# License: Apache-2.0
import numpy as np
import xgboost


class XGBBoosterBuilder:
    """XGBoost Booster Converter class."""

    @staticmethod
    def train(xgboost_model: object,
              X_train: np.array,
              y_train: np.ndarray,
              num_class=None):
        """Convert the XGBoost model to a XGB Booster model.

        Parameters
        ----------
        xgboost_model : object 
            Trained XGBoost model.
        X_train : np.ndarray 
            Train array.
        y_train : np.ndarray 
            Labels.

        Returns
        -------
        xgboost.Booster
            Trained Xgboost Booster model.
        """
        if not isinstance(X_train, np.ndarray):
            raise TypeError('`X_train` must be a numpy array.')
        if not isinstance(y_train, np.ndarray):
            raise TypeError('`y_train` must be a numpy array.')
        params = xgboost_model.get_xgb_params()
        if num_class:
            params['num_class'] = num_class
        n_estimators = xgboost_model.n_estimators
        dtrain = xgboost.DMatrix(X_train, label=y_train)
        return xgboost.train(params, dtrain, n_estimators)
