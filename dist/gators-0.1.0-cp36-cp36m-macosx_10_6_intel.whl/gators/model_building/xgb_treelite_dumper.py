# License: Apache-2.0
import os
import numpy as np
import xgboost
from xgboost.sklearn import XGBClassifier
import treelite


class XGBTreeliteDumper:
    """XGBoost Treelite Dumper class."""

    def __init__(self, xgbooster_model: XGBClassifier):
        """Init the XGBoost Treelite Dumper class.

        Parameters
        ----------
        xgbooster_model : XGBClassifier
            XGB Sklearn model.
        """
        self.xgbooster_model = xgbooster_model

    def dump(self, model_path: str, model_name: str):
        """Dump the XGBoost treelite as a .so and a
        .dylib file.

        Parameters
        ----------
        model_path : str
            Model path.
        model_name : str
            Model name.
        """
        model = treelite.Model.from_xgboost(self.xgbooster_model)
        toolchain = 'gcc'
        model.export_lib(
            toolchain=toolchain,
            libpath=os.path.join(model_path, model_name + '.so'),
            verbose=False,
            params={'parallel_comp': 8},
            nthread=1,
        )
        platform = 'unix'
        toolchain = 'gcc'
        model.export_srcpkg(
            platform=platform,
            toolchain=toolchain,
            params={'parallel_comp': 8},
            pkgpath=os.path.join(model_path, model_name + '.zip'),
            libname=os.path.join(model_path, model_name + '.so'),
            verbose=True,
        )

    def test_sklearn_booster_prediction(self, X: np.ndarray):
        """Test if  the XGBoost sklearn model and the XGBoost
        Booster model give the same predictions.

        Parameters
        ----------
        X : np.ndarray
            Array.
        """
        y_sklearn = self.xgbooster_model.predict_proba(X)[:, 1]
        y_booster = self.xgbooster_model.predict(X)
        assert np.allclose(y_sklearn, y_booster)
        'XGB Sklearn and XGB Booster predictions \
                do not match'
        print('XGB Sklearn and XGB Booster predictions match')
