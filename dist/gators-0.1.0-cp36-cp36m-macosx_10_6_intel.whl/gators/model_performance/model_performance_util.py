# License: Apache-2.0
import numpy as np


def get_y_pred(y_pred_proba: np.array, threshold: float) -> np.ndarray:
    """Return the target prediction.

    Parameters
    ----------
    y_pred_proba : np.ndarray
        Model score values.
    threshold : float
        Score threshold value.

    Returns:
    np.ndarray
        Target prediction.
    """
    return (y_pred_proba > threshold).astype(int)


def get_fbeta_column_name(beta: float) -> str:
    """Get  the fbeta value column name.

    Parameters
    ----------
    beta : float
        Beta value.

    Returns:
    str:
        F-beta value column name.
    """
    if isinstance(beta, int):
        return 'F' + str(beta)
    if beta == int(beta):
        return 'F' + str(int(beta))
    return 'F' + str(round(beta, 2))
