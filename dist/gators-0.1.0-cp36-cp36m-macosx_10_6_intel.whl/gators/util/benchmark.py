# License: Apache-2.0
from typing import List
import numpy as np
from IPython import get_ipython
import pandas as pd
from ..transformer.transformer import Transformer
import sys


def get_runtime_in_milliseconds(ipynb_benchmark: str) -> float:
    """Return the runtime in seconds.


    Parameters
    ----------
    ipynb_benchmark : str
        Output of the jupyter
        timeit magic command.

    Returns:
    float:
        Runtime in milliseconds.
    """
    if not isinstance(ipynb_benchmark, str):
        raise TypeError('`ipynb_benchmark` should be a str')
    dump = ipynb_benchmark.split(' ± ')[0].split(' ')
    if 's' not in ipynb_benchmark:
        raise ValueError('`ipynb_benchmark` format not supported')
    val = float(dump[0])
    t_unit = dump[1]
    if 'ms' in t_unit:
        return val
    if 'µs' in t_unit:
        return val * 1e-3
    if 'ns' in t_unit:
        return val * 1e-6
    if 's' in t_unit:
        return val * 1e3


def display_benchmark_md(benchmark: pd.DataFrame):
    """Display a markdown representation of a DataFrame.

    Parameters
    ----------
        benchmark (pd.DataFrame): Benchmarking data.
    """
    if not isinstance(benchmark, pd.DataFrame):
        raise TypeError('`benchmark` should be a pandas dataframe')
    s = '|   |' + '|'.join(benchmark.columns) + '|\n'\
        '|----' + (len(benchmark.columns)) * '| ----' + '|\n'
    for idx, row in benchmark.iterrows():
        s += '|' + str(idx) + '|' + '|'.join(
            str(row.to_numpy().tolist())[1: -1].split(', ')) + '|\n'
    print(s)


def generate_per_sample_benchmarking(
        objs: List[Transformer],
        Xs: List[pd.DataFrame],
        extra_info_X_vec: List[str] = None,
        extra_info_O_vec: List[str] = None,
        ys: List[np.ndarray] = None) -> pd.DataFrame:
    """Calculate the per-sample benchmarking.

    Parameters
    ----------
    objs List[Transformer]:
        List of transformers.
    Xs List[pd.DataFrame]:
        List of dataFrames.
    ys List[pd.Series], default to None:
        List of target values.


    Returns:
    pd.DataFrame:
        Benchmarking results.
    """
    if ys is None:
        ys = len(Xs) * [None]
    if not extra_info_O_vec:
        index = [
            f'{obj.__class__.__name__}{extra_info_X}'
            for obj, extra_info_X in zip(objs, extra_info_X_vec)
        ]
    elif not extra_info_X_vec:
        index = [
            f'{obj.__class__.__name__}{extra_info_O}'
            for obj, extra_info_O in zip(objs, extra_info_O_vec)
        ]
    else:
        index = [
            f'{obj.__class__.__name__}{extra_info_O}{extra_info_X}'
            for obj, extra_info_O, extra_info_X in zip(objs, extra_info_X_vec, extra_info_O_vec)
        ]
    columns = ['pandas(ms)', 'numpy(ms)']
    print(objs)
    import sys
    # sys.exit()
    results = pd.DataFrame(np.nan, columns=columns, index=index)
    if not extra_info_O_vec:
        extra_info_O_vec = len(objs) * ['']
    if not extra_info_X_vec:
        extra_info_X_vec = len(Xs) * ['']
    for i, (obj, extra_info_O) in enumerate(zip(objs, extra_info_O_vec)):
        print(objs[i].__class__.__name__)
        print(objs[i])
        for X, y, extra_info_X in zip(Xs, ys, extra_info_X_vec):
            X_row = X.iloc[[0]].copy()
            X_row_np = X_row.to_numpy()
            n_cols = X.shape[1]
            _ = obj.fit(X.copy(), y)
            print(obj.transform(X.copy()).shape)
            print('pandas')
            dummy = get_ipython().run_line_magic(
                'timeit', '-o objs[i].transform(X_row)')
            results.loc[f'{obj.__class__.__name__}{extra_info_O}{extra_info_X}', 'pandas(ms)'
                        ] = get_runtime_in_milliseconds(str(dummy))
            print('numpy')
            dummy = get_ipython().run_line_magic(
                'timeit', '-o obj.transform_numpy(X_row_np.copy())')
            results.loc[f'{obj.__class__.__name__}{extra_info_O}{extra_info_X}', 'numpy(ms)'
                        ] = get_runtime_in_milliseconds(str(dummy))
            print()
        print()
    return results


def benchmark_with_same_X(
        objs: List[Transformer],
        X: pd.DataFrame,
        info_vec: List[str],
        y: pd.Series = None) -> pd.DataFrame:
    index = [
        f'{obj.__class__.__name__}{info}'
        for obj, info in zip(objs, info_vec)
    ]
    columns = ['pandas(ms)', 'numpy(ms)']
    results = pd.DataFrame(np.nan, columns=columns, index=index)
    for obj, info in zip(objs, info_vec):
        idx = f'{obj.__class__.__name__}{info}'
        X_row = X.iloc[[0]].copy()
        X_row_np = X_row.to_numpy()
        n_cols = X.shape[1]
        _ = obj.fit(X.copy(), y)
        print(idx.replace('_', ' '))
        print('pandas')
        dummy = get_ipython().run_line_magic(
            'timeit', '-o obj.transform(X_row)')
        results.loc[idx, 'pandas(ms)'] = get_runtime_in_milliseconds(
            str(dummy))
        print('numpy')
        dummy = get_ipython().run_line_magic(
            'timeit', '-o obj.transform_numpy(X_row_np.copy())')
        results.loc[idx, 'numpy(ms)'] = get_runtime_in_milliseconds(str(dummy))
        print()
    return results


def benchmarkkkk(
        objs: object,
        Xs: List[pd.DataFrame],
        info_vec: List[str],
        y: pd.Series = None) -> pd.DataFrame:

    index = [
        f'{obj.__class__.__name__}{info}'
        for obj, info in zip(objs, info_vec)
    ]
    columns = ['pandas(ms)', 'numpy(ms)']
    bench = pd.DataFrame(np.nan, columns=columns, index=index)

    for obj, X, info in zip(objs, Xs, info_vec):
        idx = f'{obj.__class__.__name__}{info}'
        X_row = X.iloc[[0]].copy()
        X_row_np = X_row.to_numpy()
        n_cols = X.shape[1]
        _ = obj.fit(X.copy(), y)
        print(obj.transform(X.copy()).head(2))
        print('pandas')
        dummy = get_ipython().run_line_magic(
            'timeit', '-o obj.transform(X_row)')
        bench.loc[idx, 'pandas(ms)'] = get_runtime_in_milliseconds(str(dummy))
        print('numpy')
        dummy = get_ipython().run_line_magic(
            'timeit', '-o obj.transform_numpy(X_row_np.copy())')
        bench.loc[idx, 'numpy(ms)'] = get_runtime_in_milliseconds(str(dummy))
        print()
    return bench


def benchmark_with_same_obj(
        obj: object,
        Xs: List[pd.DataFrame],
        info_vec: List[str],
        y: pd.Series = None) -> pd.DataFrame:
    index = [
        f'{obj.__class__.__name__}{info}'
        for info in info_vec
    ]
    columns = ['pandas(ms)', 'numpy(ms)']
    results = pd.DataFrame(np.nan, columns=columns, index=index)
    for X, info in zip(Xs, info_vec):
        idx = f'{obj.__class__.__name__}{info}'
        X_row = X.iloc[[0]].copy()
        X_row_np = X_row.to_numpy()
        n_cols = X.shape[1]
        _ = obj.fit(X.copy(), y)
        print(idx.replace('_', ' '))
        print('pandas')
        dummy = get_ipython().run_line_magic(
            'timeit', '-o obj.transform(X_row)')
        results.loc[idx, 'pandas(ms)'] = get_runtime_in_milliseconds(
            str(dummy))
        print('numpy')
        dummy = get_ipython().run_line_magic(
            'timeit', '-o obj.transform_numpy(X_row_np.copy())')
        results.loc[idx, 'numpy(ms)'] = get_runtime_in_milliseconds(str(dummy))
        print()
    return results
