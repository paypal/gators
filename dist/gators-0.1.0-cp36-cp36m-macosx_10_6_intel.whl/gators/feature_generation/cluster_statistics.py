# License: Apache-2.0
from typing import List, Union, Dict
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ._base_feature_gen import _BaseFeatureGen


class ClusterStatistics(_BaseFeatureGen):
    """Statistics Cluster Transformer.

    Parameters
    ----------
    clusters_dict :Dict[str, List[str]]
        Dictionary of clusters of features.
    """

    def __init__(self, clusters_dict: Dict[str, List[str]],
                 column_names: List[str] = None):
        if not isinstance(clusters_dict, dict):
            raise TypeError('`clusters_dict` should be a dict.')
        if column_names is not None and not isinstance(column_names, list):
            raise TypeError('`column_names` should be None or a list.')
        if not column_names:
            column_names = self.get_column_names(clusters_dict)
        columns = list(
            set(
                [c for s in list(clusters_dict.values()) for c in s]
            )
        )
        if column_names and 2 * len(clusters_dict) != len(column_names):
            raise ValueError(
                '''Length of `column_names` should be 
                two times the length of `clusters_dict`.''')

        column_mapping = {
            **{f'{key}__mean': val for (
                key, val) in clusters_dict.items()},
            **{f'{key}__std': val for (key, val)
               in clusters_dict.items()}
        }
        _BaseFeatureGen.__init__(
            self, columns=columns, column_names=column_names,
            column_mapping=column_mapping)
        self.clusters_dict = clusters_dict
        self.n_clusters = len(self.clusters_dict)

    def fit(self,
            X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'ClusterStatistics':
        """Fit the transformer on the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.
        y None 
            None.

        Returns
        -------
        ClusterStatistics
            Instance of itself.
        """
        self.check_dataframe(X)
        self.idx_columns = self.get_idx_columns(
            X, self.clusters_dict)
        return self

    def transform(self,
                  X: Union[pd.DataFrame, ks.DataFrame],
                  ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe X.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
            [Union[pd.DataFrame, ks.DataFrame]]: Dataframe with statistics cluster features.
        """
        for i, columns in enumerate(self.clusters_dict.values()):
            X = X.join(X[columns].mean(axis=1).rename(
                self.column_names[2*i]))
            X = X.join(X[columns].std(axis=1).rename(
                self.column_names[2*i+1]))
        return X

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        X_stats = np.empty((X.shape[0], 2 * self.n_clusters))
        X_stats[:, ::2] = X[:, self.idx_columns].astype(
            np.float64).mean(axis=2)
        X_stats[:, 1::2] = X[:, self.idx_columns].astype(
            np.float64).std(axis=2, ddof=1)
        return np.concatenate((X, X_stats), axis=1)

    @ staticmethod
    def get_idx_columns(
            X: Union[pd.DataFrame, ks.DataFrame],
            clusters_dict: Dict[str, List[str]]) -> np.ndarray:
        """Get the column indices of the clusters.

        Parameters
        ----------
        X : Union[pd.DataFrame, ks.DataFrame]
            Input data.
        clusters_dict : Dict[str, List[str]]
            Clusters. 

        Returns
        -------
        Dict[str, List[str]]
            Column indices of the clusters.
        """
        columns = X.columns
        n_columns = len(columns)
        idx_columns = np.array([
            [i for i in range(n_columns)
             if columns[i] in cluster_columns
             ]
            for cluster_columns in list(clusters_dict.values())
        ])
        return idx_columns

    @staticmethod
    def get_column_names(
            clusters_dict: Dict[str, List[str]]) -> List[str]:
        """Get statistics cluster column names.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        List[str] 
        List of columns.
        """
        column_names = []
        for name in clusters_dict.keys():
            column_names.append(name + '__mean')
            column_names.append(name + '__std')
        return column_names
