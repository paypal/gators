# License: Apache-2.0
import numpy as np
from typing import List, Union, Tuple, Dict
import pandas as pd
import databricks.koalas as ks


def get_num_days_in_month(year: Union[pd.Series, ks.Series],month: np.ndarray) -> np.ndarray:
    """Get the number of days in a month.

        Parameters
        ----------
        year : np.ndarray
            Years.
        month :np.ndarray
            Months of the year.

        Returns
        -------
        np.ndarray
            True if year is a leap year.
        """

    is_leap_year = \
        ((year % 4 == 0) & (year % 100 != 0)) | (year % 400 == 0)
    is_leap_year = is_leap_year.astype(int)
    n_days_of_month = np.array(
        [[0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
            [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
         ])
    return n_days_of_month[is_leap_year, month.astype(int)]


def get_aggregation_counters_clusters_dict(
        X: Union[pd.DataFrame, ks.DataFrame],
        str_pattern: str, sep: str = '_') -> Dict[str, List[str]]:
    """Get the list of columns to be clustered based on a string pattern.


    Parameters
    ----------
        X : Union[pd.DataFrame, ks.DataFrame])
                Dataframe.
        str_pattern : str
            String pattern used to group the columns.
        sep : str, default to            
             Separator. Defaults to '_'.

    Returns:
        Dict[str, List[str]]: Aggregation counters clusters dictionary.
    """
    columns = [c for c in X.columns if str_pattern in c]
    trunk_columns = [sep.join(c.split(sep)[:-1]) for c in columns]
    trunk_columns = list(set(trunk_columns))
    clusters_dict = {
        trunk_column:
        [c for c in columns if c.startswith(trunk_column)]
        for trunk_column in trunk_columns
    }
    return clusters_dict


# def get_aggregation_counters_combination(
#         X: Union[pd.DataFrame, ks.DataFrame]) -> Tuple[List[str], List[str]]:
#     """Get the aggregation counters combination.

#     Parameters
#    ----------
#         X : Union[pd.DataFrame, ks.DataFrame])
                # Dataframe.

#     Returns:
#         Dict[str, List[str]]: Aggregation counters combination.
#     """
#     int_columns = [c for c in X.columns if '_num_distinct' in c]
#     trunk_columns = ['_'.join(c.split('_')[:-1]) for c in int_columns]
#     trunk_columns = list(set(trunk_columns))
#     columns_1day = [trunk_column + '_1day' for trunk_column in trunk_columns]
#     columns_7day = [trunk_column + '_7day' for trunk_column in trunk_columns]
#     columns_30day = [trunk_column + '_30day' for trunk_column in trunk_columns]
#     return columns_1day + columns_1day, columns_7day + columns_30day


def get_is_null_columns(
        feature_importances: pd.Series) -> List[str]:
    """Get the 'is_null' features.

    Parameters
    ----------
    feature_importances : pd.Series
    Feature Importances

    Returns:
    List[str] 
        List of columns.
    """
    columns = [
        column for column in feature_importances.index
        if column.endswith('is_null')
    ]
    return columns


def get_is_equal_columns(
        feature_importances: pd.Series) -> Tuple:
    """Get the 'is_null' features.

    Parameters
    ----------
    feature_importances : pd.Series
        Feature Importances

    Returns:
    List[str] 
        List of columns.
    """
    columns = [
        column for column in feature_importances.index
        if '_is_' in column
    ]

    columns_a = [column.split('_is_')[0] for column in columns]
    columns_b = [column.split('_is_')[1] for column in columns]
    return columns_a, columns_b


def get_trunck_column_list(columns: List[str]) -> List[str]:
    """Get the list of the trunck columns.

    Parameters
    ----------
    feature_importances : pd.Series
        Feature Importances

    Returns:
    List[str] 
        List of columns.
    """
    trunck_columns_list = [
        c[:-5] for c in columns
        if c.endswith('mean')
    ]
    trunck_columns_list += [
        c[:-4] for c in columns
        if c.endswith('std')
    ]
    return list(set(trunck_columns_list))


def get_cluster_dict(
        feature_importances: pd.Series, clusters_dict: Dict) -> Dict:
    """Get the dictionary of cluster features.

    Parameters
    ----------
    feature_importances : pd.Series
        Feature importances.

    Returns:
    List[str] 
        List of columns.
    """
    columns = list(feature_importances.index)
    trunck_columns_list = get_trunck_columns_list(columns)
    return {
        key: val for key, val in clusters_dict.items()
        if key in trunck_columns_list
    }


def get_production_clusters_dict(
        feature_importances: pd.Series,
        clusters_dict: Dict[str, List[str]]
        ) -> Dict[str, List[str]]:
    """Get the columns used for the cluster features.

    Parameters
    ----------
    feature_importances : pd.Series
        Feature importances.
    clusters_dict : Dict[str, List[str]])
        List of trunk columns.

    Returns:
    Dict[str, List[str]]
        Dictionary of clusters.
    """
    columns = list(feature_importances.index)
    return {
        key: val for key, val in clusters_dict.items()
        if key+'_mean' in columns or key+'_std' in columns}


def select_cluster_dict_with_cluster_statistics_features(
        clusters_dict: Dict[str, List[str]],
        cluster_statistics_features: List[str]) -> Dict[str, List[str]]:
    """Get the features used for the cluster features.

    Parameters
    ----------
    clusters_dict : Dict[str, List[str]])
        Dictionary of clusters.
    selected_trunk_columns: List[str]
            List of selected trunk columns.

    Returns:
    Dict[str, List[str]]
        Filtered dictionary of clusters.
    """
    trunk_columns = get_trunck_column_list(cluster_statistics_features)
    return {key: val for key, val in clusters_dict.items()
            if key in trunk_columns}


def select_top_cluster_statistics_features(
        statitics_cluster_columns_coor: pd.Series,
        n_top_features):
    """Select the top statistics cluster features.

    Parameters
    ----------
    statitics_cluster_columns_coor : pd.Series
        Statistics cluster columns correlation.
    n_top_features : int: 
        Number of top features.
        
    Returns:
    List[str]
        Top features.    
    """
    n_cluster_features = len(statitics_cluster_columns_coor)
    idx = [i for i in range(n_top_features)]
    idx += [i for i in range(n_cluster_features -
                             n_top_features, n_cluster_features)]
    return list(statitics_cluster_columns_coor.iloc[idx].index)
