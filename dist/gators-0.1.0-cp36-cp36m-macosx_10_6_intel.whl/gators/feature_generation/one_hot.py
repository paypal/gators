# License: Apache-2.0
from typing import List, Dict, Union
import numpy as np
import pandas as pd
import databricks.koalas as ks
from ..util import util
from ._base_feature_gen import _BaseFeatureGen


class OneHot(_BaseFeatureGen):
    """
    One Hot Transformer.

    Parameters
    ----------
    categories_dict : Dict[str: List[str]]. 
        keys: columns, values: list of category name.

    Examples
    ---------

    >>> import pandas as pd
    >>> from gators.feature_generation import OneHot
    >>> X = pd.DataFrame({'A': ['a', 'b', 'c'], 'B': ['z', 'a', 'a']})
    >>> obj = OneHot(categories_dict={'A': ['b', 'c'], 'B': ['z']})
    >>> obj.fit_transform(X)
        A	B	A__onehot__w	A__onehot__e	B__onehot__z
    0	a	z	0.0	    0.0	    1.0
    1	b	a	1.0	    0.0	    0.0
    2	c	a	0.0	    1.0	    0.0

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation import OneHot
    >>> X = ks.DataFrame({'A': ['a', 'b', 'c'], 'B': ['z', 'a', 'a']})
    >>> obj = OneHot(categories_dict={'A': ['b', 'c'], 'B': ['z']})
    >>> obj.fit_transform(X)
        A	B	A__onehot__w	A__onehot__e	B__onehot__z
    0	a	z	0.0	    0.0	    1.0
    1	b	a	1.0	    0.0	    0.0
    2	c	a	0.0	    1.0	    0.0

    >>> import pandas as pd
    >>> from gators.feature_generation import OneHot
    >>> X = pd.DataFrame({'A': ['a', 'b', 'c'], 'B': ['z', 'a', 'a']})
    >>> obj = OneHot(categories_dict={'A': ['b', 'c'], 'B': ['z']})
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([['a', 'z', 0.0, 0.0, 1.0],
           ['b', 'a', 1.0, 0.0, 0.0],
           ['c', 'a', 0.0, 1.0, 0.0]], dtype=object)

    >>> import databricks.koalas as ks
    >>> from gators.feature_generation import OneHot
    >>> X = ks.DataFrame({'A': ['a', 'b', 'c'], 'B': ['z', 'a', 'a']})
    >>> obj = OneHot(categories_dict={'A': ['b', 'c'], 'B': ['z']})
    >>> obj.fit(X)
    >>> obj.transform_numpy(X.to_numpy())
    array([['a', 'z', 0.0, 0.0, 1.0],
           ['b', 'a', 1.0, 0.0, 0.0],
           ['c', 'a', 0.0, 1.0, 0.0]], dtype=object)
    """

    def __init__(self, categories_dict: Dict[str, List[str]],
                 column_names: List[str] = None):
        if not isinstance(categories_dict, dict):
            raise TypeError('`categories_dict` should be a dict.')
        if column_names is not None and not isinstance(column_names, list):
            raise TypeError('`column_names` should be None or a list.')
        self.categories_dict = categories_dict
        columns = list(set(categories_dict.keys()))
        if not column_names:
            column_names = [
                f'{col}__onehot__{cat}'
                for col, cats in categories_dict.items()
                for cat in cats
            ]
            column_mapping = {
                f'{col}__onehot__{cat}': col
                for col, cats in categories_dict.items()
                for cat in cats
            }
        else:
            column_mapping = {
                name: col
                for name, col in zip(column_names, categories_dict.keys())
            }
        n_cats = sum([len(cat) for cat in categories_dict.values()])
        if column_names and n_cats != len(column_names):
            raise ValueError(
                'Length of `clusters_dict` and `column_names` should match.')

        _BaseFeatureGen.__init__(
            self, columns=columns, column_names=column_names,
            column_mapping=column_mapping)
        self.mapping = dict(zip(self.column_names, self.columns))
        self.colums_per_cat = [
            col
            for col, cats in categories_dict.items()
            for cat in cats
        ]
        self.cats = [
            cat
            for col, cats in categories_dict.items()
            for cat in cats
        ]

    def fit(self, X: Union[pd.DataFrame, ks.DataFrame],
            y: Union[pd.Series, ks.Series] = None) -> 'OneHot':
        """
        Fit the dataframe X.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.
            y (np.ndarray, optional): labels. Defaults to None.

        Returns
        -------
            OneHot: Instance of itself.
        """
        self.check_dataframe(X)
        self.idx_columns = np.array(
            [
                util.get_idx_columns_in_selected_columns(
                    X.columns, [c])[0]
                for c in list(self.categories_dict.keys())
            ]
        )
        return self

    def transform(self,
                  X: Union[pd.DataFrame, ks.DataFrame]
                  ) -> Union[pd.DataFrame, ks.DataFrame]:
        """Transform the dataframe `X`.

        Parameters
        ----------
        X Union[pd.DataFrame, ks.DataFrame]. 
            Input dataframe.

        Returns
        -------
        Union[pd.DataFrame, ks.DataFrame]
            Transformed dataframe.        
        """
        self.check_dataframe(X)
        if len(self.idx_columns) == 0:
            return X
        for name, col, cat in zip(self.column_names, self.colums_per_cat, self.cats):
            X[name] = (X[col] == cat)

        return X

    def transform_numpy(self, X: np.ndarray) -> np.ndarray:
        """Transform the numpy array `X`.

        Parameters
        ----------
        X  : np.ndarray
            Input array.

        Returns
        -------
        np.ndarray
            Transformed array.
        """
        self.check_array(X)
        n_rows = X.shape[0]
        categories_list = [
            cat for cats in self.categories_dict.values()
            for cat in cats]
        n_columns = len(categories_list)
        if n_columns == 0:
            return X
        X_onehot = np.empty((n_rows, n_columns), object)
        i = 0
        for i_col, cats in zip(self.idx_columns, list(self.categories_dict.values())):
            for cat in cats:
                X_onehot[:, i] = X[:, i_col] == cat
                i += 1
        return np.concatenate((X, X_onehot), axis=1)
